<?php
include"header.php";
if($_SESSION['USER']['logedin']=='true'){
header("location:index");
}
//$go_page=$_REQUEST['cart'];
if(isset($_POST['user_login']) && $_POST['user_login']=='Userlogin'){
$remember_me=$_POST['remember_me'];
  
$sql = "SELECT * FROM ".DTABLE_USER." WHERE email = '".$_POST['email']."' AND password = '".$_POST['password']."' and status='Active'";
$getCount  = $db->countRows($sql);
if($getCount == 0) {
$msg_class = 'alert-danger';  
$msg = MSG_INVALID_USER;
}else{ 
$row = $db->selectData($sql);
$res = $db->getRow($row);
$newAdminDataArray = array( 
  'id' => $res['id'],
  'logedin' => 'true',
  'email' => $res['email'],
    'status' => $res['status'],
  'phone' => $res['contact'],
  'chk_u' => 'use', 
  'name' =>  $res['name']
);
if(count($newAdminDataArray) > 0){
  //$_SESSION['id']=$res['admin_login_id'];
     //$_SESSION['ps']=$_POST['password'];
  if ($remember_me == "y"){
       setcookie("cookie_member_u",$res['email'],time()+2592000);
       setcookie("cookie_member_upw",$_POST['password'],time()+2592000);

     }else{
       setcookie ("cookie_member_u","", time()-3600);
       setcookie ("cookie_member_upw","", time()-3600);

     }

$_SESSION['USER'] = $newAdminDataArray;
//if($go_page!='cart_log'){
//header("location:post_ad_details");
header("location:cat_list");
//}else{
//header("location:checkout");
//}

}
}
}
?>

<?php
include"inner_search.php";
?>

<div class="mainarea ad_part">
  <div class="container">
      <div class="row">
         <div class="col-lg-8">
         <div class="sign_inbox">
         <?php if((isset($msg)) and ($msg != '')){ ?>
            <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
            </div>
            <?php } ?>
                <form method="post">
                  <input type="hidden" name="user_login" value="Userlogin">
              <h4>Sign In</h4>
                <div class="form-group">
                  <label>Email Address: </label>
                    <input type="email" class="form-control" name="email" id="email">
                </div>
                 <div class="form-group">
                  <label>Password: </label>
                    <input type="password" class="form-control" name="password" id="password">
                    <a class="btn btn-link" href="forgot_password"> Forgot your password?</a>
                </div>
                <div class="form-check mb-4">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1" <?php if($_COOKIE['cookie_member_u']!=''){ ?>checked<?php } ?> name="remember_me" value="y">
                    <label class="form-check-label" for="exampleCheck1">Keep me signed in</label>
                </div>
                <input type="submit" value="Sign In" class="btn btn-danger">
            </form>
            </div>
            </div>
            <div class="col-lg-4">
              <div class="wiget_box">
                  <h5>Not registered yet?</h5>
                    <p>Register now to post, edit, and manage ads. It’s quick, easy, and free!</p>
                    <a href="register" class="btn btn-info">Register Now</a>
                </div>
                <div class="wiget_box box_two_st">
                  <h5>Protect your account</h5>
                    <p>Ensure that whenever you sign in to Kijiji, the Web address in your browser starts with https://www.xoomla.ca/</p>
                   
                </div>
            </div>
            </div>
       
      
    </div>
</div>


<?php
include"footer.php";
?>