<?php
$page="pad";
include"header.php";
$title=$_REQUEST['title'];
$cat=base64_decode($_REQUEST['cat']);
$sub_cat=base64_decode($_REQUEST['sub_cat']);
?>
<div class="innerbanner">
         <div class="container">
            <div class="page-header clearfix">
               <h1>POST AD</h1>
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Post ad</li>
               </ol>
            </div>
         </div>
      </div>
      <div class="mainarea">
         <div class="container">
            <div class="post_addbox">
                <form action="">
                	<!-- <div class="form-group">
                    	<label>Ad title</label>
                        <textarea class="form-control"></textarea>
                    </div>
                    <input type="submit" value="Sign In" class="btn btn-danger d-block w-100">
                     -->
                    <div class="category_selet">
                    	<h4>Select a category</h4>
                        <!--<ul class="clearfix">
                        	<li><a href="#">Buy & Sell</a></li>
                            <li><a href="#">Cars & Vehicles</a></li>
                            <li><a href="#">Real Estate</a></li>
                            <li><a href="#">Jobs</a></li>
                            <li><a href="#">Services</a></li>
                            <li><a href="#">Pets</a></li>
                            <li><a href="#">Vacation Rentals</a></li>
                            <li><a href="#">Community</a></li>
                            
                        </ul>-->
                       
                        <div id="accordion" class="accordion">
                           <div class="card">
                           
                               <?php
                               $i=0; 
                $sql = "SELECT * FROM ".DTABLE_CATEGORY." ORDER BY title asc";
                $res = $db->selectData($sql);
                while($row_rec = $db->getRow($res)){
                  $cat_id=$row_rec['id'];
                  $i++;
                ?>
                              <div class="card-header <?php if($cat==$cat_id){echo"";}else{echo"collapsed";}?>" data-toggle="collapse" href="#collapse<?=$i;?>" aria-expanded="true">
                                <a class="card-title"><?=$row_rec['title'];?> </a> 
                               </div>
                              <div id="collapse<?=$i;?>" class="card-body collapse clearfix <?php if($cat==$cat_id){echo"show";}?>" data-parent="#accordion" >
                                <ul class="clearfix">
                                  <?php 
                                  $sql2 = "SELECT * FROM ".DTABLE_SUBCAT." where cat_id='$cat_id'";
                                  $res2 = $db->selectData($sql2);
                                  while($row_rec2 = $db->getRow($res2)){
              
              
                        ?>
                                    <li class="<?php if($sub_cat==$row_rec2[id]){echo"active";}?>"><a href="post_ad_details?cat=<?=base64_encode($row_rec['id']);?>&sub_cat=<?=base64_encode($row_rec2['id']);?>&title=<?=$title;?>"><?=$row_rec2['name'];?></a></li>
                                    <?php } ?>

                                 </ul>
                              </div>
                            <?php } ?>
                       
            
            </div>
        
         
     
    </div>



                        
                    </div>
                </form>
            </div>
         </div>
      </div>
      <?php
include"footer.php";

?>