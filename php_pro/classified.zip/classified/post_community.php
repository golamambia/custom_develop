<?php
$page="pad";
include"header.php";
if($_SESSION['USER']['logedin']!='true'){
header("location:signin");
}
$title=$_REQUEST['title'];
$cat=base64_decode($_REQUEST['cat']);
$sub_cat=base64_decode($_REQUEST['sub_cat']);

if(isset($_POST['add_post']) && $_POST['add_post']=='add_post'){
    $_POST['entry_date'] =date('d-m-Y');
    $_POST['status']='Active';
    //$_POST['password']=rand(00000,99999);
    $get_last_id = $db->insertDataArray(DTABLE_ADS,$_POST);
    //$name2='';
        if($_FILES['image_browses']['name']!=''){
            $filename = $_FILES['image_browses']['name'];
            $file_tmp = $_FILES['image_browses']['tmp_name'];
            $filetype = $_FILES['image_browses']['type'];
            $filesize = $_FILES['image_browses']['size'];
            
            for($i=0; $i<=count($file_tmp); $i++){
                if(!empty($file_tmp[$i])){
                    $arr=getimagesize($file_tmp[$i]);
                    $userfile_extn = end(explode(".", strtolower($filename[$i])));
                    
                    if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){
                        $tmp_name = $file_tmp[$i];
                        $name = time()."_".$filename[$i];
                        //$name2.=$name.",";
                        move_uploaded_file($tmp_name, SITE_IMAGE_PATH.$name);
                        $_POST['image'] = $name;
                        $_POST['post_id'] = $get_last_id;
                        $get_last_id1 = $db->insertDataArray(DTABLE_ADS_IMG,$_POST);
                    }
                    else{
                        $msg="Picture's must be .jpeg/.jpg/.png/.gif please check extension";
                    }
                }
                else{
                    $msg="Please select some images...";
                }
            }
        }
    if(!empty($get_last_id)):
    $msg_class = 'alert-success';
    $msg = "Your ad successfully posted";
    else:
    $msg_class = 'alert-error';
    $msg = MSG_ADD_FAIL;
    endif;

    }
?>
<style>
	   .from-field {
    border: 1px solid #e2e2e5;
    border-radius: 5px;
    padding-left: 5px;
    font-size: 22px;
    line-height: 0.6em;
}
	.description{
    width: 31%;
    border: 1px solid #e2e2e5;
    border-radius: 5px;
    margin-left: 5px;
	}
	
	
	
	.container1 {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 18px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.container1 input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

	
	
	.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.container1:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.container1 input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.container1 input:checked ~ .checkmark:after {
  display: block;
}

.container1 .checkmark:after {
 	top: 9px;
	left: 9px;
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: white;
}
</style>
<div class="innerbanner">
         <div class="container">
            <div class="page-header clearfix">
               <h1>Post Ad</h1>
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#"><?=mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_CATEGORY." where id='$cat'"))[title];?></a></li>
                  <li class="breadcrumb-item active" aria-current="page"><?=mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_SUBCAT." where id='$sub_cat'"))[name];?></li>
               </ol>
            </div>
         </div>
      </div>
      <div class="mainarea">
         <div class="container">
            <div class="Postd_dtls">
            	<h4>Post Your Ad it's fast and easy</h4>
                <div class="blub_box">
                    <img src="images/light-bulb.png" alt="">
                    Descriptive titles are the best fuel for high<br> performing ads!
               </div>
                <?php if((isset($msg)) and ($msg != '')){ ?>
        <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
        </div>
        <?php } ?>
             <form class="" action="" method="post" enctype="multipart/form-data">
               <div class="Postd_box">
                <input type="hidden" name="add_post" value="add_post">
                <input type="hidden" name="email" value="<?=$_SESSION[USER][email];?>">
               		<h3><span>1</span>Ad Details</h3>
                    <div class="postd_body">
                      <div class="clearfix">
                      <ol class="breadcrumb">
                  <li class="breadcrumb-item"><?=mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_CATEGORY." where id='$cat'"))[title];?></li>
                  <li class="breadcrumb-item active" aria-current="page"><?=mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_SUBCAT." where id='$sub_cat'"))[name];?></li>
               </ol>
               
               </div>
                     
                      
                        	
                        <div class="form-group">
                        	<label class="text">Ad Title: <input type="text" class="from-field" name="company"></label>
                           
                        </div>
                   
						<div class="form-group">
                        	<label class="text">Description: <textarea name="" id="" class="description"></textarea> </label>
                            
                      
                        </div>
                       
                       
                    </div>
               </div>
               
               
               <div class="Postd_box">
               		<h3><span>2</span>Media</h3>
                    <div class="postd_body">
                    	<h5>Add photos to attract interest to your ad</h5>
                      <p>Include pictures with different angles and details. You can upload a maximum of 10 photos, <br>that are at least 300px wide or tall (we recommend at least 1000px).<br><br><!-- Drag and drop to change the order of your pictures. --></p>
                      
                     <div class="clearfix mt-5"> 	 
                     	<!-- Our File Inputs -->
                          <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image1" accept=".gif, .jpg, .png" required />
                            <label  for="image1">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                        
                          <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image2" accept=".gif, .jpg, .png" required />
                            <label  for="image2">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                        
                          <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image3" accept=".gif, .jpg, .png" />
                            <label  for="image3">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                        
                           <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image4" accept=".gif, .jpg, .png" />
                            <label  for="image4">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                          <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image5" accept=".gif, .jpg, .png" />
                            <label  for="image5">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                          
                    </div>
                    
					 <div class="clearfix mt-4">
                    <div class="form-group">
                        	<label class="text">Youtube Link(optional):</label>
                            <input type="text" class="form-control" name="youtube">
							<p class="message">Add a YouTube video to your ad.</p>

                        <p class="example">Example: http://www.youtube.com/watch?v=&lt;your video id&gt;</p>
                        </div>
                    </div>
					
					
					
                    <div class="clearfix mt-4">
                    <div class="form-group">
                    	<label class="text">Website URL:</label>
                    	<label for="chkPassport">
                        <input type="checkbox" id="chkPassport" />   Link to your website -$4.95</label>
                        <div id="dvPassport" style="display: none">
                            <input type="text" class="form-control"  placeholder="Website URL:" name="web_url" />
                        </div>
                       </div>
                    </div>
               </div>
               </div>
			   
			   <div class="Postd_box">
               		<h3><span>3</span>Location</h3>
					   <div class="clearfix mt-5"> 	 
                    <div class="postd_body">
                    	 <div class="form-group">
                        	<label class="text">Postal code or street address</label>
                            <input type="text" class="form-control" name="contact">
                           
                        </div>
					</div>	
						</div>
                         <div class="clearfix mt-4">
                    <div class="form-group">
                    	<label class="text"></label>
                    	<label for="chkPassport">
                        <input type="checkbox" id="chkPassport" /> Show my exact location</label>
                        <div id="dvPassport" style="display: none">
                            <input type="text" class="form-control"  placeholder="Website URL:" name="web_url" />
                        </div>
                       </div>
                    </div>
					
				
               </div>
			   
			     <div class="Postd_box">
               		<h3><span>4</span>Price</h3>
					  
                         <div class="clearfix mt-4" style="position: relative;">
                    <div class="form-group">
                    	<label class="text"></label>
                    	
                            
                                <label class="container1">$
                                  <input type="radio" checked="checked" name="radio">
                                  <span class="checkmark"></span>
                                </label>
                                <label class="container1">Free
                                  <input type="radio" name="radio">
                                  <span class="checkmark"></span>
                                </label>
                                <label class="container1">Please Contact
                                  <input type="radio" name="radio">
                                  <span class="checkmark"></span>
                                </label>
                                <label class="container1">Swap / Trade
                                  <input type="radio" name="radio">
                                  <span class="checkmark"></span>
                                </label>
                       
                       </div>
                    </div>
					
				
               </div>
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
               <div class="Postd_box">
               		<h3><span>5</span>Contact Information</h3>
                    <div class="postd_body">
                    	 <div class="form-group">
                        	<label class="text">Phone Number: <span>(optional)</span></label>
                            <input type="text" class="form-control" name="contact">
                            <p>Your phone number will show up on your Ad.</p>
                        </div>
                         <div class="form-group">
                        	<label class="text">Email:</label>
                            <span class="emailtext"><?=$_SESSION[USER][email];?></span>
                            <p>Your email address will not be shared with others.</p>
                        </div>
                    </div>
               </div>
               
               <!--<div class="Postd_box">
               		<h3><span>4</span>xoomla Policies</h3>
                    <div class="postd_body">
                    	<p><strong>The following content is prohibited from Kijiji. You will be blocked from Kijiji for posting:</strong></p> 
                         <ul>
                         	<li>Multi-level or work from home jobs where recruitment of other members is part of the job</li>
                            <li>Pyramid schemes or any job that requires upfront or periodic payments</li>
                            <li>Jobs that involve sexual activities</li>
                            <li>Identical jobs that are posted in multiple categories and/or on multiple Kijiji sites</li>
                         </ul>
                         <h6>Terms and Conditions</h6>
                         <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="terms_check" id="exampleCheck1" required>
                            <label class="form-check-label" for="exampleCheck1">By posting your ad, you are agreeing to our <a href="#">terms of use</a>, <a href="#">privacy policy</a> and <a href="#">site policies</a>.<br>
          Please do not post duplicate ads. Use 'Promote My Ad' above to gain more replies.</label>
                          </div>
                    </div>
               </div>-->
               
               <div class="btn-group mt-4">
                <input type="submit" value=" Post Your Ad" class="btn btn-danger">
                 <!-- <input type="submit" value="Preview" class="btn btn-primary"> -->
               </div>
               </form>
            </div>
         </div>
      </div>
      <?php
      include"footer.php";
      ?>
      <script type="text/javascript">
    function get_cat(val) {
//alert(val);

$.ajax({
type: "POST",
url: "get_subcat.php",
data: 'val=' + val,
cache: false,
success: function(html) {
//alert(html);

   
$("#sub_category").html(html);


}
});

return false;
}    
</script>