<?php
include"header.php";
if($_SESSION['USER']['logedin']=='true'){
header("location:index");
}
include"inner_search.php";
if(isset($_POST['add_post']) && $_POST['add_post']=='add_post'){
    $_POST['entry_date'] =date('d-m-Y');
    $_POST['status']='Active';
    $sql="select * from ".DTABLE_USER." where email='$_POST[email]'";
     $count=$db->countRows($sql);
     if($count>0){
        $msg_class = 'alert-error';
    $msg = MSG_EMAIL_EXIST;
     }else{
$get_last_id = $db->insertDataArray(DTABLE_USER,$_POST);
if(!empty($get_last_id)):
    $msg_class = 'alert-success';
    $msg = "Thank You for Your Registration";
    else:
    $msg_class = 'alert-error';
    $msg = MSG_ADD_FAIL;
    endif;


            $subject = " Your Registration Has been successful";

            //$log='https://krishnaenterprises.biz/company/index.php';

            $mail_body = '<html><body>';


            $mail_body .= '<table rules="all" style="border-color: #666;" cellpadding="10">';

            $mail_body .= "<tr style='background: #eee;'><td><strong>User Name:</strong> </td><td>" .$_POST['email']. "</td></tr>";


           //$mail_body .= "<tr><td><strong>Username:</strong> </td><td>" . $_POST['email'] . "</td></tr>";

            $mail_body .= "<tr><td><strong>Password:</strong> </td><td>" .$_POST['password']. "</td></tr>";


            //$mail_body .= "<tr><td><strong>Login link:</strong> </td><td>" .$log. "</td></tr>";


            $mail_body .= "</table>";

            $mail_body .= "</body></html>";



require 'class/class.phpmailer.php';

   $mail = new PHPMailer;

   

   $mail->IsSMTP();                                  

  $mail->Host = "bh-ht-2.webhostbox.net";  
  $mail->SMTPAuth = true; 
  $mail->Username = "sendmail@webtechnomind.com"; 
  $mail->Password = "ZM-(XPt2ie!z"; 
  $mail->From = "sendmail@webtechnomind.com";

  $mail->FromName = $_POST['name'];

  $mail->AddAddress($_POST['email']);  

  $mail->WordWrap = 50; 

  $mail->IsHTML(true);  

  $mail->Subject = $subject;



  $mail->Body    = $mail_body;

   $mail->Send();


     }
    
    }
?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<style>
.popover-content {
  padding: 0px;
}
</style>
<div class="mainarea sign_part">
	<div class="container">
    	<div class="row">
         <div class="col-lg-8">
         <div class="sign_inbox">
            <?php if((isset($msg)) and ($msg != '')){ ?>
        <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
        </div>
        <?php } ?>
        	<form action="register" method="post" onsubmit="return validateForm()">
            	<h4>Register</h4>
                <input type="hidden" name="add_post" value="add_post">
                <div class="form-group">
                	<label>Email Address: </label>
                    <input type="email" class="form-control" name="email" id="email" required autocomplete="off">
                    <span style="color:red" id="malert"></span>
                </div>
                <div class="form-group">
                	<label>name: </label>
                    <input type="text" class="form-control" name="name" id="name" required>
                 </div>
                 <div class="form-group">
                	<label>Password (at least 8 characters): </label>
<!--                    <input type="password" class="form-control" name="password" id="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required autocomplete="off" data-toggle="popover" title="Popover Header" data-content="#a1" data-html="true">-->
                     
                     <!-- <input type="password" class="form-control" name="password" id="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required autocomplete="off" data-toggle="popover" title="Popover Header" data-content="Some content inside the popover"> -->


                     <input type="password" class="form-control" name="password" id="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required autocomplete="off" data-toggle="popover" data-container="body" data-placement="right" data-html="true">
                     
                     <div id="popover-content-password" class="hide">
                      <ul class="vertical_ul" id="a1" style="margin: 0;padding: 10px;">
                        <li><span id="length"><i class="fa fa-circle-o" aria-hidden="true"></i></span>At least 8 characters</li>
                        <li><span id="capital"><i class="fa fa-circle-o" aria-hidden="true"></i></span>1 uppercase</li>
                        <li><span id="letter"><i class="fa fa-circle-o" aria-hidden="true"></i></span>1 lowercase</li>
                        <li><span id="number"><i class="fa fa-circle-o" aria-hidden="true"></i></span>1 number</li>
                        <li><span id="special"><i class="fa fa-circle-o" aria-hidden="true"></i></span>1 symbol</li>
                    </ul>

                    </div>
                     
                    <!-- <ul class="vertical_ul" id="a1">
                        <li><span id="length"><i class="fa fa-circle-o" aria-hidden="true"></i></span>At least 8 characters</li>
                        <li><span id="capital"><i class="fa fa-circle-o" aria-hidden="true"></i></span>1 uppercase</li>
                        <li><span id="letter"><i class="fa fa-circle-o" aria-hidden="true"></i></span>1 lowercase</li>
                        <li><span id="number"><i class="fa fa-circle-o" aria-hidden="true"></i></span>1 number</li>
                        <li><span id="special"><i class="fa fa-circle-o" aria-hidden="true"></i></span>1 symbol</li>
                    </ul> -->
                </div>
                <div class="form-group">
                	<label>Re-type password: </label>
                    <input type="password" class="form-control" id="repass" required>
                    <!--<input type="checkbox" onclick="myFunction()">Show Password-->
                    <span id="pass_alert" style="float: right;color: red;"></span>
                </div>
                <input type="submit" value="Register" class="btn btn-danger" id="sub">
                <p class="disclaimer mt-3">By clicking Register, you agree to our <a href="#" target="_blank">Terms of Use</a> and <a href="#" target="_blank">Privacy Policy</a></p>
            </form>
            </div>
            </div>
            
            <div class="col-lg-4">
            	<div class="wiget_box">
                	<h5>Already Registered?</h5>
                    <p>Sign in to post your ad.</p>
                    <a href="signin" class="btn btn-info"> Sign In</a>
                </div>
                <div class="wiget_box">
                	<h5>Why Register?</h5>
                    <p>To enhance your Xoomla experience and help you stay safe and secure, you now need to register to:</p>
                    <ul class="checkmark-list">
                        <li>Post, edit and manage ads</li>
                        <li>Access saved ads in your Favourites from all of your devices</li>
                        <li>Easily promote multiple ads to gain more visibility and view order history</li>
                        <li>Reserve your own nickname</li>
                        <li>And much more!</li>
                    </ul>
                </div>
            </div>
            </div>
       
    	
    </div>
</div>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->

<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script>
$("[data-toggle=popover]").each(function(i, obj) {
$(this).popover({
  html: true,
  content: function() {
    return $('#popover-content-password').html();
  }
});
});
</script>

<script>

var myInput = document.getElementById("password");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");
var special = document.getElementById("special");


myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
   $("#letter").html('<i class="fa fa-check-circle" aria-hidden="true"></i>');
   //$("#sub").prop("disabled", false);
  } else {
   //$("#sub").prop("disabled", true);
    $("#letter").html('<i class="fa fa-circle-o" aria-hidden="true"></i>');
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    
  $("#capital").html('<i class="fa fa-check-circle" aria-hidden="true"></i>');
  //$("#sub").prop("disabled", false);
  } else {
   //$("#sub").prop("disabled", true);
    $("#capital").html('<i class="fa fa-circle-o" aria-hidden="true"></i>');
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
   //$("#sub").prop("disabled", false);
    $("#number").html('<i class="fa fa-check-circle" aria-hidden="true"></i>');
  } else {
   //$("#sub").prop("disabled", true);
    $("#number").html('<i class="fa fa-circle-o" aria-hidden="true"></i>');
  }
  var sp = /[!@#$%^&*]/g;
  if(myInput.value.match(sp)) {  
   //$("#sub").prop("disabled", false);
    $("#special").html('<i class="fa fa-check-circle" aria-hidden="true"></i>');
  } else {
   //$("#sub").prop("disabled", true);
    $("#special").html('<i class="fa fa-circle-o" aria-hidden="true"></i>');
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
   $("#sub").prop("disabled", false);
  $("#length").html('<i class="fa fa-check-circle" aria-hidden="true"></i>');
  } else {
   $("#sub").prop("disabled", true);
    $("#length").html('<i class="fa fa-circle-o" aria-hidden="true"></i>');
  }

  $(".popover-content").html($('#popover-content-password').html());

}
function myFunction() {
  var x = document.getElementById("repass");
  if (x.type === "password") {
    x.type = "text";
    myInput.type = "text";
  } else {
    x.type = "password";
    myInput.type = "password";
  }
}

function validateForm() {
        
            var password = $("#password").val();
            var confirmPassword = $("#repass").val();
            if (password != confirmPassword) {
                //alert("Passwords do not match.");
                $("#pass_alert").html("Passwords do not match.");
                return false;
            }
            
        
    }

$(document).ready(function(){

  $("#email").keyup(function(){
    //alert(2);
    var mail=$("#email").val();
        //email_check(mail);
        $.ajax({
type: "POST",
url: "get_email.php",
data: 'val=' + mail,
cache: false,
success: function(html) {
//alert(html);
if(html>0){
$("#malert").html('Email already exist!');
$("#sub").prop("disabled", true);
//return false;
}else{
    $("#malert").html('');
    $("#sub").prop("disabled", false);
    //return true;
}

}
});

  });

  });
</script>
<!-- <script>
$(function(){
    $("[data-toggle=popover]").popover({
        html : true,
        content: function() {
          var content = $(this).attr("data-popover-content");
          return $(content).children(".popover-body").html();
        },
        title: function() {
          var title = $(this).attr("data-popover-content");
          return $(title).children(".popover-heading").html();
        }
    });
});
</script> -->

<script>
$(document).ready(function(){
  $('#password').popover({title: "<h1><strong>HTML</strong> inside <code>the</code> <em>popover</em></h1>", content: "Blabla <br> <h2>Cool stuff!</h2>", html: true, placement: "right"}); 
});
</script>


<?php
include"footer.php";

?>