<?php
include"header.php";
$id = $_REQUEST['details'];
$get_data = $pm->getTableDetails(DTABLE_ADS,'id',$id);
?>
<div class="innerbanner">
    <div class="container">
        <div class="page-header clearfix">
            <h1>Ad Details</h1>
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index">Home</a></li>
            <li class="breadcrumb-item"><?php echo mysql_fetch_assoc(mysql_query("select title FROM ".DTABLE_CATEGORY." where id=$get_data[category]"))['title']; ?></li>
            <li class="breadcrumb-item"><?php echo mysql_fetch_assoc(mysql_query("select name FROM ".DTABLE_SUBCAT." where id=$get_data[sub_category]"))['name']; ?></li>
            <li class="breadcrumb-item active" aria-current="page"><?=$get_data['title'];?></li>
          </ol>
        </div>
    </div>
</div>

<div class="mainarea">
	<div class="container">
    	<div class="row">
        	<div class="col-lg-9">
            	<article class="article">
               	  <h2 class="one"><?=$get_data['title'];?> </h2>
                  <div class="article_head clearfix">
                    	<ul>
                        	<li><i class="fa fa-clock-o" aria-hidden="true"></i>Today 10.35 AM </li>
                            <li><i class="fa fa-coffee" aria-hidden="true"></i><?php echo mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_CATEGORY." where id='$get_data[category]'"))['title'];?></li>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i><?=$get_data['location'];?></li>
                        </ul>
                    </div>
                    <!--<div class="article_thumble">
                       <img src="images/addthumble.jpg" alt=""> 
                    </div>-->
                    
                    
                    
                    
                    
                     <div class="row">
        <div class="col-lg-12" id="slider">
                <div id="myCarousel" class="carousel slide">
                    <!-- main slider carousel items -->
                    <div class="carousel-inner">

                        <?php 
                      $j=0;
            $sql = "SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$id' order by id desc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
              
            ?>
                        <div class="<?php if($j==0){echo "active";}?> item carousel-item" data-slide-number="<?=$j;?>">
                           <div class="imgthumnail">
                            <img src="<?PHP echo SITE_IMAGE_PATH.$row_rec['image']?>">
                            </div>
                        </div>
                        <?php $j++; }?>
                        
                        <a class="carousel-control left pt-3" href="#myCarousel" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
                        <a class="carousel-control right pt-3" href="#myCarousel" data-slide="next"><i class="fa fa-chevron-right"></i></a>

                    </div>
                    <!-- main slider carousel nav controls -->


                    <ul class="carousel-indicators list-inline">
                        <?php
                      $i=0; 
            $sql = "SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$id' order by id desc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
              
            ?>
                        <li class="list-inline-item <?php if($i==0){echo "active";}?>">
                            <a id="carousel-selector-<?=$i;?>" class="<?php if($i==0){echo "selected";}?>" data-slide-to="<?=$i;?>" data-target="#myCarousel">
                                <img src="<?PHP echo SITE_IMAGE_PATH.$row_rec['image']?>" >
                            </a>
                        </li>
                       <?php $i++; }?>
                        
                    </ul>
            </div>
        </div>

    </div>
                    
                    
                    
                    
                    
                    
                    
                    <h2 class="two">Description</h2>
                    <p><?=$get_data['description'];?></p>
                    
                    <!-- <h2 class="two">Features</h2> -->
                    <div class="feature_list clearfix">
                    <!-- <ul>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Contrary to popular belief</li>
                    </ul> -->
                    <!-- <?=$get_data['features'];?> -->
                    </div>
                    <div class="article_footer clearfix">
                    	<p><i class="fa fa-eye" aria-hidden="true"></i>Ad Views : 6544</p>
                        <ul class="socal_box">
                        	<span>Share This Ad :</span>
                        	<li><a href="javascript:void(0)" onClick="testamb('facebook','<?=$get_data[id];?>','<?PHP echo mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$id'"))['image']?>')"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="javascript:void(0)" onClick="testamb('twitter','<?=$get_data[id];?>','<?PHP echo mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$id'"))['image']?>')"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a href="javascript:void(0)" onClick="testamb('linkedin','<?=$get_data[id];?>','<?PHP echo mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$id'"))['image']?>')"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </article>
                <div class="traning_add mt-4"> 
        
            <h2 class="clearfix">Similar ads<span><a href="#">view all</a></span></h2>
            <div class="row row-5 ">
              <?php 
            $sql = "SELECT * FROM ".DTABLE_ADS." where id!='$id' and category='$get_data[category]' ORDER BY rand() DESC limit 0,4";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
                $post_id=$row_rec['id'];
              $cat_id=$row_rec['category'];
              $get_img =mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$post_id'"));
              $get_cat =mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_CATEGORY." where id='$cat_id'"));
            ?>  
        <div class="col-lg-3">
        <div class="item box">
                    <a href="ad_details?details=<?=$row_rec['id'];?>">
                    	<div class="imgthumble">
                   	       <img src="<?PHP echo SITE_IMAGE_PATH.$get_img['image'];?>" alt="">
                           <div class="stiker"><?=$get_cat['title'];?></div>
                           <div class="titel"><?=$row_rec['title'];?></div> 
                        </div>
                        <div class="bodyarea">
						 <?php if($row_rec['price']!='') { ?>
                        	<h4>Price: $<?=$row_rec['price'];?></h4>.
						 <?php } ?>
                            <p><?php echo substr($row_rec['description'], 0, 60) . '...'; ?></p>
                            <div class="dated"><i class="fa fa-clock-o" aria-hidden="true"></i> <?=date('d.m.Y',strtotime($row_rec['entry_date']));?></div>
                            <div class="calgary"><i class="fa fa-map-marker" aria-hidden="true"></i> <?=$row_rec['location'];?></div>
                        </div>
                        </a>
                    </div>
        </div>
        <?php }?>


</div>
</div>
            
            </div>
            <div class="col-lg-3">
            	<aside class="aside">
               	  <div class="aside_wizget card">
                    	<div class="card-header">
						   <?php if($get_data['price']!="") { ?>
                           <h2><span>$</span><?=$get_data['price'];?></h2>
						   <?php } ?>
                        </div>
                        <div class="card-body text-center">
                   	       <?php if($get_data['pro_pic']!=''){?>

                            <img src="<?PHP echo SITE_IMAGE_PATH.$get_data['pro_pic']?>" class="thumbleimg" alt="">
                         <?php }else{?>
                           <img src="<?PHP echo SITE_IMAGE_PATH.mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$id'"))['image']?>" class="thumbleimg" alt=""><?php }?>
                           <h4><?=$get_data['name'];?></h4>
                           <p><i class="fa fa-clock-o" aria-hidden="true"></i>Joined:  <?php echo $dt=date('d M Y',strtotime($get_data['entry_date']));?></p>
                           <p><i class="fa fa-map-marker" aria-hidden="true"></i>Location: <?=$get_data['location'];?></p> 
                        </div>
                    </div>
                    
                    
                    
                    <div class="aside_wizget card mt-4">
                    	<div class="card-header">
                           <h2>Location</h2>
                        </div>
                        <div class="card-body p-0">
                   	       <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30593401584!2d-74.25986539089548!3d40.69714941954754!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY!5e0!3m2!1sen!2sus!4v1506615745397" width="100%" height="250" style="border:0" allowfullscreen=""></iframe> -->
                           <?php //$address = '1625 Hennepin Ave, Minneapolis, MN';
                           $address =$get_data['location'].','.$get_data['city'].','.$get_data['state'];
   
echo '<iframe  width="100%" height="250" style="border:0" allowfullscreen="" src="https://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q=' . str_replace(",", "", str_replace(" ", "+", $address)) . '&z=14&output=embed"></iframe>';?>
                        </div>
                    </div>
                    
                    <div class="aside_wizget card mt-4">
                    	<div class="card-header">
                           <h2>Contact</h2>
                        </div>
                        <div class="card-body">
                   	       <span id="feedback"></span>
                           <form method="post">
                           <div class="form-group">
                           <input type="text" class="form-control" id="name" placeholder="Name">
                           </div>
                           <div class="form-group">
                           <input type="email" id="email" class="form-control" placeholder="Email">
                           </div>
                           <div class="form-group">
                           <input type="text" id="phone" class="form-control" placeholder="Phone Number">
                           </div>
                           <div class="form-group">
                           <textarea id="message" class="form-control" placeholder="Message"></textarea>
                           </div>
                           <input onclick="myFunction()" type="button" class="btn btn-primary w-100" value="Send Message" id="send">
                           </form>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                    <!--<div class="aside_wizget card mt-4">
                    	<div class="card-header">
                          <h3>Similar ads</h3>
                        </div>
                        <div class="card-body">
                   	     <ul>
                         	<li>
                              <a href="#">
                              <span><img src="images/feature_three.jpg" class="rounded-circle" alt=""></span>
                              <h5>This is dummy te heading</h5>
                              <div class="price">Price: $1510.00</div>
                              <p><i class="fa fa-map-marker" aria-hidden="true"></i>Calgary</p>
                              </a>
                            </li>
                            <li>
                              <a href="#">
                              <span><img src="images/feature_three.jpg" class="rounded-circle" alt=""></span>
                              <h5>This is dummy te heading</h5>
                              <div class="price">Price: $1510.00</div>
                              <p><i class="fa fa-map-marker" aria-hidden="true"></i>Calgary</p>
                              </a>
                            </li>
                            <li>
                              <a href="#">
                              <span><img src="images/feature_three.jpg" class="rounded-circle" alt=""></span>
                              <h5>This is dummy te heading</h5>
                              <div class="price">Price: $1510.00</div>
                              <p><i class="fa fa-map-marker" aria-hidden="true"></i>Calgary</p>
                              </a>
                            </li>
                            
                         </ul>
                        </div>
                    </div>-->
                </aside>
            </div>
            
        </div>
        
        

	 <div class="adds-banner mt-5">
    <img src="images/Banner_Pasang_Iklan_zpsa9a64beb.gif" alt=""> 
    </div>
    </div>
</div>
<script type="text/javascript">
   function myFunction() {
var name = document.getElementById("name").value;
var email = document.getElementById("email").value;
var phone = document.getElementById("phone").value;
var message = document.getElementById("message").value;
var sender='<?=$get_data['email'];?>';
// Returns successful data submission message when the entered information is stored in database.
var dataString = 'name=' + name + '&email=' + email + '&phone=' + phone + '&message=' + message + '&sender=' + sender;
if (name == '' || email == '' || phone == '' || message == '') {
alert("Please Fill All Fields");
$("#name").focus();
} else {
   //$("#send").html('Please wait...');
   $("#send").prop('value', 'Please wait...');
   $("#send").prop("disabled", true);
// AJAX code to submit form.
$.ajax({
type: "POST",
url: "sendmail.php",
data: dataString,
cache: false,
success: function(html) {
//alert(html);
if(html!='no'){
   $("#name").val('');
    $("#email").val('');
     $("#phone").val('');
      $("#message").val('');
$("#feedback").html("Your message successfully send");
//$("#send").html('Send Message');
$("#send").prop('value', 'Send Message');
$("#send").prop("disabled", false);
}else{
 $("#feedback").html("Your message not send");
 $("#send").prop('value', 'Send Message');
 //$("#send").html('Send Message');
 $("#send").prop("disabled", false);  
}
}
});
}
return false;
}
function testamb(social,pid,img){
    //alert(img);
$.ajax({
type: "POST",
url: "get_share.php",
data: 'social='+social+'&pid='+pid+'&img='+img,
cache: false,
success: function(html) {
//alert(html);
var fields = html.split('~');

var name1 = fields[1];
  var name =name1.trim();

socialsharingbuttons_blog(social, name);
}
});

return false;

    }
</script>
<script type="text/javascript">
  function socialsharingbuttons_blog(social, params){
    //alert(social);
  var w = 550;
        var h = 550;
        var left = Number((screen.width/2)-(w/2));
        var tops = Number((screen.height/2)-(h/2));
  var button= '';
  switch (social) {
   case 'facebook':
    button=params;
    window.open(params, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+tops+', left='+left);
    break;
   
    case 'twitter':
    button=params;
    window.open(params, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+tops+', left='+left);
    break;
   
    case 'linkedin':
    button=params;
    window.open(params, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+tops+', left='+left);
    break;
   default:
    break;
  }
  return button; 
 }
</script>
<?php
include"footer.php";
?>