<?php
include"configure.php";

if(!empty($_POST["keyword"])) {

?>
<ul id="country-list">

<?php 
            $sql = "SELECT * FROM ".DTABLE_ADS." WHERE title like '" . $_POST["keyword"] . "%' ORDER BY title asc";
            $res = $db->selectData($sql);
            $count = $db->countRows($sql);
            if($count>0){
            while($row_rec = $db->getRow($res)){
            ?>
            <li onClick="selectCountry('<?=$row_rec['title'];?>');"><?=$row_rec['title'];?></li>
           
          <?php }}else{?>
          	<li onClick="selectCountry('');">No record found</li>
          <?php }?>
</ul>
<?php }  ?>