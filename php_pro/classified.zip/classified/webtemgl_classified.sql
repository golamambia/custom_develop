-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 09, 2019 at 08:31 AM
-- Server version: 5.6.41-84.1-log
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtemgl_classified`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_admin`
--

CREATE TABLE `admin_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_login_id` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_fastname` varchar(255) NOT NULL,
  `admin_lastname` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_last_login_ip` varchar(255) NOT NULL,
  `admin_last_login_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_admin`
--

INSERT INTO `admin_admin` (`admin_id`, `admin_login_id`, `admin_password`, `admin_fastname`, `admin_lastname`, `admin_email`, `admin_last_login_ip`, `admin_last_login_datetime`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '', '', '', '192.185.129.32', '2019-07-09 06:50:22');

-- --------------------------------------------------------

--
-- Table structure for table `admin_setting`
--

CREATE TABLE `admin_setting` (
  `id` int(11) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `linkdin` varchar(255) NOT NULL,
  `google_plus` varchar(255) NOT NULL,
  `site_email` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `office_phone` varchar(50) NOT NULL,
  `site_logo` varchar(255) NOT NULL,
  `from_email` varchar(100) NOT NULL,
  `about` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_setting`
--

INSERT INTO `admin_setting` (`id`, `twitter`, `facebook`, `linkdin`, `google_plus`, `site_email`, `address`, `phone`, `office_phone`, `site_logo`, `from_email`, `about`) VALUES
(1, 'https://twitter.com', 'https://www.facebook.com', 'https://www.linkedin.com', '#', 'info@Xoomla.ca', '7007 Dummy Avenue,\r\nCA 96001 USA', '7980230244', '7980230244', '1560341660_xoomla.png', '', 'Donec id elit non mi porta graat eget metus. Akshay id elit non Vestibulum id ligula. Lorem Ipsum is simply dummy text of the printing and typesetting industry.');

-- --------------------------------------------------------

--
-- Table structure for table `carmodel`
--

CREATE TABLE `carmodel` (
  `mid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carmodel`
--

INSERT INTO `carmodel` (`mid`, `id`, `name`) VALUES
(2, 0, 'Alfetta'),
(3, 0, 'Milano'),
(4, 0, 'Spider'),
(5, 0, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `category_table`
--

CREATE TABLE `category_table` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `menu` varchar(5) NOT NULL,
  `isDisplay` varchar(255) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `cat_image` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_table`
--

INSERT INTO `category_table` (`id`, `title`, `menu`, `isDisplay`, `icon`, `cat_image`) VALUES
(12, 'Jobs', 'Yes', '', 'flaticon-portfolio', '1551791674_jobs.ea02e64d.jpg'),
(13, 'Services', 'Yes', '', 'flaticon-businessman', '1551791747_services.fa51dc36.jpg'),
(14, 'Pets', 'Yes', '', 'flaticon-walking-with-dog', '1551805949_Tulips.jpg'),
(10, 'Cars & Vehicles', 'Yes', '', 'flaticon-sports-car', '1551792390_cars-and-vehicles.ab3adeb0.jpg'),
(11, 'Real Estate', 'Yes', '', 'flaticon-house', '1551791611_real-estate.3a54bc7c.jpg'),
(15, 'Vacation Rentals', 'Yes', '', 'flaticon-traveler-with-a-suitcase', '1551792095_vacation-rentals.6a19a2c3.jpg'),
(16, 'Community', 'Yes', '', 'flaticon-social-media', '1551792166_community.0714fc17.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `inquery_message`
--

CREATE TABLE `inquery_message` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `message` text NOT NULL,
  `c_user` varchar(256) NOT NULL,
  `entry_date` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inquery_message`
--

INSERT INTO `inquery_message` (`id`, `name`, `email`, `phone`, `message`, `c_user`, `entry_date`) VALUES
(1, 'golam ambia', 'wtm.golam@gmail.com', '7003832809', 'final', 'wtm.golam@gmail.com', '21-02-2019'),
(2, 'What is Lorem Ipsum?', 'wtm.golam@gmail.com', '7003832809', 'dddd', 'wtm.golam@gmail.com', '21-02-2019'),
(3, 'SHISH KEBAB', 'wtm.golam@gmail.com', '7003832809', 'fff', 'wtm.golam@gmail.com', '21-02-2019'),
(4, 'SHISH KEBAB', 'wtm.golam@gmail.com', '7003832809', 'dddgfffghtrfhtrhfcvff', 'wtm.golam@gmail.com', '21-02-2019'),
(5, 'SHISH KEBAB', 'wtm.golam@gmail.com', '7003832809', 'ambia', 'wtm.golam@gmail.com', '21-02-2019'),
(6, 'zxzXzX', 'zxX', 'zxX', 'zxzX', 'wtm.golam@gmail.com', '07-03-2019'),
(7, 'Amit Kumar', 'agrahriamit86@gmail.com', '8961757873', 'test', 'wtm.golam@gmail.com', '28-03-2019'),
(8, 'Navita', 'joneslouis620@gmail.com', '9638527410', 'Hi ', 'allenhayden448@gmail.com', '28-05-2019'),
(9, 'jdsnbfb', 'm,sd cdn', '432132132', 'sd mfdsnmf', 'joneslouis620@gmail.com', '30-05-2019'),
(10, 'Clark', 'annaclark251@gmail.com', '09910844229', 'Hi, this is test message', 'simonmoore921@gmail.com', '30-05-2019'),
(11, 'Navin', 'navin209@gmail.com', '7418529633', 'test message', 'allenhayden448@gmail.com', '31-05-2019'),
(12, 'Alien ', 'alien.m96@gmail.com', '6547895233', 'i m interested ', 'annaclark251@gmail.com', '20-06-2019');

-- --------------------------------------------------------

--
-- Table structure for table `make`
--

CREATE TABLE `make` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `make`
--

INSERT INTO `make` (`id`, `name`) VALUES
(1, 'Calgary'),
(2, 'Lloydminster'),
(3, 'Red Deer'),
(4, 'Edmonton Area'),
(5, 'Volvo');

-- --------------------------------------------------------

--
-- Table structure for table `post_ads`
--

CREATE TABLE `post_ads` (
  `id` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `price` varchar(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `category` int(11) NOT NULL,
  `sub_category` int(11) NOT NULL,
  `location` text NOT NULL,
  `email` varchar(256) NOT NULL,
  `postal_code` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `state` int(11) NOT NULL,
  `city` varchar(256) NOT NULL,
  `password` varchar(100) NOT NULL,
  `pro_pic` varchar(256) NOT NULL,
  `features` text NOT NULL,
  `job_offer` varchar(50) NOT NULL,
  `company` varchar(150) NOT NULL,
  `job_type` varchar(50) NOT NULL,
  `web_url` varchar(200) NOT NULL,
  `terms_check` varchar(10) NOT NULL,
  `entry_date` varchar(20) NOT NULL,
  `AdType` varchar(255) NOT NULL,
  `SaleBy` varchar(255) NOT NULL,
  `urgentprice` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `youtube_url` varchar(255) NOT NULL,
  `priceoption` varchar(255) NOT NULL,
  `Bedrooms` varchar(255) NOT NULL,
  `Bathrooms` varchar(255) NOT NULL,
  `PetFriendly` varchar(255) NOT NULL,
  `Furnished` varchar(255) NOT NULL,
  `RentBy` varchar(255) NOT NULL,
  `Make` varchar(255) NOT NULL,
  `Model` varchar(255) NOT NULL,
  `Trim` varchar(255) NOT NULL,
  `Year` varchar(255) NOT NULL,
  `Kilometers` varchar(255) NOT NULL,
  `BodyType` varchar(255) NOT NULL,
  `Transmission` varchar(255) NOT NULL,
  `Drivetrain` varchar(255) NOT NULL,
  `Colour` varchar(255) NOT NULL,
  `FuelType` varchar(255) NOT NULL,
  `Doors` varchar(255) NOT NULL,
  `Seats` varchar(255) NOT NULL,
  `companyoption` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_ads`
--

INSERT INTO `post_ads` (`id`, `title`, `price`, `name`, `description`, `category`, `sub_category`, `location`, `email`, `postal_code`, `status`, `contact`, `state`, `city`, `password`, `pro_pic`, `features`, `job_offer`, `company`, `job_type`, `web_url`, `terms_check`, `entry_date`, `AdType`, `SaleBy`, `urgentprice`, `address`, `youtube_url`, `priceoption`, `Bedrooms`, `Bathrooms`, `PetFriendly`, `Furnished`, `RentBy`, `Make`, `Model`, `Trim`, `Year`, `Kilometers`, `BodyType`, `Transmission`, `Drivetrain`, `Colour`, `FuelType`, `Doors`, `Seats`, `companyoption`) VALUES
(1, 'Dummy text', '44', 'golam ambia', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 1, 1, 'Kolkata, West Bengal', 'wtm.golam@gmail.com', '123456', '', '8016095108', 0, '', '8931026127', '', '', '', '', '', '', '', '16-02-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, 'title', '44', 'golam ambia', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 1, 1, 'Kolkata, West Bengal', 'wtm.golam@gmail.com', '123456', '', '8016095108', 0, '', '', '', '', '', '', '', '', '', '16-02-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 'demo title', '44', 'golam ambia', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 1, 1, 'Kolkata, West Bengal', 'wtm.golam@gmail.com', '123456', '', '8016095108', 0, '', '', '', '', '', '', '', '', '', '16-02-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry dummy text of the printing', '44', 'golam ambia', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.', 1, 7, 'Kolkata, West Bengal', 'wtm.golam@gmail.com', '123456', '', '8016095108', 0, '', '', '', '', '', '', '', '', '', '16-02-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, 'Test product', '51', 'SHISH KEBAB', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry dummy text of the printing</p>\r\n', 5, 5, 'baguihati', 'wtm.golam@gmail.com', '123458', 'Active', '8016095108', 59, 'Kolkata', '12345', '1550814262_trending_two.jpg', '<ul>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n	<li>Contrary to popular belief</li>\r\n</ul>\r\n', '', '', '', '', '', '20-02-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, 'Dummy title', '', '', '', 1, 32, '', 'wtm.golam@gmail.com', '', 'Active', '07003832809', 0, '', '', '', '', 'indivitual', 'Zydus Healthcare Limited', 'fulltime', 'http://webtechnomind.com/work/classified/post_ad_details?cat=MQ==&sub_cat=MzI=&title=Dummy%20title', 'on', '05-03-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, 'ewertvvttv', '', '', '', 12, 81, '', 'agrahriamit86@gmail.com', '', 'Active', '+91896175787', 0, '', '', '', '', 'indivitual', 'asdasdasdsad', 'parttime', '', 'on', '08-03-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, 'Test post', '', '', '', 11, 72, '', 'wtm.purnendu@gmail.com', '', 'Active', '08787878787', 0, '', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '16-03-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(12, 'demo anit', '144', '', 'sadsad', 1, 45, '', 'wtm.anit@gmail.com', '454545454', 'Active', '7878787878', 0, '', '', '', '', '', '', '', 'ddd.com', 'on', '20-03-2019', 'I want', 'Business', '7 days -$15.95', 'asdsadsaddsa', 'yyy.com', 'Free', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(13, 'dfgdfgdfgdfg', '8000', '', 'dghtfryhcfguhjghjghjghj', 1, 32, '', 'wtm.anit@gmail.com', '678789', 'Active', '768879978', 0, '', '', '', '', '', '', '', '', 'on', '20-03-2019', 'I am offering', 'Business', '7 days -$15.95', 'sdtgdfghgh tdhy fhf d yhrtyr tyrty889008', 'seszdftgds', 'Free', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(14, 'kol', '', 'Hayden', '', 13, 107, 'Ontario', 'wtm.projectmanager@gmail.com', '', 'Active', '90153456456', 0, 'Toronto', '', '', '', 'indivitual', 'demo service', '', 'ads.com', '', '20-03-2019', '', '', '', 'hi this is dermo test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(15, 'pet f', '', '', '', 14, 121, 'ertretret', 'wtm.anit@gmail.com', '', 'Active', '7878787878', 0, '', '', '', '', '', '', '', 'ddd.com', '', '20-03-2019', 'I am offering', '', '', '', 'yyy.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(16, 're3al', '', '', 'gdfdgfdg', 11, 73, '', 'wtm.anit@gmail.com', '', 'Active', '7878787878', 0, '', '', '', '', '', '', '', 'sdfdsf.coms', '', '22-03-2019', 'I want', '', '7 days -$19.95', '', '', '', '1', '1', 'Yes', 'Yes', 'Owner', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(17, 'Service page', '', '', '', 15, 126, '787878787', 'wtm.anit@gmail.com', '', 'Active', '8888585856', 0, '', '', '', '', 'indivitual', '', '', 'aa.com', '', '25-03-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(19, 'car rent', '', '', 'vfvbcbcvb', 10, 63, '', 'wtm.anit@gmail.com', '', 'Active', 'zXxzxzc', 0, '', '', '', '', '', '', '', 'vbvb.com', '', '27-03-2019', 'I want', 'Owner', '7 days -$15.95', '', 'bcbcvb.com', 'on', '', '', '', '', '', 'Lloydminster', 'milano', 'vfddsf', '2004', '120', 'coup', '2', 'fwd', 'brown', 'electric', '3', '6', 'Sunroof'),
(20, 'dsfsfdsf y7y87yi', '55', '', 'iojeriotuioer', 10, 61, '', 'wtm.projectmanager@gmail.com', '', 'Active', '987455112', 0, '', '', '', '', '', '', '', '', '', '28-03-2019', 'I want', 'Owner', '', '', 'SDgzdfbvzfv', 'on', '', '', '', '', '', 'Edmonton Area', 'Spider', 'vdayj', '2018', '584522', 'vanminicomma', '1', 'awd', 'white', 'gas', '4', '4', 'Cruise control'),
(21, 'comunity', '', '', '', 16, 133, '', 'wtm.anit@gmail.com', '', 'Active', 'xzX', 0, '', '', '', '', '', '', '', '', '', '28-03-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(22, 'asdd', '', '', '', 16, 139, '', 'wtm.projectmanager@gmail.com', '', 'Active', '89745212355', 0, '', '', '', '', '', '', '', '', '', '29-03-2019', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(23, 'Vacation and Trip for Norway', '6000', 'Rahjul', '<p>hgiudfhosd 7 awidyiaydiasydiy9 78y9ds a</p>\r\n', 15, 130, '700159, Baguiati Baguipara ', 'wtm.projectmanager@gmail.com', '700059', 'Active', '9875404193', 59, 'Kolkata', '', '', '<p>ksddfhiosd uf0 y 8uf8o</p>\r\n', '', 'webtechnomind IT Solutions', 'fulltime', 'webtechnomind.com', '', '29-03-2019', 'I am offering', '', '', '', 'YouTube.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(24, 'Immigration Lawyer Consultant', '', '', '', 13, 98, '', 'joneslouis620@gmail.com', '', 'Active', '', 0, '', '', '', '', 'indivitual', 'Go Canada', 'fulltime', 'gocanada.com', 'on', '28-05-2019', '', '', '', '37 Bloor Street West Toronto 5, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(25, 'Immigration Lawyer Consultant Spousal Sponsor', '', 'Hayden', '<p>Our team of Registered Canadian Immigration Consultants RCIC and Immigration Lawyers referral can legally represent you before Immigration, Refugees and Citizenship Canada (IRCC) previously known as Citizenship and Immigration Canada (CIC). Located in Winnipeg Manitoba.</p>\r\n\r\n<p><strong>Benefits:</strong></p>\r\n\r\n<p>&bull; 100% Free Assessment initial assessment</p>\r\n\r\n<p>&bull; Experienced work and honest advice</p>\r\n\r\n<p>&bull; Best price guaranteed</p>\r\n\r\n<p>&bull; Free parking</p>\r\n\r\n<p>&bull; Spousal Sponsorship (inside and outside Canada)</p>\r\n\r\n<p>&nbsp;</p>\r\n', 13, 98, 'Ontario', 'allenhayden448@gmail.com', '', 'Active', '9015385852', 0, 'Toronto', '', '', '<p><strong>Our Services:</strong></p>\r\n\r\n<p>&bull; Sponsorship of Spouse, Dependent and Orphan Children</p>\r\n\r\n<p>&bull; Spousal Sponsorship (inside and outside Canada)</p>\r\n\r\n<p>&bull; Super Visa for parents and grandparents</p>\r\n\r\n<p>&bull; Permanent Resident PR Card Renewal</p>\r\n\r\n<p>&bull; Visitor Visa/Extensions</p>\r\n\r\n<p>&bull; Extend your stay in Canada</p>\r\n\r\n<p>&bull; Citizenship Application</p>\r\n\r\n<p>&bull; Study Permit</p>\r\n\r\n<p>&bull; Work Permits</p>\r\n', 'indivitual', 'Go Canada', 'fulltime', 'gocanada.com', 'on', '28-05-2019', '', '', '', '37 Bloor Street West Toronto 5, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(26, 'Family Divorce Lawyer', '', 'Hayden', '<p>FAMILY LAW</p>\r\n\r\n<p>Regrettably, family relationships do breakdown. When that happens, you need an experienced family law lawyer to manage any or all the consequences of the breakdown: CFS (Child and Family Services), Custody; Access; Child Support; Spousal Support; Divorce; Separation Agreements; Division of Property; Children&#39;s Aid Cases; ETC.</p>\r\n', 13, 98, 'Ontario', 'simonmoore921@gmail.com', '1A9', 'Active', '9638527410', 0, 'Toronto', '', '', '<p>We are lawyers who act in a wide range of family disputes in the courts and in arbitration, mediation and other types of alternative dispute resolution arising out of:</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&bull; Parenting and custody of children</p>\r\n\r\n<p>&bull; Spousal support</p>\r\n\r\n<p>&bull; Child support</p>\r\n\r\n<p>&bull; Property division</p>\r\n\r\n<p>&bull; Pensions, trusts, taxation</p>\r\n\r\n<p>&bull; Family business matters</p>\r\n\r\n<p>&bull; Premarital contracts</p>\r\n\r\n<p>&bull; Cohabitation agreements</p>\r\n\r\n<p>&bull; Separation agreements</p>\r\n\r\n<p>&bull; Common-law relationships</p>\r\n\r\n<p>&bull; Same-sex relationships</p>\r\n\r\n<p>&bull; Inter-jurisdictional and foreign matters</p>\r\n\r\n<p>&bull; Collaborative family law</p>\r\n\r\n<p>Email for an appointment: lawyer@bluewter.com</p>\r\n', 'non_indivitual', 'Global Vision Immigration', 'parttime', 'abc, xyz', 'on', '28-05-2019', '', '', '', '1253 Bay Street Toronto 185, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(27, 'Childcare Available ', '', 'Hayden', '<p>Hi,</p>\r\n\r\n<p>I am an Experienced, Certified Childcare provider.</p>\r\n\r\n<p>I am offering childcare in Smoke and Pet free, clean and safe environment. Big fenced backyard with lots of indoor and outdoor toys, Nearby parks.No subsidy.</p>\r\n\r\n<p>&nbsp;</p>\r\n', 13, 95, 'Alberta', 'allenhayden448@gmail.com', '1A9', 'Active', '9638527413', 0, 'Alberta', '', '', '<p>Type of spot: Full time (Starting June), part-time, summer care, casual, some Saturdays.</p>\r\n\r\n<p>Availability: ASAP</p>\r\n\r\n<p>Ages: 2 yr plus</p>\r\n\r\n<p>Area: North Kildonan</p>\r\n', 'indivitual', 'Global Vision Immigration', 'fulltime', 'abc, xyz', 'on', '28-05-2019', '', '', '', 'Alberta', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(28, 'Childcare Available at Maples Area', '', 'Hayden', '<p>New daycare Opening June 3</p>\r\n\r\n<p>We have Monday Tuesday Thursday and Friday open for 1 spot</p>\r\n\r\n<p>CPR &amp; First Aid Certified.</p>\r\n\r\n<p>&nbsp;</p>\r\n', 13, 95, 'Manitoba', 'allenhayden448@gmail.com', '', 'Active', '843-5647-236', 0, 'Manitoba', '', '', '<p>Area: Transcona</p>\r\n\r\n<p>Age: 18months - 5 years</p>\r\n\r\n<p>Time: 7-5:30 (Monday -Friday)</p>\r\n', 'indivitual', '', 'parttime', '', 'on', '28-05-2019', '', '', '', 'British Columbia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(29, 'Junk Removal & Demolition Services', '', 'Hayden', '<p>Garbage Removal / CleanOuts /Junk</p>\r\n\r\n<p>&bull; Eavestrough Repairs. Eavestrough Cleaning Roof Repairs. Roofing. Roof shoveling</p>\r\n\r\n<p>&bull;Windows and Doors</p>\r\n\r\n<p>&bull; Tree service &lsquo;Tree removal</p>\r\n\r\n<p>&bull;Demolition</p>\r\n\r\n<p>&bull; Scrap Vehicles Car/Truck Free Pick Up</p>\r\n\r\n<p>&bull; Scrap Metal Pick Up City Wide</p>\r\n\r\n<p>&bull; Dump Runs</p>\r\n', 13, 96, 'Vancouver', 'allenhayden448@gmail.com', '', 'Active', '9638527413', 0, 'British Columbia', '', '', '', '', '', 'fulltime', '', '', '29-05-2019', 'I am offering', '', '', '3308 Ash St Vancouver BC V5Z 3E3, British Columbia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(30, 'Professional Cleaner Available', '', 'Hayden', '<p>Diane&#39;s Home Cleaning Services</p>\r\n\r\n<p>Daily-Weekly-Semi-Monthly-Monthly-One Time</p>\r\n\r\n<p>Houses-Apartments-Condo&rsquo;s-Move In&rsquo;s-Move Outs</p>\r\n\r\n<p>Construction &amp; Renovation Clean Up-Office</p>\r\n\r\n<p><strong>Basic Package Description</strong></p>\r\n\r\n<p>Kitchen</p>\r\n\r\n<p>Bathrooms</p>\r\n\r\n<p>Bedrooms</p>\r\n\r\n<p>&nbsp;</p>\r\n', 13, 96, 'Vancouver', 'allenhayden448@gmail.com', '', 'Active', '9638527414', 0, 'British Columbia', '', '', '<p>Kitchen</p>\r\n\r\n<p>-wipe down all counters and kitchen table</p>\r\n\r\n<p>-wipe down the outsides of all appliances</p>\r\n\r\n<p>-clean the inside of microwave</p>\r\n\r\n<p>-wash dishes/load dishwasher</p>\r\n\r\n<p>-sweep &amp; mop</p>\r\n\r\n<p>-empty garbage</p>\r\n\r\n<p>Bathrooms</p>\r\n\r\n<p>-wipe down all counters, sinks, mirrors and faucets</p>\r\n\r\n<p>-sanitize and wipe toilet</p>\r\n\r\n<p>-do a light scrub of showers and bathtubs</p>\r\n\r\n<p>-empty garbage</p>\r\n\r\n<p>-sweep &amp; mop</p>\r\n\r\n<p>Bedrooms</p>\r\n\r\n<p>-beds made(linen changed upon request)</p>\r\n\r\n<p>-lamps cleaned and lamp shades dusted</p>\r\n\r\n<p>-picture frames dusted</p>\r\n\r\n<p>-furniture dusted-top, front and underneath</p>\r\n', 'indivitual', '', 'contract', '', 'on', '29-05-2019', '', '', '', '2485 Broadway W 414 Vancouver BC V6K 2E8, British Columbia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(31, 'Music entertainment - A live duo with a full band sound', '', 'Hayden', '<p>We are OnePlusOne - a couple of guys who love to make music. We pride ourselves on a wide repertoire of great tunes, excellent harmonies, and a fun time for all.</p>\r\n\r\n<p>We can set up in your living room, your lounge, your dance hall, or on your patio, and provide music for practically any audience.</p>\r\n\r\n<p>With everything from country to rock, Van Morrison to the Northern Pikes, we will entertain your family and friends at an affordable price.</p>\r\n', 13, 97, '4654 Granville St', 'allenhayden448@gmail.com', '', 'Active', '902-442-5916', 0, 'Halifax', '', '', '', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '4654 Granville St, Halifax, Nova Scotia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(32, 'BEST Female magician', '', 'Hayden', '<p>Your Only Female Magician, That Provides Everything for your Parties!</p>\r\n\r\n<p>Book with the professionals that have over 20 years of experience.</p>\r\n\r\n<p>We&#39;ll make your party everything you wanted it to be!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', 13, 97, '1133 West River Station Rd', 'allenhayden448@gmail.com', '', 'Active', '902-442-5916', 0, 'Brookland', '', '', '<p>Do you need a birthday party with everything?</p>\r\n\r\n<p>I can perform a magic show, host birthday party games, face paint, make balloon sculptures, and/or glitter tattoos. I can MC your birthday party if you would like. Check my packages below to meet the needs of your party!</p>\r\n', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '4654 Granville St, Halifax, Nova Scotia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(33, 'Fitness Classes', '', 'Anna', '<p>Fitness classes in Kitchener and Ontario</p>\r\n\r\n<p>These classes will run until early June then resume in September</p>\r\n\r\n<p>Sign up with Zumba and Fitness Classes</p>\r\n\r\n<p>To get more information, please fill the contact form</p>\r\n', 13, 99, '4039 Water Street', 'annaclark251@gmail.com', '', 'Active', '519-783-3007', 0, 'Kitchener', '952097960', '', '<p>Zumba</p>\r\n', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '4039 Water Street, Kitchener, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(34, 'Looking for a private personal trainer to train me in my home', '', 'Anna', '<p>I looking for a certified personal trainer to train my in my home three times a week using equipment I have and run with me outside and help me get in better shape reasonably quickly.</p>\r\n', 13, 99, '4234 Boulevard Cremazie', 'annaclark251@gmail.com', '', 'Active', '418-808-6523', 0, 'Quebec', '', '', '', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '4234 Boulevard Cremazie, Quebec', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(35, 'INDIAN FOOD: Chawla Family\'s Catering and Tent', '', 'Anna', '<p>Only Vegetarian:</p>\r\n\r\n<p>Restaurant Style Food at Your Place 306-898-8610</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>With 30 years of restaurant experience from home country and Gurdwara Langri, we would like to offer you our family based catering services for all your religious events such as Akand path, Sukhmani Sahib, Pooja/Path, Picnic Parties, Community Events/Conferences, wedding, birthday party, anniversaries, showers, engagement, Ladies Sangeet, and all other homely events. Our team can cook and serve you fresh, delicious and qualitative types of Indian dishes, snacks, tea, breakfast etc. for guests ranging from 50-250 easily with pleasure. We can come to your place to take care of your large scale cooking needs like wedding shower Bhaji (Ladoo, Shakarpara, Seviyan etc).</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>20x20ft Tent, Table and Chairs Service available too. Beautiful 20x20 or 15x10 white tent for rent with windows and even a door entrance. Good for outdoor parties, family gatherings, etc. Please contact us for rental and more information.</p>\r\n\r\n<p>In our Snack catering service, we offer you your choice of 4 snack items including tea and soft drinks.</p>\r\n\r\n<p>In our Lunch/Dinner catering service we offer 8 items (your choice of two vegetables, Daal, Raita, Rice, Salad, Dessert or your choice and Roti/Naan)</p>\r\n', 13, 100, '2375 St. John Street', 'annaclark251@gmail.com', '', 'Active', '306-898-8610', 0, 'Bredenbury', '', '', '<p>Snack Menu: (Pick any 4 items)</p>\r\n\r\n<p>1. Vege Pakora</p>\r\n\r\n<p>2. Samosa</p>\r\n\r\n<p>3. Spring Roll</p>\r\n\r\n<p>4. Aloo Tikki</p>\r\n\r\n<p>5. Channa Chaat</p>\r\n\r\n<p>6. Bread Pakora</p>\r\n\r\n<p>Drinks:</p>\r\n\r\n<p>1. Tea</p>\r\n\r\n<p>2. Soft Drinks</p>\r\n\r\n<p>3. Juice</p>\r\n\r\n<p>Try Our Lunch Menu:</p>\r\n\r\n<p>1. Shahi Paneer</p>\r\n\r\n<p>2. Mixed Vegetable</p>\r\n\r\n<p>3. Aloo Gobi</p>\r\n\r\n<p>4. Sholay Paneer</p>\r\n\r\n<p>Roti, Naan, Parantha, Stuffed Parantha, Missi Roti, Poori</p>\r\n\r\n<p>Dessert Menu:</p>\r\n\r\n<p>1. Badaam Kheer</p>\r\n\r\n<p>2. Gajar Halwa</p>\r\n\r\n<p>3. Ras Malai</p>\r\n\r\n<p>4. Gulab Jamun</p>\r\n\r\n<p>5. Sooji Khoa Halwa</p>\r\n\r\n<p>6. Sooji Kheer</p>\r\n', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '2375 St. John Street, Bredenbury, Saskatchewan', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(36, 'Indian Food Catering', '', 'Anna', '<p>Menu:</p>\r\n\r\n<p>1 ) Different types of Vada</p>\r\n\r\n<p>2) Chicken biriyani</p>\r\n\r\n<p>3)Chicken fried rice</p>\r\n\r\n<p>4)variety rice (Lemon rice , Curd rice ,Sambar rice,tamarind rice )</p>\r\n\r\n<p>5)Oil parotta &amp; Chicken salna OR veg curry</p>\r\n\r\n<p>Sweets:</p>\r\n\r\n<p>1)Kesari</p>\r\n\r\n<p>2)Sweet pongal</p>\r\n\r\n<p>Order on weekdays and get it delivered in weekends</p>\r\n\r\n<p>Please contact :</p>\r\n\r\n<p>Contact No: 506-939-1288</p>\r\n\r\n<p>Contact person: Darshana</p>\r\n', 13, 100, '4393 Ross Terrasse', 'annaclark251@gmail.com', '', 'Active', '506-939-1288', 0, 'Sackville', '', '', '', 'indivitual', '', 'contract', '', 'on', '29-05-2019', '', '', '', '1325 47th Avenue, Beaver Creek, Yukon', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(37, 'Special price facials and therapeutic massage', '', 'Anna', '<p>I have been in the Beauty health Spa industry business for over 18 years. I am a certified Esthetician and RMT with 2200 hours Qualification, a specialist in professional facials and therapeutic massage.( Business In varsity NW) .</p>\r\n\r\n<p>My clinic is approved by the City of Calgary and Health Canada. I will provide free evaluation on your skin condition and assist you to select the best facial procedures:</p>\r\n\r\n<p>Laser Hair Removal and Laser for Skin rejuvenation;</p>\r\n\r\n<p>IPL Leg Vein Removal;</p>\r\n\r\n<p>IPL Skin Renewal - Pigmented Lesions &amp; Fine Lines;</p>\r\n\r\n<p>IPL Skin Resurfacing - Wrinkles Fractional;</p>\r\n\r\n<p>European Facial;</p>\r\n\r\n<p>Anti Aging Facial or Microneedling;</p>\r\n\r\n<p>Acne treatment Facial;</p>\r\n\r\n<p>Scraping therapy for essential oil(facial and eyes);</p>\r\n\r\n<p>Oxygen injection treatment;</p>\r\n\r\n<p>Radiofrequency treatment;</p>\r\n\r\n<p>Aromatherapy ear candle therapy;</p>\r\n\r\n<p>Moles removal.</p>\r\n\r\n<p>If you have any muscle pain or your body experience following symptoms, we provide therapeutic massage</p>\r\n\r\n<p>-- lymphatic drainage massage .</p>\r\n\r\n<p>--Tennis elbow</p>\r\n\r\n<p>--Cervical vertebra disease</p>\r\n\r\n<p>--Sciatic pain</p>\r\n\r\n<p>--Headache</p>\r\n\r\n<p>--acute strain of lumbar muscles</p>\r\n\r\n<p>--chronic strain of lumbar</p>\r\n\r\n<p>--Arthritis-</p>\r\n\r\n<p>-Carpal tunnel syndrome.</p>\r\n', 13, 101, '2239 Richford Road', 'annaclark251@gmail.com', '', 'Active', '450-246-8228', 0, 'Lacolle', '', '', '<p>Please book an appointment by text , new patients receive 30% discount by mentioning this ad. 450-246-8228</p>\r\n', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '4841 Pond Rd, Rocky Harbour, Newfoundland and Labrador', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(38, 'Aroma Beauty Spa- Brazilian, body waxing, facial, threading', '', 'Anna', '<p>Dear Ladies,</p>\r\n\r\n<p>Aroma Beauty Spa is a Licensed and Full private home based salon.</p>\r\n\r\n<p>We are approved by Alberta Health Services.</p>\r\n\r\n<p>High quality products and wax used.</p>\r\n\r\n<p>Taking proper care of your personal hygiene.</p>\r\n\r\n<p>Quick in waxing.</p>\r\n\r\n<p>Affordable / cheap / reasonable price.</p>\r\n\r\n<p>FLEXIBLE TIME !! ONLY FOR FEMALES!!</p>\r\n\r\n<p>For appointment please text or call 506-210-6802</p>\r\n', 13, 101, '4768 Mountain Rd', 'annaclark251@gmail.com', '', 'Active', '506-210-6802', 0, 'Chatham', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '2239 Richford Road, Lacolle, Quebec', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(39, 'RIGHT MOVE - MOVING ', '', 'Simon', '<p>Hi! Are you moving in Edmonton, or the Surrounding Area? Or maybe to BC, SK, MB, ON, NS, or the US?</p>\r\n\r\n<p>If so, call Right Move today at 416-567-2892.</p>\r\n\r\n<p>Whether it&#39;s a Local, or Long Distance move across Canada, our moving company has many years experience in providing top quality moving services. If you&#39;re in need of an International move, we can do that too.</p>\r\n\r\n<p>PROMOTION</p>\r\n\r\n<p>Get One Month&#39;s Free Storage at our Secure Storage Facility which is Large, Clean, and Climate-Controlled!</p>\r\n\r\n<p>DISCOUNTS</p>\r\n\r\n<p>We offer special discounts for:</p>\r\n\r\n<p>- Seniors</p>\r\n\r\n<p>- Students</p>\r\n\r\n<p>- Military</p>\r\n\r\n<p>- Fire Fighters</p>\r\n\r\n<p>- Police Personnel</p>\r\n', 13, 102, '2473 Islington Ave', 'simonmoore921@gmail.com', '', 'Active', '416-567-2892', 0, 'Toronto', '', '', '<p>Full or Partial Packing and Unpacking services.</p>\r\n\r\n<p>- Loading / Unloading services.</p>\r\n\r\n<p>- Free Box Delivery to your home.</p>\r\n', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '243 Heritage Drive, Calgary, Alberta', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(40, 'OGT Moving And Storage - OGT Movers', '', 'Simon', '<p>No hidden fees for anything! Your choice of hourly or flat rate</p>\r\n\r\n<p>EQUIPMENT ON OUR TRUCK FREE OF CHARGE:</p>\r\n\r\n<p>Moving blankets to protect furniture and breakables</p>\r\n\r\n<p>Mattress bags to protect beds from dirt and water</p>\r\n\r\n<p>Floor mats to protect your hardwood or carpet</p>\r\n\r\n<p>Padding to protect railings and door frames</p>\r\n\r\n<p>4 wheeled dollies to speed up the moving process</p>\r\n\r\n<p>Straps for carrying heavy furniture</p>\r\n\r\n<p>Straps for securing items on the truck</p>\r\n\r\n<p>Tape for closing boxes or securing miscellaneous items</p>\r\n\r\n<p>Shrink wrap to secure doors on cabinets, dressers or buffet and hutch</p>\r\n\r\n<p>Tools for disassembly and reassembly</p>\r\n\r\n<p>Wardrobe boxes for clothes on hangers</p>\r\n\r\n<p>Boxes for last minute items</p>\r\n', 13, 102, '13 St Marys Rd', 'simonmoore921@gmail.com', '', 'Active', '204-975-3988', 0, 'Winnipeg', '', '', '<p>Free overnight storage on our truck!</p>\r\n\r\n<p>Free short term storage!</p>\r\n\r\n<p>Free cancellation anytime!</p>\r\n', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '13 St Marys Rd, Winnipeg, Manitoba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(41, 'Music Lessons by a working musician', '', 'Simon', '<p>I&#39;m now taking guitar, bass and drum students of all ages from beginner to advanced, I&#39;m a working professional musician / music teacher, I guarantee I can have you playing your favorite songs as well as learning to read music in a couple months. I&#39;ve developed a method that has been taught to many of the working musicians in Essex county and all while having fun at the same time .</p>\r\n\r\n<p>You&#39;ll also be surrounded by some of the latest recording equipment at the same time. I really look forward to hearing from you and as well as sharing the gift of music. Lessons are a half hour in length at a cost of $22.00.&nbsp;</p>\r\n', 13, 103, '1303 49th Avenue', 'simonmoore921@gmail.com', '', 'Active', '867-370-2975', 0, 'Lutselk', '', '', '', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '1303 49th Avenue, Lutselk, Northwest Territories', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(42, 'Violin and Piano Lessons', '', 'Simon', '<p>Looking for violin or piano teacher to involve your child to summer activities? Or you want to improve your skills? Need help with doing summer music homework for school?</p>\r\n\r\n<p>I&#39;m here to help! You just need instrument and some music books to have this summer full of new experience!</p>\r\n\r\n<p>Violin and piano teacher with Russian Master&#39;s Degree provides private lesson for ages 6-100.</p>\r\n\r\n<p>10+ years of teaching experience in Russia and Canada.</p>\r\n\r\n<p>Prices:</p>\r\n\r\n<p>30min $25</p>\r\n\r\n<p>45min $30</p>\r\n\r\n<p>1hour $35</p>\r\n', 13, 103, '3520 Wallace Street', 'simonmoore921@gmail.com', '', 'Active', '250-616-9949', 0, ' Nanaimo', '', '', '', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '3520 Wallace Street, Nanaimo, British Columbia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(43, 'PHOTO AND VIDEO GRAPHER ', '', 'Simon', '<p>Best photographer and videographer</p>\r\n\r\n<p>We specialize in weddings photography and videography.</p>\r\n\r\n<p>We offer high quality pictures and videos.</p>\r\n\r\n<p>Feel free to conatct&nbsp;for more information and availability.</p>\r\n\r\n<p>Let us help you capture the moment!</p>\r\n', 13, 104, '2700 Carter Crescent', 'simonmoore921@gmail.com', '', 'Active', '902-971-1407', 0, 'Antigonish', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '3596 Lynden Road, Gormley, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(44, 'Professional Photography & Video Services', '', 'Simon', '<p>Providing Professional Photography and Video services across the GTA. If you have a vision let us help create it through our creative eyes and amazing team. We strive to provide our clients with nothing but the best in class customer service and final product where we&#39;d love to help promote the video on our social media pages for added awareness. Lets create some memories!</p>\r\n\r\n<p>Corporate events</p>\r\n\r\n<p>Birthday parties</p>\r\n\r\n<p>Wedding functions</p>\r\n\r\n<p>Automotive Media</p>\r\n\r\n<p>Models</p>\r\n\r\n<p>Product Shoots</p>\r\n\r\n<p>&nbsp;</p>\r\n', 13, 104, '3596 Lynden Road', 'simonmoore921@gmail.com', '', 'Active', '905-927-4048', 0, 'Gormley', '', '', '', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '2700 Carter Crescent, Antigonish, Nova Scotia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(45, 'Appliance Repair and installation', '', 'Emile', '<p>Visit our website https://www.appliancesssolutions.ca/</p>\r\n\r\n<p>Appliance repair, service and installation . Posted in skilled trades, appliance repair, installation in Kitchener / Waterloo.</p>\r\n\r\n<p>Call us for reliable service of Repairs and installation:</p>\r\n\r\n<p>Washer</p>\r\n\r\n<p>Dryer</p>\r\n\r\n<p>Fridge</p>\r\n\r\n<p>Range/oven/stove</p>\r\n\r\n<p>Dishwasher</p>\r\n\r\n<p>Microwave</p>\r\n\r\n<p>Range hoods</p>\r\n', 13, 105, '1137 49th Avenue', 'emilelee69@gmail.com', '', 'Active', '867-645-8040', 0, 'Rankin Inlet', '1007632095', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '1137 49th Avenue, Rankin Inlet, Nunavut', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(46, 'Skilled trade or general labour cash work wanted	', '', 'Emile', '<p>I&#39;m 34 year old man, very physically active and am in shape with a great work ethic.</p>\r\n\r\n<p>Laid off for a couple months till end of June and am looking for any type of cash work . I&#39;m in hvac by trade and have a g2 gas ticket as well as 4 years into my refrigeration/ air conditioning ticket.</p>\r\n\r\n<p>Have lots of other work experience like drywalling, general labour, electrical and trouble shooting, manufacturing . Even if you need help moving if the money is right I&#39;ll do it. I have my own car . Any questions or enquiries give me a text or call at 250-961-2234 or send a reply.</p>\r\n', 13, 105, '251 Carlson Road', 'emilelee69@gmail.com', '', 'Active', '250-961-2234', 0, 'Prince George', '', '', '', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '251 Carlson Road, Prince George, British Columbia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(47, 'Vacation Place Sell Off List', '', 'Emile', '<p>I am a member of several travel clubs. I get an updated sell-off list every few weeks of the resort list. If you would like me to forward you the list i get, email myself and ill forward it to you. If you see something you like email me back and ill book it for you as my guest to get that rate quoted. It costs you nothing extra and i help the vacation clubs i belong to sell off their extra inventory mainly the lodging itself, and makes me look good, and helps me get better deals as well. I will not rent or sell your email, i am not a business, just a consumer, who bought into membership programs and can offer it to others as well. Ad is current still, as new resorts and different weeks change all the time. Thank you.</p>\r\n', 13, 108, '4781 Wascana Parkway', 'emilelee69@gmail.com', '', 'Active', '306-585-3253', 0, 'Regina', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '4781 Wascana Parkway, Regina, Saskatchewan', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(48, 'Planning to travel soon - Need Travel Insurance!!', '', 'Emile', '<p>TRAVEL INSURANCE</p>\r\n\r\n<p>Are you planning for vacation on a short term or long term journey? There is a need for travel insurance to supplement your Provincial Health plan.</p>\r\n\r\n<p>To ensure you and your family have a safety trip while you&rsquo;re away.</p>\r\n\r\n<p>Are you travelling for vacation or business abroad from Canada?</p>\r\n\r\n<p>Are you a Canadian Student attending school or university abroad?</p>\r\n\r\n<p>Are you an International Student attending school or university in Canada?</p>\r\n\r\n<p>Are you parent/grandparent applying for SuperVisa?</p>\r\n\r\n<p>We offer Canada&rsquo;s best travel insurance &ndash; available at your fingertips, right here.</p>\r\n\r\n<p>Coverage</p>\r\n\r\n<p>Emergency Medical Insurance</p>\r\n\r\n<p>Trip Cancellation &amp; Interruption Insurance</p>\r\n\r\n<p>Baggage Loss, Damage, &amp; Delay</p>\r\n\r\n<p>Flight Accident &amp; Travel Accident</p>\r\n\r\n<p>Travel Insurance for International Students</p>\r\n', 13, 108, '3143 Pownal Road', 'emilelee69@gmail.com', '', 'Active', '902-368-2694', 0, 'Alexandra', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '3143 Pownal Road, Alexandra, Prince Edward Island', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(49, 'Programming Tutor (College / University) $25/hr', '', 'Emile', '<p>BSc in Computer Science graduate with professional experience.</p>\r\n\r\n<p>Offer consultation in various programming languages (Python, C, C++, Java, Javascript, etc...)</p>\r\n\r\n<p>Offer project management and assignment review.</p>\r\n\r\n<p>Offer tutoring sessions at Ottawa, Carleton and Algonquin</p>\r\n\r\n<p>Reply to this ad with your concerns for an accurate quote.</p>\r\n', 13, 106, '2678 40th Street', 'emilelee69@gmail.com', '', 'Active', '403-236-9894', 0, 'Calgary', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '2678 40th Street, Calgary, Alberta', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(50, 'Software, Virtualization, Web, Graphic, SQL, Programming', '', 'Emile', '<p>I am a network specialist and a programmer who can help you with all programming languages (Java, HTML, PHP, ASP, C#, C++, C, Python, jQuery &amp; JavaScript), Docker, .JS, TCP/IP, MVC, SDLC, UML, etc.), all virtualization (Vmware &amp; Oracle), All Database (MMSQL &amp; MySQL) Applications, Web Development and Graphic Design.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Please contact me if you are interested.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Solve assignments? Sure, pls send me yours to review and I will return with a quote.</p>\r\n', 13, 106, '3928 Factory Lane', 'emilelee69@gmail.com', '', 'Active', '709-530-1458', 0, 'Lumsden', '', '', '', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '2119 Appledore Ln, Alexandra, Prince Edward Island', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(51, 'Wedding and Party Decor', '', 'Emile', '<p>Get Creative!! DIY Backdrops for Rent.</p>\r\n\r\n<p>Includes:</p>\r\n\r\n<p>Backdrop Frame</p>\r\n\r\n<p>Accessories</p>\r\n\r\n<p>8 drapes</p>\r\n\r\n<p>Price:$200</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Creativity is not your thing? No worries, we offer this service starting at $300.00.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Rental:</p>\r\n\r\n<p>Centrepieces</p>\r\n\r\n<p>Cake Stands</p>\r\n\r\n<p>Seqince Table Cloths</p>\r\n\r\n<p>Silk Flowers arrangement</p>\r\n\r\n<p>Backdrop frames</p>\r\n\r\n<p>Sofa</p>\r\n\r\n<p>Flower Wall</p>\r\n\r\n<p>Candelabras Gold/Silver</p>\r\n\r\n<p>and much more</p>\r\n\r\n<p>Services Offered by our Company:</p>\r\n\r\n<p>Wedding Decor</p>\r\n\r\n<p>Birthday Decor</p>\r\n\r\n<p>Bridals Showers Decor</p>\r\n\r\n<p>Baby Showers Decor</p>\r\n\r\n<p>Balloon Backdrop Decor</p>\r\n\r\n<p>All Balloon service</p>\r\n\r\n<p>Custom Cakes/Cupcake/Cakepop</p>\r\n', 13, 107, '20 Bloor Street', 'emilelee69@gmail.com', '', 'Active', '780-386-8562', 0, 'Lougheed', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '3944 2nd Street, Gimli, Manitoba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(52, 'Wanted: Winnipeg Indian community', '', 'Emile', '<p>My beautiful bride to be is Indian and not from winnipeg while I am not Indian and from Winnipeg.</p>\r\n\r\n<p>Unfortunately all of her friends are unable to attend the wedding and sangeeth due to various travel and visa issues.</p>\r\n\r\n<p>I would love to exceed her current expectations for the sangeeth by surprising her with some people from the local Indian community!</p>\r\n\r\n<p>Our sangeeth is June 7th - if you would like to show my wife to be why winnipegers are great - please come and enjoy some food and drinks and fun and dancing!</p>\r\n', 13, 107, '1846 St Marys Rd', 'emilelee69@gmail.com', '', 'Active', '204-293-2775', 0, 'Winnipeg', '', '', '', 'indivitual', '', 'contract', '', 'on', '29-05-2019', '', '', '', '4608 James Street, St Catharines, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(53, 'Hindu Puja Priest - Pandit Sharma Ji', '', 'Louis', '<p>Call me for Indian Wedding | Greh Pravesh | Namkaran Puja | Satya Narayan Katha | Gita Path | Ganesh chaturthi Puja | Diwali Lakshmi Puja.</p>\r\n\r\n<p>I will explain all rituals in English for you to understand deeper meaning of the Puja. I also speak Hindi and Gujarati.</p>\r\n\r\n<p>Servicing GTA and willing to travel further. I have retired from my multi national job and following my passion and tradition of my family, of being a Pandit.</p>\r\n', 13, 109, '3578 Sheppard Ave', 'joneslouis620@gmail.com', '', 'Active', '647-321-4600', 0, 'Toronto', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '3578 Sheppard Ave, Toronto, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(54, 'PROM DRESS / BRIDESMAID', '', 'Louis', '<p>If you are not happy with your prom or bridesmaids dress or want to have your wedding outfit make you feel special on that big day call Alterations Idea at 780-675-8256. &nbsp;I also specialize in wedding gowns and outfits for special occasions.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Alterations offered, among other sewing services:</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Wedding gowns/ Bridesmaid dresses</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Proms / Special occasion outfits</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Men&rsquo;s suit jackets and pants</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ladies&rsquo; formal gowns and casual dresses</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Repair other clothing items</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Other special sewing requests</p>\r\n', 13, 109, '3453 Venture Place', 'joneslouis620@gmail.com', '', 'Active', '780-675-8256', 0, 'Athabasca', '', '', '<p>Hours:&nbsp;&nbsp; Mondays to Fridays 10 a.m. &ndash; 8 p.m.</p>\r\n\r\n<p>Saturdays 10 a.m. &ndash; 2 p.m.</p>\r\n\r\n<p>Closed on Sundays</p>\r\n', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '3453 Venture Place, Athabasca, Alberta', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(55, 'Hiring cook / line cook with breakfast and lunch experience', '', 'Louis', '<p>Hiring cook / line cook with breakfast and lunch experience !. Posted in jobs, bar, food, hospitality in Kitchener / Waterloo.&nbsp;</p>\r\n', 12, 78, '2111 11th Ave', 'joneslouis620@gmail.com', '', 'Active', '403-233-4426', 0, 'Calgary', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '2111 11th Ave, Calgary, Alberta', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(56, 'Line Cook', '', 'Louis', '<p>Do you have a passion for food, hospitality and service excellence ? Do you want to work in an exciting and fast-paced environment?</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>You will have the opportunity to be on a team of talented and driven associates who are passionate about food, hospitality, and service excellence while working in a fun, dynamic, and fast-paced team environment. Throughout your career you will have the opportunity to take on new and exciting challenges not only within Montana&#39;s, but also the CARA group of restaurants. You will be a significant member of one of the largest and most successful restaurant companies in Canada.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Qualifications:</p>\r\n\r\n<p>-Food Service/Hospitality Experience</p>\r\n\r\n<p>-Must have a love of food and strive for culinary excellence</p>\r\n\r\n<p>-Driven and focused</p>\r\n\r\n<p>-Inspirational/Motivational</p>\r\n\r\n<p>Please apply within or email resume to montanasss1231@hotmail.com Priority to those who have kitchen experience.</p>\r\n', 12, 78, '500 Shaughnessy St', 'joneslouis620@gmail.com', '', 'Active', '604-942-2412', 0, 'Port Coquitlam', '', '', '', 'non_indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '500 Shaughnessy St, Port Coquitlam, British Columbia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(57, 'Accounting Assistant ', '', 'Louis', '<p>Position: Administrative Assistant (Accounting)</p>\r\n\r\n<p>Industry: Property Management (Residential)</p>\r\n\r\n<p>Job Responsibilities:</p>\r\n\r\n<p>Obtains revenue and pays invoices by verifying and completing payable and receivable transactions in a deadline driven environment.</p>\r\n\r\n<p>Job Duties:</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Prepares work to be accomplished by gathering and sorting documents and related information.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Process invoices by verifying transaction information and obtaining authorization of payment.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Obtains revenue by verifying transaction information; computing charges and refunds; preparing and mailing invoices.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Collects revenue by reminding delinquent accounts; notifying customers of insufficient payments.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Prepares financial reports by collecting, analyzing, and summarizing account information and trends.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Maintains accounting ledgers by posting account transactions.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Verifies accounts by reconciling statements and transactions.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resolves account discrepancies by investigating documentation.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Maintains financial security by following internal accounting controls.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Maintains financial historical records by filing accounting documents.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Contributes to team effort by accomplishing related tasks as needed.</p>\r\n\r\n<p>Qualifications:</p>\r\n\r\n<p>Accounting Fundamentals, Administrative Writing Skills, Organization, Data Entry Skills, General Math Skills, Financial Software, Microsoft Word and Excel proficiency, Analyzing Information, Attention to Detail, Thoroughness, Verbal/ Written Communication in English necessary, Yardi knowledge preferably.</p>\r\n', 12, 76, '3653 St Marys Rd', 'joneslouis620@gmail.com', '', 'Active', '204-952-4345', 0, 'Winnipeg', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '3653 St Marys Rd, Winnipeg, Manitoba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(58, 'Book Keeper/Accountant', '', 'Louis', '<p>Job Description</p>\r\n\r\n<p>Responsibilities:</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Preparation of varying reports on a weekly and monthly basis to support local management team</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Experienced in performing all accounting functions (journal entries, payroll, accounts payable, accounts receivable and reporting)</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ensuring rapid and consistent collection of receivables</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Assist in year-end preparation and audit</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Support and assist in preparation of detailed estimates</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Completes payments and controls expenses by monitoring discount opportunities, receiving, processing, verifying, and reconciling invoices and resolving payment discrepancies</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Oversight of payroll functions,</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ensuring statutory compliance incl: HST, payroll, WSIB and other related matters</p>\r\n\r\n<p>Requirements:</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Must be able to follow instructions</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Post Secondary Accounting Degree or diploma</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Excellent oral and written communication skills</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Highly organized and strong problem solving skills</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Possess strong communication and interpersonal skills</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hands on experience with Simply Accounting</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; PC Proficiency, Data Entry Skills, General Math Skills</p>\r\n\r\n<p>Contact us with your interest by sending a cover letter with your resume.</p>\r\n\r\n<p>Job Type : 2 Days a week (16hrs a week)</p>\r\n', 12, 76, '377 Prince William', 'joneslouis620@gmail.com', '', 'Active', '506-512-8272', 0, 'Saint John', '', '', '', 'indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '377 Prince William, Saint John, New Brunswick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(59, 'Looking for child care', '', 'Louis', '<p>Hello everyone. My name is Heli. I&rsquo;m 24 years old. I&rsquo;m looking to provide childcare in my home. I&rsquo;m a mom of a 15 month old baby boy.</p>\r\n\r\n<p>I have tons of experience of watching children of all ages. I have my first aid, CPR, whims, and food handlers course done. My house is fully baby proofed.</p>\r\n\r\n<p>I have educational children&rsquo;s shows and a house full of toys. As well, my back yard is fully fenced and full of fun toys.</p>\r\n\r\n<p>If you have any questions, feel free to ask. Thank you!</p>\r\n', 12, 77, '1515 chemin Saint-Ignace', 'joneslouis620@gmail.com', '', 'Active', '506-612-1937', 0, 'Woodstock', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '1515 chemin Saint-Ignace, Woodstock, New Brunswick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `post_ads` (`id`, `title`, `price`, `name`, `description`, `category`, `sub_category`, `location`, `email`, `postal_code`, `status`, `contact`, `state`, `city`, `password`, `pro_pic`, `features`, `job_offer`, `company`, `job_type`, `web_url`, `terms_check`, `entry_date`, `AdType`, `SaleBy`, `urgentprice`, `address`, `youtube_url`, `priceoption`, `Bedrooms`, `Bathrooms`, `PetFriendly`, `Furnished`, `RentBy`, `Make`, `Model`, `Trim`, `Year`, `Kilometers`, `BodyType`, `Transmission`, `Drivetrain`, `Colour`, `FuelType`, `Doors`, `Seats`, `companyoption`) VALUES
(60, 'Full Time Staff Required for Child care', '', 'Louis', '<p>We are currently hiring responsible, reliable and energetic child care staff with level III (Child Development Supervisor) for our fully licensed and accredited childcare (includes Preschool / BAS Programs).</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Interested candidate must have the following qualifications!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&bull; Child Development Supervisor certificate &ndash; (Level III)</p>\r\n\r\n<p>&bull; Suitable candidates with Child Development Worker Certificate (Level II) having relevant experience can be considered</p>\r\n\r\n<p>&bull; Relevant child care experience with knowledge of child care regulations</p>\r\n\r\n<p>&bull; Able to engage children with different activities</p>\r\n\r\n<p>&bull; Able to work independently with minimum supervision</p>\r\n\r\n<p>&bull; Criminal record check</p>\r\n\r\n<p>&bull; Valid first aid certificate</p>\r\n\r\n<p>&bull; Must be flexible, hard working and able to work in a team environment</p>\r\n\r\n<p>&bull; We offer competitive wages with opportunities for advancement.</p>\r\n', 12, 77, '4480 Higginsville Road', 'joneslouis620@gmail.com', '', 'Active', '902-256-8867', 0, 'Mount Uniacke', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '4480 Higginsville Road, Mount Uniacke, Nova Scotia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(61, 'Looking for Housekeeping position ASAP', '', 'Louis', '<p>Hi My name is Malini i am looking for a position as soon as possible for housekeeping.</p>\r\n\r\n<p>I am punctual , reliable, great at cleaning i have experiences 4 years experiences in the field.</p>\r\n\r\n<p>Looking for serious postition only .</p>\r\n\r\n<p>I have previous work references . Fluent in French , English and Creole</p>\r\n', 12, 79, '2742 Bridgeport Rd', 'joneslouis620@gmail.com', '', 'Active', '519-943-5454', 0, 'Orangeville', '', '', '', 'indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '2742 Bridgeport Rd, Orangeville, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(62, 'Housekeeper cleaning help $20 an hour', '', 'Louis', '<p>I need help in the kitchen and general housekeeping we are senior citizens and willing to pay $20 an hour</p>\r\n', 12, 79, '4459 49th Avenue', 'joneslouis620@gmail.com', '', 'Active', '867-975-9867', 0, 'Iqaluit', '', '', '', 'non_indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '4459 49th Avenue, Iqaluit, Nunavut', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(63, 'CONSTRUCTION & TRADES JOBS AVAILABLE', '', 'Louis', '<p>Construction and trades businesses across the city have Full-time and Part-time laborer, construction worker, welders, mechanics, installers, and roofers jobs.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>DUTIES</p>\r\n\r\n<p>- Depending on job, perform work assigned: general labour help, installing, sorting, move goods, make repairs accessories (as required) and perform any other related trades duties of the job.</p>\r\n\r\n<p>- must be quick, self organized, have a good professional attitude towards residents and staff.</p>\r\n\r\n<p>- Must be punctual, reliable and have a flexible work schedule</p>\r\n\r\n<p>- Ability to use and operate all required equipment.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>REUIREMENTS</p>\r\n\r\n<p>- Must have excellent communication skills, problem solving skills, and must be able to motivate staff.</p>\r\n\r\n<p>- able to apply due diligence ensuring accuracy in preparing and promptly completing all necessary documentation for projects and time-sheets</p>\r\n\r\n<p>- well organized and be able to work well individually and as part of a team</p>\r\n\r\n<p>- Must be punctual, reliable and have a flexible work schedule</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>COMPENSATION</p>\r\n\r\n<p>- Flexible scheduling</p>\r\n\r\n<p>- Competitive Wages &amp; Benefits Package</p>\r\n', 12, 80, '4184 Pownal Road', 'joneslouis620@gmail.com', '', 'Active', '902-368-2510', 0, 'Alexandra', '', '', '', 'non_indivitual', '', 'fulltime', '', 'on', '29-05-2019', '', '', '', '4184 Pownal Road, Alexandra, Prince Edward Island', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(64, 'Trades Persons Needed', '', 'Louis', '<p>Do you want to work on the most exciting new construction project?</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Are you a leader and Mentor looking for an opportunity to gain new experience and pass on your knowledge those that report to you? Are you a self-motivated, creative individual who thrives on making responsible decisions under pressure? Do you truly enjoy the personal interaction that naturally occurs when leading a team? Do you believe in the power of proper planning and clear communication with the members of your team to drive projects to the best possible outcome? Do you excel at problem solving and decision making in a fast paced environment? If so, we want you to join our team as we continue to steer our company to be best in class.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>We are Hiring trades and labor to construct a large hotel in Nova Scotia.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Proud to be 100% Canadian-owned and operated, with over 150 outlets nationwide, we have home offices in both Vancouver and Calgary and employ over 10,000 talented individuals across the nation.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>What Will Make You Successful in this Role?</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Positive Attitude.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Punctual.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hard Working.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Experience in concrete construction.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ability to work independently and as part of a team.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; WHMIS training.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Working at Heights.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ability to work effectively in various climate conditions, good manual dexterity, physical strength and stamina</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Good understanding of safety policies, and safe work practices.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Able to work independently, manage time effectively, and work with multiple deadlines.</p>\r\n\r\n<p>&bull;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Strong written and verbal communication, as well as interpersonal skills</p>\r\n', 12, 80, '3002 Granville St', 'joneslouis620@gmail.com', '', 'Active', '902-877-5501', 0, 'Halifax', '', '', '', 'non_indivitual', '', 'parttime', '', 'on', '29-05-2019', '', '', '', '3002 Granville St, Halifax, Nova Scotia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(65, 'Truck Driver Needed', '100', 'Hayden', '<p>We are looking for 1 company driver and 1 lease operator. The company driver would be driving a 2000 Kenworth W900L Cat, 18 speed, 6NZ Cat Power. Class 1 drivers licence needed. MUST be able to cross the border and pass a drug test. Minimum 1 year experience. We do mostly van work, some deck work. Good drivers abstract is very important to us. You are home every weekend. Most of our driving is in BC, AB, WA, ID, OR. We have lots of steady work. Extended medical is offered after 6 months. Phone reimbursement every month. Our company prides ourselves on our above average equipment! Drivers all make average pay. Please send in your drivers abstract with your resume!</p>\r\n', 12, 83, '4690 Churchill Plaza', 'allenhayden448@gmail.com', 'P6A 1Z', 'Active', '705-941-1299', 0, 'Sault Ste Marie', '', '', '', 'non_indivitual', 'Transport Services Pvt Ltd', 'contact', 'www.transportservicess.com', 'on', '31-05-2019', '', '', '', '4690 Churchill Plaza, Sault Ste Marie,  Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(66, 'French Bulldog puppies', '2,300.00', 'Vicki J White', '<p>Beautiful French Bulldog puppies born May 20/2019 will be ready to go to their new homes July 15/2019. We got 6 females and 2 males. Our Dam is fawn and the Sire is red fawn. So some puppies are fawn and some are red fawn. Will come with up to date vaccinations, health examined, microchipped and dewormed. French bulldogs are very friendly and love to play and cuddle, barely bark and low shedding.</p>\r\n\r\n<p>Email, Call or text 519-217-2055. Reserve yours with a $300 down payment. New pictures coming soon. Delivery available, please contact for further details.</p>\r\n', 14, 114, '2835 Bridgeport Rd', 'annaclark251@gmail.com', 'L9W 2J', 'Active', '519-217-2055', 0, 'Orangeville', '', '', '', 'indivitual', '', 'contact', '', 'on', '20-06-2019', '', '', '', '2835 Bridgeport Rd, Orangeville, Ontario', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `post_ads_images`
--

CREATE TABLE `post_ads_images` (
  `id` int(11) NOT NULL,
  `image` varchar(256) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_ads_images`
--

INSERT INTO `post_ads_images` (`id`, `image`, `post_id`) VALUES
(1, '1550321979_Koala.jpg', 6),
(2, '1550321979_Lighthouse.jpg', 6),
(3, '1550321979_Penguins.jpg', 6),
(4, '1550321979_Koala.jpg', 6),
(5, '1550321979_Tulips.jpg', 1),
(6, '1550321979_Penguins.jpg', 2),
(7, '1550321979_Koala.jpg', 3),
(8, '1550321979_Lighthouse.jpg', 4),
(9, '1550321979_Tulips.jpg', 5),
(13, '1550826035_addthumble.jpg', 7),
(14, '1550826035_feature_three.jpg', 7),
(15, '1550826035_feature_two.jpg', 7),
(16, '1550826035_ferimg.jpg', 7),
(18, '1551801320_Desert.jpg', 8),
(19, '1551801320_Tulips.jpg', 8),
(20, '1551801320_Jellyfish.jpg', 8),
(24, '1551854825_logo.png', 9),
(25, '1552059084_1444-xmas-wreath-1366x768-holiday-wallpaper.jpg', 10),
(26, '1552059084_2012_colorful_new_year-HD[1].jpg', 10),
(27, '1552059084_2012_madagascar_3-1366x768.jpg', 10),
(28, '1552059084_1324E4202615F-223I[1].jpg', 10),
(29, '1552059084_2012_colorful_new_year-HD[1].jpg', 10),
(30, '1552059084_1444-xmas-wreath-1366x768-holiday-wallpaper.jpg', 10),
(31, '1552059084_2006-1306-49117[1].jpg', 10),
(32, '1552059084_1323R3535F3P-1D50[1].jpg', 10),
(33, '1552059084_1324E4202615F-223I[1].jpg', 10),
(34, '1552735678_1.jpg', 11),
(35, '1552735678_1.jpg', 11),
(36, '1553079311_light-bulb.png', 12),
(37, '1553079311_light-bulb.png', 12),
(38, '1553079311_light-bulb.png', 12),
(39, '1553079311_light-bulb.png', 12),
(40, '1553079311_light-bulb.png', 12),
(41, '1553089100_light-bulb.png', 14),
(42, '1553089100_light-bulb.png', 14),
(43, '1553092560_light-bulb.png', 15),
(44, '1553092560_light-bulb.png', 15),
(45, '1553251768_bg-1.jpg', 16),
(46, '1553251768_bg-2.jpg', 16),
(47, '1553500629_illustration-of-maintenance-with-screwdriver-and-wrench_9638-56.jpg', 17),
(48, '1553500629_illustration-of-maintenance-with-screwdriver-and-wrench_9638-56.jpg', 17),
(49, '1553500629_illustration-of-maintenance-with-screwdriver-and-wrench_9638-56.jpg', 17),
(50, '1553699420_bnr2.jpg', 18),
(51, '1553699420_bnr3.jpg', 18),
(52, '1553699420_bnr3.jpg', 18),
(53, '1553699765_bnr2.jpg', 19),
(54, '1553699765_bnr3.jpg', 19),
(55, '1553772152_illustration-of-maintenance-with-screwdriver-and-wrench_9638-56.jpg', 20),
(56, '1553772152_illustration-of-maintenance-with-screwdriver-and-wrench_9638-56.jpg', 20),
(57, '1553772152_illustration-of-maintenance-with-screwdriver-and-wrench_9638-56.jpg', 20),
(58, '1553777289_bnr1.jpg', 21),
(59, '1553777289_bnr2.jpg', 21),
(60, '1553844900_e1624eb84b0150eed8b5d1bb31ae7387.jpg', 22),
(61, '1553844900_thin-line-style-under-maintenance-message-banner-100071034.jpg', 22),
(62, '1553844900_winbrand_business_name_desing.png', 22),
(63, '1553844900_fresh-vegetables-wallpaper-1.jpg', 22),
(64, '1553845404_intro-illustration.png', 23),
(65, '1553845404_vegetable-png-1732.jpg', 23),
(66, '1553845404_logo profile.jpg', 23),
(67, '1559041129_Financial & Legal1.jpg', 24),
(68, '1559041129_Financial & Legal2.jpg', 24),
(69, '1559041994_Financial & Legal1.jpg', 25),
(70, '1559041994_Financial & Legal2.jpg', 25),
(71, '1559042926_Financial & Legal3.jpg', 26),
(72, '1559042926_Financial & Legal2.jpg', 26),
(73, '1559049552_Childcare & Nanny1.jpg', 27),
(74, '1559049552_Childcare & Nanny2.jpg', 27),
(75, '1559049926_Childcare & Nanny3.jpg', 28),
(76, '1559049926_Childcare & Nanny4.jpg', 28),
(77, '1559109200_Cleaners & Cleaning1.jpg', 29),
(78, '1559109200_Cleaners & Cleaning2.jpg', 29),
(79, '1559109691_Cleaners & Cleaning3.jpg', 30),
(80, '1559109691_Cleaners & Cleaning4.jpg', 30),
(81, '1559110277_Entertainment2.jpg', 31),
(82, '1559110277_Entertainment3.jpg', 31),
(85, '1559110698_Entertainment4.png', 32),
(86, '1559110698_Entertainment5.jpg', 32),
(87, '1559111918_Fitness & Personal Trainer1.jpg', 33),
(88, '1559111918_Fitness & Personal Trainer2.jpg', 33),
(89, '1559112456_Fitness & Personal Trainer3.jpg', 34),
(90, '1559112456_Fitness & Personal Trainer4.jpg', 34),
(91, '1559113413_Food & Catering5.jpg', 35),
(92, '1559113413_Food & Catering4.png', 35),
(93, '1559113923_Food & Catering3.jpg', 36),
(94, '1559113923_Food & Catering1.jpg', 36),
(95, '1559113923_Food & Catering2.jpg', 36),
(96, '1559114474_Health & Beauty2.jpg', 37),
(97, '1559114474_Health & Beauty3.jpg', 37),
(98, '1559114545_Health & Beauty4.jpg', 38),
(99, '1559114545_Health & Beauty5.jpg', 38),
(100, '1559115810_Moving & Storage2.jpg', 39),
(101, '1559115810_Moving & Storage3.jpg', 39),
(102, '1559115919_Moving & Storage4.jpg', 40),
(103, '1559115919_Moving & Storage5.jpg', 40),
(104, '1559119487_Music Lessons1.jpg', 41),
(105, '1559119487_Music Lessons2.jpg', 41),
(106, '1559119604_Music Lessons3.jpg', 42),
(107, '1559119604_Music Lessons4.jpg', 42),
(108, '1559120154_Photography & Video1.jpg', 43),
(109, '1559120154_Photography & Video2.jpg', 43),
(110, '1559120231_Photography & Video3.jpg', 44),
(111, '1559120231_Photography & Video4.jpg', 44),
(112, '1559120947_Skilled Trades1.jpg', 45),
(113, '1559120947_Skilled Trades2.jpg', 45),
(114, '1559121132_Skilled Trades3.jpg', 46),
(115, '1559121132_Skilled Trades5.jpg', 46),
(116, '1559121763_Travel & Vacations1.jpg', 47),
(117, '1559121763_Travel & Vacations2.jpg', 47),
(118, '1559122013_Travel & Vacations3.jpg', 48),
(119, '1559122013_Travel & Vacations5.jpg', 48),
(120, '1559122279_Tutors & Languages1.jpg', 49),
(121, '1559122279_Tutors & Languages2.jpg', 49),
(122, '1559122523_Tutors & Languages7.png', 50),
(123, '1559122523_Tutors & Languages6.jpeg', 50),
(124, '1559123179_Wedding1.jpg', 51),
(125, '1559123179_Wedding2.jpg', 51),
(126, '1559123654_Wedding4.jpg', 52),
(127, '1559123654_Wedding5.jpg', 52),
(128, '1559124338_other3.jpg', 53),
(129, '1559124338_other4.jpg', 53),
(130, '1559124550_other5.jpg', 54),
(131, '1559124550_other6.jpg', 54),
(132, '1559127666_bar, food & hospitality1.jpg', 55),
(133, '1559127666_bar, food & hospitality2.jpg', 55),
(134, '1559127818_Bar, Food & Hospitality3.jpg', 56),
(135, '1559127818_Bar, Food & Hospitality4.jpg', 56),
(136, '1559128042_Accounting & Management1.jpg', 57),
(137, '1559128042_Accounting & Management3.jpg', 57),
(138, '1559128200_Accounting & Management2.png', 58),
(139, '1559128200_Accounting & Management4.jpg', 58),
(140, '1559129085_child care1.png', 59),
(141, '1559129085_child care4.jpg', 59),
(142, '1559129249_child care3.jpg', 60),
(143, '1559129249_Child care2.jpg', 60),
(144, '1559129249_child care5.jpg', 60),
(145, '1559129736_Cleaning & Housekeeping1.jpg', 61),
(146, '1559129736_Cleaning & Housekeeping2.jpg', 61),
(147, '1559129993_Cleaning & Housekeeping4.jpg', 62),
(148, '1559129993_Cleaning & Housekeeping3.jpg', 62),
(149, '1559130307_Construction & Trades1.jpg', 63),
(150, '1559130307_Construction & Trades2.jpg', 63),
(151, '1559130476_Construction & Trades3.jpg', 64),
(152, '1559130476_Construction & Trades4.jpg', 64),
(153, '1559282147_Truck driver1.jpg', 65),
(154, '1559282147_Truck Driver2.jpg', 65),
(155, '1561011940_French Bulldog puppies.jpg', 66),
(156, '1561011940_French Bulldog puppies2.jpg', 66);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `name`) VALUES
(36, 'ANDHRA PRADESH'),
(37, 'ASSAM'),
(38, 'ARUNACHAL PRADESH'),
(39, 'GUJRAT'),
(40, 'BIHAR'),
(41, 'HARYANA'),
(42, 'HIMACHAL PRADESH'),
(43, 'JAMMU & KASHMIR'),
(44, 'KARNATAKA'),
(45, 'KERALA'),
(46, 'MADHYA PRADESH'),
(47, 'MAHARASHTRA'),
(48, 'MANIPUR'),
(49, 'MEGHALAYA'),
(50, 'MIZORAM'),
(51, 'NAGALAND'),
(52, 'ORISSA'),
(53, 'PUNJAB'),
(54, 'RAJASTHAN'),
(55, 'SIKKIM'),
(56, 'TAMIL NADU'),
(57, 'TRIPURA'),
(58, 'UTTAR PRADESH'),
(59, 'WEST BENGAL'),
(60, 'DELHI'),
(61, 'GOA'),
(62, 'PONDICHERY'),
(63, 'LAKSHDWEEP'),
(64, 'DAMAN & DIU'),
(65, 'DADRA & NAGAR'),
(66, 'CHANDIGARH'),
(67, 'ANDAMAN & NICOBAR'),
(68, 'UTTARANCHAL'),
(69, 'JHARKHAND'),
(70, 'CHATTISGARH');

-- --------------------------------------------------------

--
-- Table structure for table `sub_cat`
--

CREATE TABLE `sub_cat` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `cat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_cat`
--

INSERT INTO `sub_cat` (`id`, `name`, `cat_id`) VALUES
(1, 'Adventure', 1),
(28, 'All in Buy & Sell', 1),
(29, 'Arts & Collectibles', 1),
(30, 'Audio', 1),
(31, 'Baby Items', 1),
(32, 'Bikes', 1),
(33, 'Books', 1),
(34, 'Business & Industrial', 1),
(35, 'Cameras & Camcorders', 1),
(36, 'CDs, DVDs & Blu-ray', 1),
(37, 'Clothing', 1),
(38, 'Computers', 1),
(39, 'Computer Accessories', 1),
(40, 'Electronics', 1),
(41, 'Free Stuff', 1),
(42, 'Furniture', 1),
(43, 'Garage Sales', 1),
(44, 'Health &amp; Special Needs', 1),
(45, 'Hobbies &amp; Crafts', 1),
(46, 'Home Appliances', 1),
(47, 'Home - Indoor', 1),
(59, 'All in Cars & Vehicles', 10),
(60, 'Cars & Trucks in', 10),
(61, 'Cars & Trucks', 10),
(62, 'Classic Cars', 10),
(63, 'Vehicle Parts, Tires, &  Accessories', 10),
(64, 'Automotive Services', 10),
(65, 'Motorcycles', 10),
(66, 'ATVs & Snowmobiles', 10),
(67, 'Boats & Watercraft', 10),
(68, 'RVs, Campers & Trailers', 10),
(69, 'Heavy Equipment', 10),
(70, 'Other', 10),
(71, 'All in Real Estate', 11),
(72, 'For Rent', 11),
(73, 'For Sale', 11),
(74, 'Real Estate Services', 11),
(75, 'All in Jobs', 12),
(76, 'Accounting & Management', 12),
(77, 'Child Care', 12),
(78, 'Bar, Food & Hospitality', 12),
(79, 'Cleaning & Housekeeping', 12),
(80, 'Construction & Trades', 12),
(81, 'Customer Service', 12),
(82, 'Cannabis Sector', 12),
(83, 'Drivers &amp; Security', 12),
(84, 'General Labour', 12),
(85, 'Graphic &amp; Web Design', 12),
(86, 'Healthcare', 12),
(87, 'Hair Stylist &amp; Salon', 12),
(88, 'Office Manager &amp; Receptionist', 12),
(89, 'Part Time &amp; Students', 12),
(90, 'Programmers &amp; Computer', 12),
(91, 'Sales &amp; Retail Sales', 12),
(92, 'TV, Media, &amp; Fashion', 12),
(93, 'Other', 12),
(94, 'All in Services', 13),
(95, 'Childcare &amp; Nanny', 13),
(96, 'Cleaners &amp; Cleaning', 13),
(97, 'Entertainment', 13),
(98, 'Financial &amp; Legal', 13),
(99, 'Fitness &amp; Personal Trainer', 13),
(100, 'Food &amp; Catering', 13),
(101, 'Health &amp; Beauty', 13),
(102, 'Moving &amp; Storage', 13),
(103, 'Music Lessons', 13),
(104, 'Photography &amp; Video', 13),
(105, 'Skilled Trades', 13),
(106, 'Tutors &amp; Languages', 13),
(107, 'Wedding', 13),
(108, 'Travel &amp; Vacations', 13),
(109, 'Other', 13),
(110, 'All in Pets', 14),
(111, 'Animal &amp; Pet Services', 14),
(112, 'Birds for Rehoming', 14),
(113, 'Cats &amp; Kittens for Rehoming', 14),
(114, 'Dogs &amp; Puppies for Rehoming', 14),
(115, 'Equestrian &amp; Livestock Accessories', 14),
(116, 'Fish for Rehoming', 14),
(117, 'Horses &amp; Ponies for Rehoming', 14),
(118, 'Livestock', 14),
(119, 'Lost &amp; Found', 14),
(120, 'Accessories', 14),
(121, 'Reptiles &amp; Amphibians for Rehoming', 14),
(122, 'Small Animals for Rehoming', 14),
(123, 'Other Pets for Rehoming', 14),
(124, 'Other', 14),
(125, 'All in Vacation Rentals', 15),
(126, 'Canada', 15),
(127, 'USA', 15),
(128, 'Caribbean', 15),
(129, 'Mexico', 15),
(130, 'Other Countries', 15),
(131, 'All in Community', 16),
(132, 'Activities &amp; Groups', 16),
(133, 'Artists &amp; Musicians', 16),
(134, 'Classes &amp; Lessons', 16),
(135, 'Events', 16),
(136, 'Friendship &amp; Networking', 16),
(137, 'Long Lost Relationships', 16),
(138, 'Lost &amp; Found', 16),
(139, 'Missed Connections', 16),
(140, 'Rideshare', 16),
(141, 'Sports Teams', 16),
(142, 'Volunteers', 16),
(143, 'Other', 16),
(144, 'Home - Outdoor &amp; Garden', 1),
(145, 'Home Renovation Materials', 1),
(146, 'Jewellery &amp; Watches', 1),
(147, 'Musical Instruments', 1),
(148, 'Phones', 1),
(149, 'Sporting Goods &amp; Exercise', 1),
(150, 'Tickets', 1),
(151, 'Tools', 1),
(152, 'Toys &amp; Games', 1),
(153, 'TVs &amp; Video', 1),
(154, 'Video Games &amp; Consoles', 1),
(155, 'Other', 1);

-- --------------------------------------------------------

--
-- Table structure for table `userlist`
--

CREATE TABLE `userlist` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `status` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(256) NOT NULL,
  `pro_pic` varchar(256) NOT NULL,
  `entry_date` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlist`
--

INSERT INTO `userlist` (`id`, `name`, `status`, `password`, `email`, `pro_pic`, `entry_date`) VALUES
(1, 'amb', 'Active', 'ï¿½ï¿½,', 'name.kalyan@gmail.com', '', '02-03-2019'),
(2, 'Ambia', 'Active', '1234', 'wtm.golam@gmail.com', '', '05-03-2019'),
(3, 'SHISH KEBAB', 'Active', 'Admin123', 'name.kalyan@gmail.com', '', '05-03-2019'),
(4, 'Rahul H', 'Active', 'Webtechnomind@123', 'wtm.projectmanager@gmail.com', '', '06-03-2019'),
(5, 'KP', 'Active', 'Classified@2019', 'kalypaul@gmail.com', '', '08-03-2019'),
(6, 'Amit Kumar', 'Active', 'Webtechnomind@1990', 'agrahriamit86@gmail.com', '', '08-03-2019'),
(7, 'Anit', 'Active', 'Anit@1234', 'wtm.anit@gmail.com', '', '14-03-2019'),
(8, 'RABINDRA NATH HALDER', 'Active', 'Rahul@2009', 'rahul.halder2009@gmail.com', '', '14-03-2019'),
(9, 'soumen singh', 'Active', 'Webtechnomind@123', 'wtm.soumen@gmail.com', '', '16-03-2019'),
(10, 'Arnab Nath', 'Active', 'Arnab@123', 'arnab@gmail.com', '', '18-03-2019'),
(11, 'Rahul', 'Active', 'Webtechnomind@123', 'wtm.projectmanger@gmail.com', '', '20-03-2019'),
(12, 'Emile', 'Active', 'Admin@123#', 'emilelee69@gmail.com', '', '27-05-2019'),
(13, 'Louis', 'Active', 'Admin@123#', 'joneslouis620@gmail.com', '', '28-05-2019'),
(14, 'Hayden', 'Active', 'Admin@123#', 'allenhayden448@gmail.com', '', '28-05-2019'),
(15, 'Anna', 'Active', 'Admin@123#', 'annaclark251@gmail.com', '', '29-05-2019'),
(16, 'Simon', 'Active', 'Admin@123#', 'simonmoore921@gmail.com', '', '29-05-2019'),
(17, 'ksdfjskdlvjk', 'Active', 'Xoomla@2019', 'paul@gvimmigration.com', '', '03-06-2019'),
(18, 'Nipun', 'Active', 'Admin@123#', 'nipunsingh645@gmail.com', '', '20-06-2019');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_admin`
--
ALTER TABLE `admin_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `admin_setting`
--
ALTER TABLE `admin_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carmodel`
--
ALTER TABLE `carmodel`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `category_table`
--
ALTER TABLE `category_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquery_message`
--
ALTER TABLE `inquery_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `make`
--
ALTER TABLE `make`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_ads`
--
ALTER TABLE `post_ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_ads_images`
--
ALTER TABLE `post_ads_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_cat`
--
ALTER TABLE `sub_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlist`
--
ALTER TABLE `userlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_admin`
--
ALTER TABLE `admin_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_setting`
--
ALTER TABLE `admin_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `carmodel`
--
ALTER TABLE `carmodel`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category_table`
--
ALTER TABLE `category_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `inquery_message`
--
ALTER TABLE `inquery_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `make`
--
ALTER TABLE `make`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `post_ads`
--
ALTER TABLE `post_ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `post_ads_images`
--
ALTER TABLE `post_ads_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `sub_cat`
--
ALTER TABLE `sub_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `userlist`
--
ALTER TABLE `userlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
