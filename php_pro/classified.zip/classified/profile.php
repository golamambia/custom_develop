<?php
include"header.php";
$msg ="";
$msg_class ="";
if($_SESSION['USER']['logedin']!='true'){
    header("location:login");
}else{

$sid=$_SESSION['USER']['id'];


if(isset($_POST['changeProfile']) && $_POST['changeProfile']=='changeProfile'){
  if($_FILES['file']['name']!=''){
            $arr=getimagesize($_FILES['file']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['file']['name'])));
                        
               
                    $tmp_name = $_FILES['file']['tmp_name'];
                    $name = time()."_".$_FILES['file']['name'];
                    move_uploaded_file($tmp_name, SITE_IMAGE_PATH.$name);
                    $_POST['upload'] = $name;

                                
        }
        $_POST['name'] =mysql_real_escape_string($_POST['name']);
    $db->updateArray(DTABLE_USER,$_POST, "id=".$sid);
    
    $msg_class = 'alert-success';
    $msg = MSG_EDIT_SUCCESS;
}
 $GET_DATA =$pm->getTableDetails(DTABLE_USER,'id',$sid);

//$GET_USER_UPDATE = $pm->getTableDetails(TABLE_EMPLOG,'id',$sid);
}

?>
<div class="main_area">
	<div class="container">
    	<div class="category_area">
        	<div class="row">
                <div class="col-lg-3">
                    <div class="dashboard">
                        <?php
                        include"sidebar.php";
                        ?>
                    </div>
                </div>
              <div class="col-lg-9">
            	<div class="logon_box">
                	<h3>Profile <span style="float: right;color: orange;"><?php if($GET_DATA['approval']=='no' && $GET_DATA['upload']!=''){
                    echo"Your approval is pending. Please contact us";
}?></span></h3>
                    <?php if((isset($msg)) and ($msg != '')){ ?>
                                <div class="alert <?php echo $msg_class; ?> alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <p><?php echo $msg; ?></p>
                                </div>
                            <?php } ?>
                     <form action="" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="changeProfile" value="changeProfile">
                      <div class="form-group row">
                        <label class="col-lg-2 col-form-label">Name</label>
                        <div class="col-lg-10">
                          <input type="text" name="name"  class="form-control"  placeholder="Name" value="<?php echo $GET_DATA['name']; ?>"  required>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-lg-2 col-form-label">Email</label>
                        <div class="col-lg-10">
                          <input type="text"  class="form-control" value="<?php echo $GET_DATA['email']; ?>"  placeholder="Email ID" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-lg-2 col-form-label">Upload Agreement</label>
                        <div class="col-lg-10">
                          <input type="file" name="file" id="file" class="form-control" <?php if($GET_DATA['upload']==''){echo"required";}?>>
                        </div>
                        
                      </div>
                      <div class="form-group row">
                        <label class="col-lg-2 col-form-label">&nbsp;</label>
                        <div class="col-lg-10">
                          <?php if($GET_DATA['upload']!=''){?>
                  <a style="float: right;margin-top: 5px;" href="<?PHP echo SITE_IMAGE_PATH.$GET_DATA['upload']?>" download>
                        Download Your Agreement
                    </a>
                  <?php }else{?>

                    <a style="float: right;margin-top: 5px;" href="<?PHP echo SITE_IMAGE_PATH.mysql_fetch_assoc(mysql_query("select upload FROM ".DTABLE_SETTING." where id=1"))['upload'];?>" download>
                        Download Agreement for sign
                    </a>

                  <?php }?>
                        </div>
                      </div>
                      
                       <div class="form-group row">
                       	 <div class="col-lg-10 offset-lg-2"><input type="submit" value="Update" class="btn btn-default"></div>
                       </div>
                    </form>	
                </div>
              </div>
            </div>
        </div>
     </div>
    </div>


<?php
include"footer.php";
?>
<script type="text/javascript">
  $(document).ready(function(e){
//alert(1);
$("#file").change(function() {
        var file = this.files[0];
        var imagefile = file.type;
        //alert(imagefile);
        var match= ["application/msword","application/pdf","application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
            alert('Please select a valid  file (DOC/PDF).');
            $("#file").val('');
            return false;
        }
    });


  });
</script>