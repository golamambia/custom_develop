<?php
include"header.php";
?>
<div class="home-banner" style="background-image:url(images/banner.jpg)">

<div class="container">
<div class="banner_up_part">
<h1>Buy – Sell – Advertise anything online</h1>
<div class="classify_formbox">
<div class="form_area">
    <div class="add_contant">Classified 
Ads</div>
	<div class="formarea_inner clearfix">
    <form class="w-100" method="get" action="ad_listing">
    <div class="form-group box_one">
    <input type="text" class="form-control" placeholder="What are you Looking for?" name="searchfor" id="searchfor" autocomplete="off">
    <div id="suggesstion-box" class="auto_select"></div>
    </div>
    
    <div class="form-group box_two">
    <select class="form-control" name="category">
           <?php 
            $sql = "SELECT * FROM ".DTABLE_CATEGORY." ORDER BY title asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
            <option value="<?=$row_rec['id'];?>"><?=$row_rec['title'];?></option>
          <?php }?>
    </select>  
    </div>
    
    <div class="form-group box_two">
    <input type="text" class="form-control" id="location" name="location" placeholder="Type location" autocomplete="off">
    <div id="suggesstion_loc" class="auto_select"></div>
    </div>
    <div class=" input_search">
    <input type="submit" value="search" class="search_btn">
    </div>
    </form>
    </div>
</div>
</div>
</div>
</div>
</div>


<div class="cetagory_area">
	<div class="container">
    	<h2>POPULAR CATEGORIES</h2>
    	 <div id="servicescarousel" class="owl-carousel services-carousel">
         <?php 
            $sql = "SELECT * FROM ".DTABLE_CATEGORY." ORDER BY title asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
              $sql2 = "SELECT * FROM ".DTABLE_ADS." where category='$row_rec[id]'";
               $count=$db->countRows($sql2);
            ?>
                <div class="item">
                   <a href="ad_listing?category=<?=$row_rec['id'];?>">
                     <p><i  class="glyph-icon <?=$row_rec['icon'];?>"></i></p>
                    <h5><?=$row_rec['title'];?><span><?=$count;?> Ads</span></h5>
                   </a>
                </div>
             <?php }?>
                <!-- <div class="item">
                   <a href="">
                     <p><i  class="glyph-icon flaticon-open-book"></i></p>
            	      <h5>Books<span>1500 Ads</span></h5>
                   </a>
                </div> -->
                
              
            </div> 
    </div>
</div>


<div class="feature_area">
	<div class="container">
   
    	<div class="row">
        <div class="col-lg-9">
    	 <h2 class="clearfix">Feature Ads<span><a href="#">view all</a></span></h2>
    	 <div id="featurecarousel" class="owl-carousel feature-carousel">
         
         <?php 
            $sql = "SELECT * FROM ".DTABLE_ADS." ORDER BY title asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
              $post_id=$row_rec['id'];
              $cat_id=$row_rec['category'];
              $get_img =mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$post_id'"));
              $get_cat =mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_CATEGORY." where id='$cat_id'"));
            
            ?>
         	<div class="item box">
            <a href="ad_details?details=<?=$row_rec['id'];?>">
            	<div class="imgthumble">
           	       <img src="<?PHP echo SITE_IMAGE_PATH.$get_img['image'];?>" alt="">
                   <div class="stiker"><?=$get_cat['title'];?></div>
                   <div class="titel"><?=$row_rec['title'];?></div> 
                </div>
                <div class="bodyarea">
                	<h4>Price: $<?=$row_rec['price'];?></h4>
                    <p><?php echo substr($row_rec['description'], 0, 60) . '...'; ?></p>
                    <div class="dated"><i class="fa fa-clock-o" aria-hidden="true"></i> <?=date('d.m.Y',strtotime($row_rec['entry_date']));?></div>
                    <div class="calgary"><i class="fa fa-map-marker" aria-hidden="true"></i> <?=$row_rec['location'];?></div>
                </div>
              </a>
            </div>
             <?php }?>
            
          </div>
            
            
            <div class="adds-banner mt-5 mb-5">
            <img src="images/Banner_Pasang_Iklan_zpsa9a64beb.gif" alt=""> 
            </div>
            
            <div class="traning_add"> 
            <h2 class="clearfix">Trending Ads<span><a href="#">view all</a></span></h2>
            <div class="row row-5 ">
              <?php 
            $sql = "SELECT * FROM ".DTABLE_ADS." ORDER BY rand() limit 0,4";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
              $post_id=$row_rec['id'];
              $cat_id=$row_rec['category'];
              $get_img =mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_ADS_IMG." where post_id='$post_id'"));
              $get_cat =mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_CATEGORY." where id='$cat_id'"));
            ?>
          <div class="col-lg-3 col-md-6 col-sm-6 col-12">
          <div class="item box">
                      <a href="ad_details?details=<?=$row_rec['id'];?>">
                      	<div class="imgthumble">
                     	       <img src="<?PHP echo SITE_IMAGE_PATH.$get_img['image'];?>" alt="">
                             <div class="stiker"><?=$get_cat['title'];?></div>
                             <div class="titel"><?=$row_rec['title'];?></div> 
                          </div>
                          <div class="bodyarea">
                          	<h4>Price: $<?=$row_rec['price'];?></h4>
                              <p><?php echo substr($row_rec['description'], 0, 60) . '...'; ?></p>
                              <div class="dated"><i class="fa fa-clock-o" aria-hidden="true"></i> <?=date('d.m.Y',strtotime($row_rec['entry_date']));?></div>
                              <div class="calgary"><i class="fa fa-map-marker" aria-hidden="true"></i> <?=$row_rec['location'];?></div>
                          </div>
                          </a>
                      </div>
          </div>

        <?php }?>
        </div>
        </div>
            
            
            
            
            
            
            
          </div>
            <div class="col-lg-3">
               <aside class="asidebox">
            	   <div class="adds_box">
           	       <img src="images/adds.png" alt=""> 
                   </div>
                   <!--<div class="aside_menu">
                   		<h2>Popular on classified</h2>
                   		<ul>
                        	<li><a href="#">Free Stuff <i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
                            <li><a href="#">Wanted Ads <i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
                            <li><a href="#">Swap / Trade <i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
                        </ul>
                   </div>-->
                   <div class="adds_box mt-4">
           	         <img src="images/114659673861311085.gif" alt=""> 
                   </div>
                </aside>
            </div>
         </div>
         
        
         
    </div>
</div>




<!--<div class="serviceslist_area">
	<div class="container">
    	<h2>Services List</h2>
        <div class="row">
        	<div class="col-lg-3 col-md-6 col-sm-6 serviceslistbox">
            	<div class="card">
                	<div class="card-header">
                    	<h5>Books<span>1500 Ads</span></h5>
                       <div class="glyph-icon flaticon-open-book"></div>
                    </div>
                    <div class="card-body clearfix">
                    	<ul>
                        	<li>Comic <span>35</span></li>
                            <li>Adventure <span>48</span></li>
                            <li>Science Fiction <span>100</span></li>
                            <li>Science Fiction <span>76</span></li>
                            <li>Sports <span>98</span></li>
                            <li>Motivational <span>48</span></li>
                            <li><a href="#">Show More <span><i class="fa fa-arrow-right" aria-hidden="true"></i></span></a></li>
                         </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6  serviceslistbox">
            	<div class="card">
                	<div class="card-header">
                    	<h5>Jobs<span>900 Ads</span></h5>
                       <div class="glyph-icon flaticon-suitcase"></div>
                    </div>
                    <div class="card-body clearfix">
                    	<ul>
                        	<li>Comic <span>35</span></li>
                            <li>Adventure <span>48</span></li>
                            <li>Science Fiction <span>100</span></li>
                            <li>Science Fiction <span>76</span></li>
                            <li>Sports <span>98</span></li>
                            <li>Motivational <span>48</span></li>
                            <li><a href="#">Show More <span><i class="fa fa-arrow-right" aria-hidden="true"></i></span></a></li>
                         </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6  serviceslistbox">
            	<div class="card">
                	<div class="card-header">
                    	<h5>Real Estate<span>1900 Ads</span></h5>
                       <div class="glyph-icon flaticon-building"></div>
                    </div>
                    <div class="card-body clearfix">
                    	<ul>
                        	<li>Comic <span>35</span></li>
                            <li>Adventure <span>48</span></li>
                            <li>Science Fiction <span>100</span></li>
                            <li>Science Fiction <span>76</span></li>
                            <li>Sports <span>98</span></li>
                            <li>Motivational <span>48</span></li>
                            <li><a href="#">Show More <span><i class="fa fa-arrow-right" aria-hidden="true"></i></span></a></li>
                         </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6  serviceslistbox">
            	<div class="card">
                	<div class="card-header">
                    	<h5>Car<span>2300 Ads</span></h5>
                       <div class="glyph-icon flaticon-car"></div>
                    </div>
                    <div class="card-body clearfix">
                    	<ul>
                        	<li>Comic <span>35</span></li>
                            <li>Adventure <span>48</span></li>
                            <li>Science Fiction <span>100</span></li>
                            <li>Science Fiction <span>76</span></li>
                            <li>Sports <span>98</span></li>
                            <li>Motivational <span>48</span></li>
                            <li><a href="#">Show More <span><i class="fa fa-arrow-right" aria-hidden="true"></i></span></a></li>
                         </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6  serviceslistbox">
            	<div class="card">
                	<div class="card-header">
                    	<h5>Buy/sell<span>1385 Ads</span></h5>
                       <div class="glyph-icon flaticon-laptop"></div>
                    </div>
                    <div class="card-body clearfix">
                    	<ul>
                        	<li>Comic <span>35</span></li>
                            <li>Adventure <span>48</span></li>
                            <li>Science Fiction <span>100</span></li>
                            <li>Science Fiction <span>76</span></li>
                            <li>Sports <span>98</span></li>
                            <li>Motivational <span>48</span></li>
                            <li><a href="#">Show More <span><i class="fa fa-arrow-right" aria-hidden="true"></i></span></a></li>
                         </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6  serviceslistbox">
            	<div class="card">
                	<div class="card-header">
                    	<h5>Pets<span>1721 Ads</span></h5>
                       <div class="glyph-icon flaticon-chef"></div>
                    </div>
                    <div class="card-body clearfix">
                    	<ul>
                        	<li>Comic <span>35</span></li>
                            <li>Adventure <span>48</span></li>
                            <li>Science Fiction <span>100</span></li>
                            <li>Science Fiction <span>76</span></li>
                            <li>Sports <span>98</span></li>
                            <li>Motivational <span>48</span></li>
                            <li><a href="#">Show More <span><i class="fa fa-arrow-right" aria-hidden="true"></i></span></a></li>
                         </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6  serviceslistbox">
            	<div class="card">
                	<div class="card-header">
                    	<h5>Community<span>1500 Ads</span></h5>
                       <div class="glyph-icon flaticon-open-book"></div>
                    </div>
                    <div class="card-body clearfix">
                    	<ul>
                        	<li>Comic <span>35</span></li>
                            <li>Adventure <span>48</span></li>
                            <li>Science Fiction <span>100</span></li>
                            <li>Science Fiction <span>76</span></li>
                            <li>Sports <span>98</span></li>
                            <li>Motivational <span>48</span></li>
                            <li><a href="#">Show More <span><i class="fa fa-arrow-right" aria-hidden="true"></i></span></a></li>
                         </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6  serviceslistbox">
            	<div class="card">
                	<div class="card-header">
                    	<h5>Jobs<span>900 Ads</span></h5>
                       <div class="glyph-icon flaticon-suitcase"></div>
                    </div>
                    <div class="card-body clearfix">
                    	<ul>
                        	<li>Comic <span>35</span></li>
                            <li>Adventure <span>48</span></li>
                            <li>Science Fiction <span>100</span></li>
                            <li>Science Fiction <span>76</span></li>
                            <li>Sports <span>98</span></li>
                            <li>Motivational <span>48</span></li>
                            <li><a href="#">Show More <span><i class="fa fa-arrow-right" aria-hidden="true"></i></span></a></li>
                         </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>-->


<div class="playstore_area mt-5 mb-5">
	<div class="container">
   	  <div class="playstore_box">
        	<div class="img_thumb">
       	      <img src="images/bg-phones-en.be355a25.png" alt=""> 
           </div>
        <div class="playstore_contantbox">
   		  <h4>Take Canada's #1 classifieds site with you</h4>
          <p>Buy and sell new or used items wherever you go!</p>
             <ul>
               	 <li><a class="" href="#"><img src="images/appstore.png" alt=""></a></li>
                 <li><a class="" href="#"><img src="images/playstore.png" alt=""></a></li>
             </ul>
          </div>
        </div>
    </div>
</div>

<?php
include"footer.php";
?>