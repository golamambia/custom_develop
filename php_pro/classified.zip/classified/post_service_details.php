<?php
$page="pad";
include"header.php";
if($_SESSION['USER']['logedin']!='true'){
header("location:signin");
}
$title=$_REQUEST['title'];
$cat=base64_decode($_REQUEST['cat']);
$sub_cat=base64_decode($_REQUEST['sub_cat']);

if(isset($_POST['add_post']) && $_POST['add_post']=='add_post'){
    $_POST['entry_date'] =date('d-m-Y');
    $_POST['status']='Active';
    //$_POST['password']=rand(00000,99999);
    $get_last_id = $db->insertDataArray(DTABLE_ADS,$_POST);
    //$name2='';
        if($_FILES['image_browses']['name']!=''){
            $filename = $_FILES['image_browses']['name'];
            $file_tmp = $_FILES['image_browses']['tmp_name'];
            $filetype = $_FILES['image_browses']['type'];
            $filesize = $_FILES['image_browses']['size'];
            
            for($i=0; $i<=count($file_tmp); $i++){
                if(!empty($file_tmp[$i])){
                    $arr=getimagesize($file_tmp[$i]);
                    $userfile_extn = end(explode(".", strtolower($filename[$i])));
                    
                    if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){
                        $tmp_name = $file_tmp[$i];
                        $name = time()."_".$filename[$i];
                        //$name2.=$name.",";
                        move_uploaded_file($tmp_name, SITE_IMAGE_PATH.$name);
                        $_POST['image'] = $name;
                        $_POST['post_id'] = $get_last_id;
                        $get_last_id1 = $db->insertDataArray(DTABLE_ADS_IMG,$_POST);
                    }
                    else{
                        $msg="Picture's must be .jpeg/.jpg/.png/.gif please check extension";
                    }
                }
                else{
                    $msg="Please select some images...";
                }
            }
        }
    if(!empty($get_last_id)):
    $msg_class = 'alert-success';
    $msg = "Your ad successfully posted";
    else:
    $msg_class = 'alert-error';
    $msg = MSG_ADD_FAIL;
    endif;

    }
?>
<div class="innerbanner">
         <div class="container">
            <div class="page-header clearfix">
               <h1>Post Ad</h1>
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#"><?=mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_CATEGORY." where id='$cat'"))[title];?></a></li>
                  <li class="breadcrumb-item active" aria-current="page"><?=mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_SUBCAT." where id='$sub_cat'"))[name];?></li>
               </ol>
            </div>
         </div>
      </div>
      <div class="mainarea">
         <div class="container">
            <div class="Postd_dtls">
            	<h4>Post Your Ad it's fast and easy</h4>
                <div class="blub_box">
                    <img src="images/light-bulb.png" alt="">
                    Descriptive titles are the best fuel for high<br> performing ads!
               </div>
                <?php if((isset($msg)) and ($msg != '')){ ?>
        <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
        </div>
        <?php } ?>
             <form class="" action="" method="post" enctype="multipart/form-data">
               <div class="Postd_box">
                <input type="hidden" name="add_post" value="add_post">
                <input type="hidden" name="email" value="<?=$_SESSION[USER][email];?>">
               		<h3><span>1</span>Ad Details</h3>
                    <div class="postd_body">
                      <div class="clearfix">
                      <ol class="breadcrumb">
                  <li class="breadcrumb-item"><?=mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_CATEGORY." where id='$cat'"))[title];?></li>
                  <li class="breadcrumb-item active" aria-current="page"><?=mysql_fetch_assoc(mysql_query("SELECT * FROM ".DTABLE_SUBCAT." where id='$sub_cat'"))[name];?></li>
               </ol>
               
               </div>
                     
                      	<div class="form-group">
                        	<label class="text">Ad Type</label>
                            <p>
                                <input type="radio" id="test1" name="job_offer" value="indivitual" checked>
                                <label for="test1"><strong>I am offering</strong> - You are offering an item for sale </label>
                             </p>
                              <p>
                                <input type="radio" id="test2" name="job_offer" value="non_indivitual">
                                <label for="test2"><strong>I want </strong> - You want to buy an item
              </label>
                              </p>
                            

                        </div>
                        <div class="form-group">
                        	<label class="text">Ad Title:</label>
                            <input type="text" class="form-control" name="company">
                        </div>
						<div class="form-group">
                        	<label class="text">Description:</label>
                            <input type="text" class="form-control" name="address" required>
                      
                        </div>
                        <div class="form-group">
                        	<label class="text">Location:</label>
                            <select class="form-control" name="job_type" required>
                            	<option value="">Calgary</option>
                                <option value="Lloydminster">Lloydminster</option>
                                <option value="Red Deer">Red Deer</option>
                                <option value="Calgary">Calgary</option>
                                <option value="temp">Edmonton Area</option>
                                <option value="Lethbridge">Lethbridge</option>
								
								<option value="Medicine Hat">Medicine Hat</option>
                                <option value="temp">Fort McMurray</option>
                                <option value="Grande Prairie">Grande Prairie</option>
								 <option value="Banff / Canmore">Banff / Canmore</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                          <label class="text">Sub Area:</label>
                            <select class="form-control" name="sub_category" id="sub_category" required>
                              <option value=""></option>
                                
                            </select>
                        </div>
                         <div class="form-group">
                        	<label class="text">Address:</label>
                            <input type="text" class="form-control" name="title" id="title" value="<?=$title;?>" placeholder="Please enter an address" required>
                             <div class="form-group chake mt-2">
                              <p>Enter your postal code and/or street address above.</p>
                            </div>
                        </div>
                        <!-- <input type="hidden" class="form-control" value="<?=$cat;?>" name="category">
                        <input type="hidden" class="form-control" value="<?=$sub_cat;?>" name="sub_category"> -->
                        
                        <p>There is a limit of 1 standard ad at a time in this category for individuals. Restrictions apply to professional employers. A standard ad is defined as any ad for which an insertion fee or package has not been purchased. At any time when you have 1 standard ad posted in this category, each additional ad posted will not be free and will be subject to a fee (which is included in all paid package prices).</p>
                      
                    </div>
               </div>
               
               
               <div class="Postd_box">
               		<h3><span>2</span>Media</h3>
                    <div class="postd_body">
                    	<h5>Add photos to attract interest to your ad</h5>
                      <p>Include pictures with different angles and details. You can upload a maximum of 10 photos, <br>that are at least 300px wide or tall (we recommend at least 1000px).<br><br><!-- Drag and drop to change the order of your pictures. --></p>
                      
                     <div class="clearfix mt-5"> 	 
                     	<!-- Our File Inputs -->
                          <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image1" accept=".gif, .jpg, .png" required />
                            <label  for="image1">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                        
                          <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image2" accept=".gif, .jpg, .png" required />
                            <label  for="image2">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                        
                          <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image3" accept=".gif, .jpg, .png" />
                            <label  for="image3">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                        
                           <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image4" accept=".gif, .jpg, .png" />
                            <label  for="image4">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                          <div class="wrap-custom-file">
                            <input type="file" name="image_browses[]" id="image5" accept=".gif, .jpg, .png" />
                            <label  for="image5">
                              <span>upload image</span>
                              <i class="fa fa-plus-circle"></i>
                            </label>
                          </div>
                          
                    </div>
                    
					 <div class="clearfix mt-4">
                    <div class="form-group">
                        	<label class="text">Youtube Link(optional):</label>
                            <input type="text" class="form-control" name="youtube">
							<p class="message">Add a YouTube video to your ad.</p>

                        <p class="example">Example: http://www.youtube.com/watch?v=&lt;your video id&gt;</p>
                        </div>
                    </div>
					
					
					
                    <div class="clearfix mt-4">
                    <div class="form-group">
                    	<label class="text">Website URL:</label>
                    	<label for="chkPassport">
                        <input type="checkbox" id="chkPassport" />   Link to your website -$4.95</label>
                        <div id="dvPassport" style="display: none">
                            <input type="text" class="form-control"  placeholder="Website URL:" name="web_url" />
                        </div>
                       </div>
                    </div>
               </div>
               </div>
               <div class="Postd_box">
               		<h3><span>3</span>Contact Information</h3>
                    <div class="postd_body">
                    	 <div class="form-group">
                        	<label class="text">Phone Number: <span>(optional)</span></label>
                            <input type="text" class="form-control" name="contact">
                            <p>Your phone number will show up on your Ad.</p>
                        </div>
                         <div class="form-group">
                        	<label class="text">Email:</label>
                            <span class="emailtext"><?=$_SESSION[USER][email];?></span>
                            <p>Your email address will not be shared with others.</p>
                        </div>
                    </div>
               </div>
               
               <!--<div class="Postd_box">
               		<h3><span>4</span>xoomla Policies</h3>
                    <div class="postd_body">
                    	<p><strong>The following content is prohibited from Kijiji. You will be blocked from Kijiji for posting:</strong></p> 
                         <ul>
                         	<li>Multi-level or work from home jobs where recruitment of other members is part of the job</li>
                            <li>Pyramid schemes or any job that requires upfront or periodic payments</li>
                            <li>Jobs that involve sexual activities</li>
                            <li>Identical jobs that are posted in multiple categories and/or on multiple Kijiji sites</li>
                         </ul>
                         <h6>Terms and Conditions</h6>
                         <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="terms_check" id="exampleCheck1" required>
                            <label class="form-check-label" for="exampleCheck1">By posting your ad, you are agreeing to our <a href="#">terms of use</a>, <a href="#">privacy policy</a> and <a href="#">site policies</a>.<br>
          Please do not post duplicate ads. Use 'Promote My Ad' above to gain more replies.</label>
                          </div>
                    </div>
               </div>-->
               
               <div class="btn-group mt-4">
                <input type="submit" value=" Post Your Ad" class="btn btn-danger">
                 <!-- <input type="submit" value="Preview" class="btn btn-primary"> -->
               </div>
               </form>
            </div>
         </div>
      </div>
      <?php
      include"footer.php";
      ?>
      <script type="text/javascript">
    function get_cat(val) {
//alert(val);

$.ajax({
type: "POST",
url: "get_subcat.php",
data: 'val=' + val,
cache: false,
success: function(html) {
//alert(html);

   
$("#sub_category").html(html);


}
});

return false;
}    
</script>