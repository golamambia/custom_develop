<?php 

include('includes/admin_top.php');



//$host=$_SESSION['USER']['user_id'];

    $msg ="";

    $deleteid = $_REQUEST['delete'];

    $page_title = 'USER - List';



    if(isset($deleteid) && $deleteid!=""){

        $db->deleteData(TABLE_USER,"id=".$deleteid);
		$db->deleteData(TABLE_USER_KYC,"user_id=".$deleteid);
    $db->deleteData(TABLE_BANK,"user_id=".$deleteid);
    $db->deleteData(TABLE_BONUS,"user_id=".$deleteid);
    $db->deleteData(TABLE_TBONUS,"user_id=".$deleteid);
    $db->deleteData(TABLE_REWARD,"user_id=".$deleteid);
    $db->deleteData(TABLE_TASK_BYUSER,"user_id=".$deleteid);
    $db->deleteData(TABLE_WALLET,"user_id=".$deleteid);
    $db->deleteData(TABLE_WALLET_HISTORY,"user_id=".$deleteid);
        $msg_class = 'alert-success';

        $msg = MSG_DELETE_SUCCESS;

    }

    $tod=date("n/j/Y");

?>  

<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">

    <!-- Main Header -->

    <?php include('includes/admin_header.php'); ?>  

    <!-- Left side column. contains the logo and sidebar -->

    <?php include('includes/admin_sidebar.php'); ?>  

    <!-- Content Wrapper. Contains page content -->

    <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

        <h1><?php echo $page_title; ?></h1>

    </section>



    <section class="content">

    <?php if((isset($msg)) and ($msg != '')){ ?>

    <div class="alert <?php echo $msg_class; ?> alert-dismissable">

        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

    <p><?php echo $msg; ?></p>

    </div>

    <?php } ?>



    <div class="box box-info">

    <!-- form start -->

    <div class="box-body">

    <table id="example12" class="table table-bordered table-striped tableGrid2">

        <thead>

        

            <tr>

                

               

                <!-- <th>Image</th> -->

                <th>Name</th>

                <th>Email</th>                

                <th>Sponsor Name</th>

                <th>Mobile (user id)</th>
                <th>Password</th>
                <th>Payment Status</th> 
                <th>Sponsor ID</th>
                <th>Level 1</th>
                <th>ID</th>
                <th>Status</th> 

                <th>Action</th>

            </tr>

        </thead>

        <tbody>

            <?php 

            

                    $sql = "SELECT * FROM ".TABLE_USER." where mobile !='' order by id desc "; 

               

            $i=0;

            $res = $db->selectData($sql);

            while($row_rec = $db->getRow($res)){

                 $i++;

            ?>

            <tr>

                

                <!-- <td><img src="<?PHP echo HOME_UPLOAD.$row_rec['service_img']?>" height="60"/></td> -->

                <td>

                      <?php echo $row_rec['name']; ?>

                </td>

                <td>

                   <?php echo $row_rec['email']; ?>

                </td>

                <td>

                  <?php echo $row_rec['sponsor_name']; ?> (<?php echo $row_rec['sponsor_id']; ?>)

                   

                </td>

                <td>

                      <?php echo $row_rec['mobile']; ?>

                </td>
                <td>

                      <?php echo base64_decode($row_rec['password']); ?>

                </td>
                <td>

                    <label class="switch">

                        <input name="sec11" id ="sec11" onclick="check2('<?php echo $row_rec['id']; ?>')" type="checkbox" <?php if($row_rec['pay_status'] !='unpaid'){ ?>checked <?php } ?> >

                        <span class="slider round"></span>

                    </label>

                </td>
                <td>

                   <?php echo $row_rec['user_sponsorid']; ?>

                </td>
                <td><?php
                $t_sql="select * FROM ".TABLE_USER." where sponsor_id='".$row_rec['user_sponsorid']."'";
echo $count=$db->countRows($t_sql);
?>
</td>
<td><?php if($row_rec['id_no']=='id1'){
echo"ID 1";
}else if($row_rec['id_no']=='id2'){ echo"ID 2";}else{ echo"ID 3";}?></td>
                <td>

                    <label class="switch">

                        <input name="sec1" id ="sec1" onclick="check('<?php echo $row_rec['id']; ?>')" type="checkbox" <?php if($row_rec['user_status'] == 'Active'){ ?>checked <?php } ?> >

                        <span class="slider round"></span>

                    </label>

                </td>

                

                

                <td>

                    

                    <a href="user_edit.php?edit=<?php echo base64_encode($row_rec['id']); ?>" title="Edit"><img src="images/pencil.png" width="16" height="16" alt=""></a>



                

                    <a href="user_list.php?delete=<?php echo $row_rec['id']; ?>" title="Delete"  onClick="return confirm('Are you sure you to delete this data?');">

                    <img src="images/cross.png" width="16" height="16" alt="">

                    </a>

                </td>

            </tr>

            <?php } ?>

        </tbody>

    </table>

    </div>

    </div>

    </section>

</div>

<!-- /.content-wrapper -->

<?php include('includes/admin_footer.php'); ?>

<style>

.switch {

  position: relative;

  display: inline-block;

  width: 60px;

  height: 34px;

}



.switch input {display:none;}



.slider {

  position: absolute;

  cursor: pointer;

  top: 0;

  left: 0;

  right: 0;

  bottom: 0;

  background-color: #ccc;

  -webkit-transition: .4s;

  transition: .4s;

}



.slider:before {

  position: absolute;

  content: "";

  height: 26px;

  width: 26px;

  left: 4px;

  bottom: 4px;

  background-color: white;

  -webkit-transition: .4s;

  transition: .4s;

}



input:checked + .slider {

  background-color: #0fb80c;

}





input:checked + .slider:before {

  -webkit-transform: translateX(26px);

  -ms-transform: translateX(26px);

  transform: translateX(26px);

}



/* Rounded sliders */

.slider.round {

  border-radius: 30px;

}



.slider.round:before {

  border-radius: 50%;

}

</style>

<script>

    function check(a){
//alert(a);
      $.ajax({

        type:'post',

        url:'user_active.php',

        data:{

          fstatus: 'fstatus',

          id: a

        },
        success: function(html) {
//console.log(html);
        }

      });

    

    }
function check2(a){
//alert(a);
      $.ajax({

        type:'post',

        url:'user_pay_active.php',

        data:{

          fstatus: 'fstatus',

          id: a

        },
        success: function(html) {
//console.log(html);
        }

      });

    

    }
</script> 