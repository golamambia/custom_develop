<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $editid = $_REQUEST['edit'];
    $page_title = 'Update - Earning';

    if(isset($_POST['update_banner']) && $_POST['update_banner']=='update_banner'){
        
            $db->updateArray(TABLE_EARNING,$_POST, "id=".$editid) or die(mysql_error());
            $msg_class = 'alert-success';
            $msg = MSG_EDIT_SUCCESS;
      
    }
    $get_data = $pm->getTableDetails(TABLE_EARNING,'id',$editid);
?>  

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
    <!-- Main Header -->
        <?php include('includes/admin_header.php'); ?>  

        <!-- Left side column. contains the logo and sidebar -->
        <?php include('includes/admin_sidebar.php'); ?>  

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1><?php echo $page_title; ?></h1>
        </section>

        <section class="content">
            <?php if((isset($msg)) and ($msg != ''))
            { ?>
            <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
            </div>
            <?php 
            } 
            ?>
            <div class="box box-info">
            <!-- form start -->
            <form class="form-horizontal"  method="post" enctype="multipart/form-data">
            
                <input type="hidden" name="update_banner" value="update_banner">
                <div class="box-body">

               <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="title" placeholder="Task name" name="name" value="<?php echo $get_data['name']; ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">User Id</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="user_id" placeholder="Enter User Id" name="user_id" value="<?php echo $get_data['user_id']; ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Contact No.</label>
                <div class="col-sm-5">
                    <input type="number" class="form-control" id="contact_no" placeholder="Enter Contact No." name="contact_No" value="<?php echo $get_data['contact_no']; ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Earning</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="earning" placeholder="Enter Earning" name="earning" value="<?php echo $get_data['earning']; ?>" required>
                </div>
            </div>
                <!-- <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Sponsor Id</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="sponsor_id" name="" value="<?php echo $get_data['user_sponsorid']; ?>" readonly>
                </div>
            </div>
 -->

                <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Date</label>
                <div class="col-sm-5">
                    <input type="date" class="form-control" placeholder="date" name="date"  value="<?php echo $get_data['date']; ?>" required>                    
                </div>
                </div>

                <div class="box-footer">                    
                    <a href="work_info_list.php" type="button" class="btn btn-info">Close</a>
                    <button type="submit" class="btn btn-info">Submit</button>
                </div>

                </div>
            </form>
            </div>
        </section>
        
        </div>
    </div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?> 