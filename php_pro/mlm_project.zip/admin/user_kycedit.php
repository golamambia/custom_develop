<?php 
include('includes/admin_top.php'); 
$msg ="";
$error_msg ="";


$edit=base64_decode($_REQUEST['edit']);
if(isset($_POST['changeProfile']) && $_POST['changeProfile']=='changeProfile'){  if($_FILES['photo1']['name']!=''){            $arr=getimagesize($_FILES['photo1']['tmp_name']);            $userfile_extn = end(explode(".", strtolower($_FILES['photo1']['name'])));                                                           $tmp_name = $_FILES['photo1']['tmp_name'];                    $name = time()."_".$_FILES['photo1']['name'];                    move_uploaded_file($tmp_name, INNER_IMAGE.$name);                    $_POST['photo'] = $name;                                        }        if($_FILES['pan1']['name']!=''){            $arr=getimagesize($_FILES['pan1']['tmp_name']);            $userfile_extn = end(explode(".", strtolower($_FILES['pan1']['name'])));                                                           $tmp_name = $_FILES['pan1']['tmp_name'];                    $name = time()."_".$_FILES['pan1']['name'];                    move_uploaded_file($tmp_name, INNER_IMAGE.$name);                    $_POST['pan'] = $name;                                        }        if($_FILES['aadhar1']['name']!=''){            $arr=getimagesize($_FILES['aadhar1']['tmp_name']);            $userfile_extn = end(explode(".", strtolower($_FILES['aadhar1']['name'])));                                                           $tmp_name = $_FILES['aadhar1']['tmp_name'];                    $name = time()."_".$_FILES['aadhar1']['name'];                    move_uploaded_file($tmp_name, INNER_IMAGE.$name);                    $_POST['aadhar'] = $name;                                        }        if($_FILES['passbook1']['name']!=''){            $arr=getimagesize($_FILES['passbook1']['tmp_name']);            $userfile_extn = end(explode(".", strtolower($_FILES['passbook1']['name'])));                                                           $tmp_name = $_FILES['passbook1']['tmp_name'];                    $name = time()."_".$_FILES['passbook1']['name'];                    move_uploaded_file($tmp_name, INNER_IMAGE.$name);                    $_POST['passbook'] = $name;                                        }                       $db->updateArray(TABLE_USER_KYC,$_POST, "id=".$edit);             $msg_class = 'alert-success';    $msg = "Document updated successfully";        }

$GET_USER_UPDATE = $pm->getTableDetails(TABLE_USER_KYC,'id',$edit);


?>  
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<!-- Main Header -->
<?php include('includes/admin_header.php'); ?>  
<!-- Left side column. contains the logo and sidebar -->
<?php include('includes/admin_sidebar.php'); ?>  
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<section class="content-header">
	
<h1>UPDATE KYC</h1>

</section>
<section class="content">
<?php if((isset($msg)) and ($msg != '')){ ?>
<div class="alert <?php echo $msg_class; ?> alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<p><?php echo $msg; ?></p>
</div>
<?php } ?>
<div class="box box-info">
<div class="box-header with-border">
<h3 class="box-title">Update KYC</h3>
</div>


<div class="row">
<div class="col-sm-8">
<form action="" method="post" enctype="multipart/form-data">                      <input type="hidden" name="changeProfile" value="changeProfile">					  <div class="box-body">                            <div class="row">                                <div class="col-lg-6">                     <label>Photo</label>                    <div class="form-group">                        <input type="file" class="form-control" placeholder="Mobile No" name="photo1" id="photo1" >                    </div>                </div>                <div class="col-lg-6">                     <label>&nbsp;</label>                    <div class="form-group">                        <img src="<?PHP echo INNER_IMAGE.$GET_USER_UPDATE['photo']?>" height="60"/>                    </div>                </div>                                <div class="col-lg-6">                                    <label>Passbook/cancel cheque</label>                    <div class="form-group">                        <input type="file" name="passbook1" id="passbook1" class="form-control form-spon" placeholder="Sponsor's ID" >                                           </div>                </div>                <div class="col-lg-6">                     <label>&nbsp;</label>                    <div class="form-group">                        <img src="<?PHP echo INNER_IMAGE.$GET_USER_UPDATE['passbook']?>" height="60"/>                    </div>                </div>                <div class="col-lg-6">                    <label>Aadhar Card</label>                    <div class="form-group">                        <input type="file" class="form-control" placeholder="Full Name" name="aadhar1" id="aadhar1" >                    </div>                </div>                <div class="col-lg-6">                     <label>&nbsp;</label>                    <div class="form-group">                        <img src="<?PHP echo INNER_IMAGE.$GET_USER_UPDATE['aadhar']?>" height="60"/>                    </div>                </div>                <div class="col-lg-6">                     <label>Pan Card</label>                    <div class="form-group">                        <input type="file" id="pan1" class="form-control" placeholder="Death of Birth" name="pan1" >                    </div>                </div>                <div class="col-lg-6">                     <label>&nbsp;</label>                    <div class="form-group">                        <img src="<?PHP echo INNER_IMAGE.$GET_USER_UPDATE['pan']?>" height="60"/>                    </div>                </div>                                               <div class="box-footer">                                        <a href="user_kyclist.php" type="button" class="btn btn-info">Close</a>                    <button type="submit" class="btn btn-info">Submit</button>                </div>                            </div>							</div>                        </form>
</div>

</div>




</div>

</section>
</div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?> 