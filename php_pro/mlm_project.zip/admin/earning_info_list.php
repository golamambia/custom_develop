<?php 
include('includes/admin_top.php');
    $msg ="";
    $deleteid = $_REQUEST['delete'];
    $page_title = 'Earning - List';

    if(isset($deleteid) && $deleteid!=""){
        $db->deleteData(TABLE_EARNING,"id=".$deleteid);
        $msg_class = 'alert-success';
        $msg = MSG_DELETE_SUCCESS;
    }
//     $date=$_REQUEST['date'];

//     $date1 = new DateTime('now');
// $date1->modify('first day of this month');
//  $first_day=$date1->format('Y-m-d');

// $date2 = new DateTime('now');
// $date2->modify('last day of this month');
//  $last_day=$date2->format('Y-m-d');

?>  
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Main Header -->
    <?php include('includes/admin_header.php'); ?>  
    <!-- Left side column. contains the logo and sidebar -->
    <?php include('includes/admin_sidebar.php'); ?>  
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php echo $page_title; ?></h1>
    </section>

    <section class="content">
    <?php if((isset($msg)) and ($msg != '')){ ?>
    <div class="alert <?php echo $msg_class; ?> alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <p><?php echo $msg; ?></p>
    </div>
    <?php } ?>

    <div class="box box-info">
    <!-- form start -->
    <div class="box-body">

        <!--  <form action="" method="get">
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                    <label for="Username"><b>From</b></label> 
                    <input type="date" class="form-control" id="date1" placeholder="Username" name="start" value="<?=$_REQUEST['start'];?>" required>
                    
                    
                  </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                   <label for="Username"><b>To</b></label> 
                    <input type="date" class="form-control" id="date2" placeholder="Username" name="end" value="<?=$_REQUEST['end'];?>" required>
                    
                    
                  </div>
                      </div>
                      <div class="col-md-2">
                        <label for="Username"><b>&nbsp;</b></label> 
                        <input style="margin-top: 25px;" type="submit" name="" value="Search" class="btn-success btn">
                      </div>
                    </div>
                      </form> -->

    <table id="example11" class="table table-bordered table-striped tableGrid2">
        <thead>
        <a href="earning_info_add.php" type="button" class="btn btn-info" style="margin-bottom: 10px;">Add Task</a>
            <tr>
                <th>ID</th> 
                <th>NAME</th>                
                <th>USER ID</th>
                <th>CONTACT NO</th>
                <th>EARNINGS(RS.)</th>
                <th>DATE</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $start_date=$_REQUEST['start'];
                            $end_date=$_REQUEST['end'];
            $limit_val=4;
                  if(isset($_GET["page"]))
                              $page = (int)$_GET["page"];
                              else
                              $page = 1;

                              $setLimit = $limit_val;
                              $pageLimit = ($page * $setLimit) - $setLimit;
                              
                             $perPage = $limit_val;
                            $page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
                            $startAt = $perPage * ($page - 1);

                            

                             $sql= "SELECT * FROM ".TABLE_EARNING." where 1=1  ";
                        //  if($start_date!='' && $end_date!='')
                        //  {
                        //    $sql.= "and entry_date BETWEEN '".$start_date."' AND '".$end_date."' ";
                        // }else{
                        //     $sql.="and entry_date  BETWEEN '".$first_day."' AND '".$last_day."' ";
                        // }

            $sql1=$sql;
         $sql.= " ORDER BY date asc limit $startAt, $perPage";
         $count=$db->countRows($sql1);
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
                
            ?>
            <tr>
                <td>
                    <?php echo $row_rec['id']; ?>
                </td>
                <td>
                    <?php echo $row_rec['name']; ?>
                </td>
                <td>
                    <?php echo $row_rec['user_id']; ?>
                </td>
                <td>
                    <?php echo $row_rec['contact_no']; ?>
                </td>
                <td>
                    <?php echo $row_rec['earning']; ?>
                </td>
                <td>
                    <?php echo $row_rec['date']; ?>
                </td>
                <td>
                    <a href="earning_info_edit.php?edit=<?php echo $row_rec['id']; ?>" title="Edit"><img src="images/pencil.png" width="16" height="16" alt=""></a>
                    <a href="earning_info_list.php?delete=<?php echo $row_rec['id']; ?>" title="Delete"  onClick="return confirm('Are you sure you to delete this data?');">
                    <img src="images/cross.png" width="16" height="16" alt="">
                    </a> 
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>


<?php
if($count>4){

$limit =$limit_val; 


$record_index= ($page-1) * $limit;
               
// $total_records = $row[0];

$total_pages = ceil($count / $limit);  
//$pagLink = "<div class='pagination'>";  
  
 if($start_date!='' && $end_date!=''){
    echo "<ul class='pagination' style='float: right;'>";
if($page>1){
    echo "<li><a href='work_info_list.php?page=".($page-1)."&start=$_REQUEST[start]&end=$_REQUEST[end]' class='button'>Previous Day</a></li>"; 
   }

    for ($i=1; $i<=$total_pages; $i++) {?>
     <li class="<?php if($_REQUEST[page]=='' && $i==1){echo"active";}else{ if($_REQUEST[page]==$i){echo"active";}} ?>"><a  href='work_info_list.php?page=<?=$i;?>&start=<?=$_REQUEST[start];?>&end=<?=$_REQUEST[end];?>'>Day <?=$i;?></a></li>
  <?php }
  if($page<$total_pages){
    echo"<li><a href='work_info_list.php?page=".($page+1)."&start=$_REQUEST[start]&end=$_REQUEST[end]' class='button'>Next Day</a></li>";
}

    echo"</ul>"; 
    }else{
    echo "<ul class='pagination' style='float: right;'>";
if($page>1){
    echo "<li><a href='work_info_list.php?page=".($page-1)."' class='button'>Previous Day</a></li>"; 
   }

    for ($i=1; $i<=$total_pages; $i++) {?>
     <li class="<?php if($_REQUEST[page]=='' && $i==1){echo"active";}else{ if($_REQUEST[page]==$i){echo"active";}} ?>"><a  href='work_info_list.php?page=<?=$i;?>'>Day <?=$i;?></a></li>
  <?php }
  if($page<$total_pages){
    echo"<li><a href='work_info_list.php?page=".($page+1)."' class='button'>Next Day</a></li>";
}

    echo"</ul>"; 
    }               
//};  
   }    
?>



    </div>
    </div>
    </section>
</div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?> 