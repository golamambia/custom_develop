<aside class="main-sidebar">
<section class="sidebar">
<div class="user-panel">
<div class="pull-left image" style="height:50px;">
<!--<img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">-->
</div>
<div class="pull-left info" style="left:0px">
<p>
<?php

echo $_SESSION['ADMIN']['name'];

?>
</p>
<a href="<?php $gf->linkURL('admin/dashboard.php');?>"><i class="fa fa-circle text-success"></i> Online</a>
</div>
</div>
<?php if((isset($_SESSION['ADMIN']['id'])) and ($_SESSION['ADMIN']['id'] != "")){ ?>
<ul class="sidebar-menu">
<li class="<?php if($getPageName == 'dashboard.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/dashboard.php');?>"><i class="fa fa-link"></i> <span>Dashboard</span></a></li>

<li class="treeview <?php if($getPageName == 'user_list.php' || $getPageName == 'user_edit.php' || $getPageName == 'user_kyclist.php' 
|| $getPageName == 'user_kycedit.php' || $getPageName == 'user_bankedit.php' || $getPageName == 'user_banklist.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-user"></i> <span>User Section</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <!-- <li><a href="<?php $gf->linkURL('admin/user_blog_add.php');?>">Blog Add </a></li> -->
        <li class="<?php if($getPageName == 'user_list.php' ){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/user_list.php');?>">User List</a></li>
         <li class="<?php if($getPageName == 'user_kyclist.php' ){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/user_kyclist.php');?>">User KYC List</a></li>
        <li class="<?php if($getPageName == 'user_banklist.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/user_banklist.php');?>">User Bank Detail List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'user_amount_set.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-user"></i> <span>User Amount Set</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <!-- <li><a href="<?php $gf->linkURL('admin/user_blog_add.php');?>">Blog Add </a></li> -->
        <li class="<?php if($getPageName == 'user_amount_set.php' ){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/user_amount_set.php');?>">Amount set</a></li>
         
   
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'country_add.php' || $getPageName == 'country_edit.php'  || $getPageName == 'country_list.php' || $getPageName == 'state_add.php'
 || $getPageName == 'state_edit.php' || $getPageName == 'state_list.php'){?> active <?php }?>">
    <a href="#"><i  class="fa fa-file-text-o"></i> <span>Country & State</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li  class="<?php if($getPageName == 'country_list.php' ){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/country_list.php');?>">Country List </a></li> 
        <li class="<?php if($getPageName == 'state_list.php' ){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/state_list.php');?>">State List</a></li>
         
   
    </ul>
</li>



<li class="treeview <?php if($getPageName == 'home_slider_edit.php' || $getPageName == 'home_slider_list.php' || $getPageName == 'home_slider_add.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Home Page Slider</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li class="<?php if($getPageName == 'home_slider_add.php' ){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/home_slider_add.php');?>">Slider Add</a></li>
    <li class="<?php if($getPageName == 'home_slider_list.php' ){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/home_slider_list.php');?>">Slider List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'about_info_edit.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>About Page Info</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <li class="<?php if($getPageName == 'about_info_edit.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/about_info_edit.php');?>">Update Info</a></li>
           
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'home_about_info_edit.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Mission & Vision</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <li class="<?php if($getPageName == 'home_about_info_edit.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/home_about_info_edit.php');?>">Update Info</a></li>
           
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'sponsor_info_add.php' || $getPageName == 'sponsor_info_list.php' || $getPageName == 'sponsor_info_edit.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Sponsor</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <!-- <li class="<?php if($getPageName == 'sponsor_info_add.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/sponsor_info_add.php');?>">Add Sponsor</a></li> -->
    <li class="<?php if($getPageName == 'sponsor_info_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/sponsor_info_list.php');?>">List Sponsor</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'bonus_generate.php' || $getPageName == 'bonus_list.php' || $getPageName == 'bonus_update.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Shopping Bonus</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <li class="<?php if($getPageName == 'bonus_generate.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/bonus_generate.php');?>">Bonus Add</a></li>
    <li class="<?php if($getPageName == 'bonus_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/bonus_list.php');?>">Bonus List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'tbonus_generate.php' || $getPageName == 'tbonus_list.php' || $getPageName == 'tbonus_update.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Task Bonus</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <li class="<?php if($getPageName == 'tbonus_generate.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/tbonus_generate.php');?>">Task-bonus Add</a></li>
    <li class="<?php if($getPageName == 'tbonus_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/tbonus_list.php');?>">Task-bonus List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'reward_generate.php' || $getPageName == 'reward_list.php' || $getPageName == 'reward_update.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Reward Generate</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <li class="<?php if($getPageName == 'reward_generate.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/reward_generate.php');?>">Reward Add</a></li>
    <li class="<?php if($getPageName == 'reward_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/reward_list.php');?>">Reward List</a></li>
    </ul>
</li>


<li class="treeview <?php if($getPageName == 'withdrawl_request_list.php' || $getPageName == 'withdrawl_list.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Wallet Section</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <li class="<?php if($getPageName == 'withdrawl_request_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/withdrawl_request_list.php');?>">Withdrawl Request</a></li>
    <li class="<?php if($getPageName == 'withdrawl_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/withdrawl_list.php');?>">Withdrawl List</a></li>
    </ul>
</li>

<li class="treeview <?php if($getPageName == 'work_info_add.php' || $getPageName == 'work_info_list.php' || $getPageName == 'work_info_edit.php' || $getPageName == 'user_task_list.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Working Task</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <li class="<?php if($getPageName == 'work_info_add.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/work_info_add.php');?>">Add Task</a></li>
    <li class="<?php if($getPageName == 'work_info_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/work_info_list.php');?>">List Task</a></li>
    <li class="<?php if($getPageName == 'user_task_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/user_task_list.php');?>">Task Complete List</a></li>
    </ul>
</li>

<li class="treeview <?php if($getPageName == 'earning_info_add.php' || $getPageName == 'earning_info_list.php' || $getPageName == 'earning_info_edit.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Latest Earnings</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    <li class="<?php if($getPageName == 'earning_info_add.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/earning_info_add.php');?>">Add Earning</a></li>
    <li class="<?php if($getPageName == 'earning_info_list.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/earning_info_list.php');?>">List Earning</a></li>
    </ul>
</li>

<li class="treeview <?php if($getPageName == 'business_plan_update.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Business Plan</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    
    <li class="<?php if($getPageName == 'business_plan_update.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/business_plan_update.php');?>">Plan Update</a></li>
    </ul>
</li>
<li class="treeview <?php if( $getPageName == 'privacy_edit.php' || $getPageName == 'terms_edit.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Terms & Privacy</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li class="<?php if($getPageName == 'privacy_edit.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/privacy_edit.php');?>">Privacy & Policy </a></li>
        <li class="<?php if($getPageName == 'terms_edit.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/terms_edit.php');?>">Terms & Conditions</a></li>
         
   
    </ul>
</li>

<li class="treeview <?php if($getPageName == 'change_password.php' || $getPageName == 'profile.php' || $getPageName == 'setting.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Profile Section</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li class="<?php if($getPageName == 'profile.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/profile.php');?>">Admin Profile</a></li>
        <li class="<?php if($getPageName == 'setting.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/setting.php');?>">Settings</a></li>
    <li class="<?php if($getPageName == 'change_password.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/change_password.php');?>">Change Password</a></li>
    </ul>
</li>

<li class="<?php if($getPageName == 'logout.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/logout.php');?>" onclick="return confirm('Are You Sure You Want To Logout !!')"><i class="glyphicon glyphicon-log-out"></i> <span>Logout</span></a></li>


</ul>
<?php }?>
</section>
</aside>
