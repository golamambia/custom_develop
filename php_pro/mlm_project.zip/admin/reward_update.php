<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $editid = $_REQUEST['edit'];
    $page_title = 'Update - Reward';

    if(isset($_POST['update_banner']) && $_POST['update_banner']=='update_banner'){
        
            $db->updateArray(TABLE_REWARD,$_POST, "id=".$editid) or die(mysql_error());
            $msg_class = 'alert-success';
            $msg = MSG_EDIT_SUCCESS;
      
    }
    $get_data = $pm->getTableDetails(TABLE_REWARD,'id',$editid);
?>  

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
    <!-- Main Header -->
        <?php include('includes/admin_header.php'); ?>  

        <!-- Left side column. contains the logo and sidebar -->
        <?php include('includes/admin_sidebar.php'); ?>  

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1><?php echo $page_title; ?></h1>
        </section>

        <section class="content">
            <?php if((isset($msg)) and ($msg != ''))
            { ?>
            <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
            </div>
            <?php 
            } 
            ?>
            <div class="box box-info">
            <!-- form start -->
            <form class="form-horizontal"  method="post" enctype="multipart/form-data">
            
                <input type="hidden" name="update_banner" value="update_banner">
                <div class="box-body">

               <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">User ID</label>
                <div class="col-sm-5">
                    <select class="form-control select2" name="user_id" required>
                        <option value="">--Select User--</option>
                        <?php 

                $sql = "SELECT * FROM ".TABLE_USER." where mobile !='' ORDER BY id DESC"; 

            $res = $db->selectData($sql);

            while($row_rec = $db->getRow($res)){

              
            ?>
                        <option <?php if($row_rec['id']==$get_data['user_id']){echo"selected";}?> value="<?=$row_rec['id'];?>"><?=$row_rec['name'];?> (<?=$row_rec['user_sponsorid'];?>)</option>
                    <?php }?>
                    </select>
                </div>
            </div>

                <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Reward</label>
                <div class="col-sm-5">
                    <input  type="text" class="form-control " id="sponsor_id" name="reward" value="<?php echo $get_data['reward']; ?>" placeholder="Reward" required>
                </div>
            </div>


                <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Remark</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" placeholder="Remark" name="remark"  value="<?php echo $get_data['remark']; ?>" required>                    
                </div>
                </div>

                <div class="box-footer">                    
                    <a href="reward_list.php" type="button" class="btn btn-info">Close</a>
                    <button type="submit" class="btn btn-info">Update</button>
                </div>

                </div>
            </form>
            </div>
        </section>
        
        </div>
    </div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?>
<script type="text/javascript">
         $(document).ready(function() {
    $('.numeric_input').keydown(function(event) {
return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )


      
    });
});

     </script> 