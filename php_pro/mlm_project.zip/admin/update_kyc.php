<?php
include"header.php";
$msg ="";
$msg_class ="";
if($_SESSION['GUSER']['logedin']!='true'){
    header("location:login");
}else{

$sid=$_SESSION['GUSER']['id'];
$GET_USER_UPDATE1 = $pm->getTableDetails(TABLE_USER_KYC,'user_id',$sid);
$_POST['user_id']=$sid;
    $_POST['entry_date']=date('Y-m-d');

if(isset($_POST['changeProfile']) && $_POST['changeProfile']=='changeProfile'){
  if($_FILES['photo1']['name']!=''){
            $arr=getimagesize($_FILES['photo1']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['photo1']['name'])));
            
            
               
                    $tmp_name = $_FILES['photo1']['tmp_name'];
                    $name = time()."_".$_FILES['photo1']['name'];
                    move_uploaded_file($tmp_name, IMAGE.$name);
                    $_POST['photo'] = $name;

                                
        }
        if($_FILES['pan1']['name']!=''){
            $arr=getimagesize($_FILES['pan1']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['pan1']['name'])));
            
            
               
                    $tmp_name = $_FILES['pan1']['tmp_name'];
                    $name = time()."_".$_FILES['pan1']['name'];
                    move_uploaded_file($tmp_name, IMAGE.$name);
                    $_POST['pan'] = $name;

                                
        }
        if($_FILES['aadhar1']['name']!=''){
            $arr=getimagesize($_FILES['aadhar1']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['aadhar1']['name'])));
            
            
               
                    $tmp_name = $_FILES['aadhar1']['tmp_name'];
                    $name = time()."_".$_FILES['aadhar1']['name'];
                    move_uploaded_file($tmp_name, IMAGE.$name);
                    $_POST['aadhar'] = $name;

                                
        }
        if($_FILES['passbook1']['name']!=''){
            $arr=getimagesize($_FILES['passbook1']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['passbook1']['name'])));
            
            
               
                    $tmp_name = $_FILES['passbook1']['tmp_name'];
                    $name = time()."_".$_FILES['passbook1']['name'];
                    move_uploaded_file($tmp_name, IMAGE.$name);
                    $_POST['passbook'] = $name;

                                
        }
    //$db->updateArray(DTABLE_REGISTER,$_POST, "id=".$sid);
        if($GET_USER_UPDATE1['user_id']!=''){
            $db->updateArray(TABLE_USER_KYC,$_POST, "user_id=".$sid);
             $msg_class = 'alert-success';
    $msg = "Document updated successfully";
        }else{
        $get_last_id =$db->insertDataArray(TABLE_USER_KYC,$_POST);
    
    $msg_class = 'alert-success';
    $msg = "Document uploaded successfully";
}
}
 
$GET_USER_UPDATE = $pm->getTableDetails(TABLE_USER_KYC,'user_id',$sid);
}
?>

    <div class="inner_banner" style="background-image: url(images/innerbanner.jpg);">
        <div class="container">
            <h1>UPLOAD KYC</h1>
        </div>
    </div>


    <div class="main_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="dashboard_panel">
                        <?php
                        include"inner_side.php";
                        ?>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="dashboard">
                        <h3>KYC</h3>

                       <?php if((isset($msg)) and ($msg != '')){ ?>
                                <div class="alert <?php echo $msg_class; ?> alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <p><?php echo $msg; ?></p>
                                </div>
                            <?php } ?>
                            <?php if($GET_USER_UPDATE['user_id']!=''){?>
                     <form action="" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="changeProfile" value="changeProfile">
                            <div class="row">
                                <div class="col-lg-6">
                     <label>Photo</label>
                    <div class="form-group">
                        <input type="file" class="form-control" placeholder="Mobile No" name="photo1" id="photo1" >
                    </div>
                </div>

                <div class="col-lg-6">
                     <label>&nbsp;</label>
                    <div class="form-group">
                        <img src="<?PHP echo IMAGE.$GET_USER_UPDATE['photo']?>" height="60"/>
                    </div>
                </div>



                                <div class="col-lg-6">
                                    <label>Passbook/cancel cheque</label>
                    <div class="form-group">
                        <input type="file" name="passbook1" id="passbook1" class="form-control form-spon" placeholder="Sponsor's ID" >
                       
                    </div>
                </div>
                <div class="col-lg-6">
                     <label>&nbsp;</label>
                    <div class="form-group">
                        <img src="<?PHP echo IMAGE.$GET_USER_UPDATE['passbook']?>" height="60"/>
                    </div>
                </div>
                <div class="col-lg-6">
                    <label>Aadhar Card</label>
                    <div class="form-group">
                        <input type="file" class="form-control" placeholder="Full Name" name="aadhar1" id="aadhar1" >
                    </div>
                </div>
                <div class="col-lg-6">
                     <label>&nbsp;</label>
                    <div class="form-group">
                        <img src="<?PHP echo IMAGE.$GET_USER_UPDATE['aadhar']?>" height="60"/>
                    </div>
                </div>
                <div class="col-lg-6">
                     <label>Pan Card</label>
                    <div class="form-group">
                        <input type="file" id="pan1" class="form-control" placeholder="Death of Birth" name="pan1" >
                    </div>
                </div>
                <div class="col-lg-6">
                     <label>&nbsp;</label>
                    <div class="form-group">
                        <img src="<?PHP echo IMAGE.$GET_USER_UPDATE['pan']?>" height="60"/>
                    </div>
                </div>
                
                                <div class="col-lg-12"><button type="submit" class="btn btn-success">Update</button></div>
                            </div>
                        </form>
                    <?php }else{?>

                        <form action="" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="changeProfile" value="changeProfile">
                            <div class="row">
                                <div class="col-lg-6">
                     <label>Photo</label>
                    <div class="form-group">
                        <input type="file" class="form-control" placeholder="Mobile No" name="photo1" id="photo1" required>
                    </div>
                </div>
                                <div class="col-lg-6">
                                    <label>Passbook/cancel cheque</label>
                    <div class="form-group">
                        <input type="file" name="passbook1" id="passbook1" class="form-control form-spon" placeholder="Sponsor's ID" required>
                       
                    </div>
                </div>
                
                <div class="col-lg-6">
                    <label>Aadhar Card</label>
                    <div class="form-group">
                        <input type="file" class="form-control" placeholder="Full Name" name="aadhar1" id="aadhar1" required>
                    </div>
                </div>
                
                <div class="col-lg-6">
                     <label>Pan Card</label>
                    <div class="form-group">
                        <input type="file" id="pan1" class="form-control" placeholder="Death of Birth" name="pan1" required>
                    </div>
                </div>

                
                                <div class="col-lg-12"><button type="submit" class="btn btn-success">Submit</button></div>
                            </div>
                        </form>
                    <?php }?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
include"footer.php";
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

    $('.numeric_input').keydown(function(event) {
return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )


      
    });

$("#photo1").change(function() {
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];
        
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
            alert('Please select a valid image file (JPEG/JPG/PNG).');
            $("#photo1").val('');
            return false;
        }
    });
$("#pan1").change(function() {
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];
        
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
            alert('Please select a valid image file (JPEG/JPG/PNG).');
            $("#pan1").val('');
            return false;
        }
    });
$("#aadhar1").change(function() {
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];
        
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
            alert('Please select a valid image file (JPEG/JPG/PNG).');
            $("#aadhar1").val('');
            return false;
        }
    });
$("#passbook1").change(function() {
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];
        
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
            alert('Please select a valid image file (JPEG/JPG/PNG).');
            $("#passbook1").val('');
            return false;
        }
    });

});
</script>