<?php 

include('includes/admin_top.php');



//$host=$_SESSION['USER']['user_id'];

    $msg ="";

    $deleteid = $_REQUEST['delete'];

    $page_title = 'USER -Bank List';



    if(isset($deleteid) && $deleteid!=""){

        $db->deleteData(TABLE_BANK,"id=".$deleteid);

        $msg_class = 'alert-success';

        $msg = MSG_DELETE_SUCCESS;

    }

    $tod=date("n/j/Y");

?>  
<link href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">

    <!-- Main Header -->

    <?php include('includes/admin_header.php'); ?>  

    <!-- Left side column. contains the logo and sidebar -->

    <?php include('includes/admin_sidebar.php'); ?>  

    <!-- Content Wrapper. Contains page content -->

    <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

        <h1><?php echo $page_title; ?></h1>

    </section>



    <section class="content">

    <?php if((isset($msg)) and ($msg != '')){ ?>

    <div class="alert <?php echo $msg_class; ?> alert-dismissable">

        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

    <p><?php echo $msg; ?></p>

    </div>

    <?php } ?>



    <div class="box box-info">

    <!-- form start -->

    <div class="box-body">

    <table id="example12" class="table table-bordered table-striped tableGrid2">

        <thead>

        

            <tr>

                

               

                <!-- <th>Image</th> -->

                <th>Name</th>
                <th>Photo</th>
                <th>Mobile</th>
                <th>Bank</th>
                <th>Branch</th>
                <th>Ifsc Code</th>
                <th>A/c No</th>
               	<th>Passbook</th>
				

                <th>Action</th>

            </tr>

        </thead>

        <tbody>

            <?php 

            

                    $sql = "SELECT * FROM ".TABLE_BANK."  ORDER BY id DESC"; 

               

            $i=0;

            $res = $db->selectData($sql);

            while($row_rec = $db->getRow($res)){

                 $i++;
 $user=mysql_fetch_assoc(mysql_query("select * FROM ".TABLE_USER." where id='".$row_rec['user_id']."'"));
 $user_kyc=mysql_fetch_assoc(mysql_query("select * FROM ".TABLE_USER_KYC." where user_id='".$row_rec['user_id']."'"));
            ?>

            <tr>

               
                <td>

                      <?php echo $user['name']; ?>

                </td>
                 <td>
                     <?PHP if($user_kyc['photo']!='' && file_exists(INNER_IMAGE.$user_kyc['photo']))
                {
                ?>

                    <a href="<?PHP echo INNER_IMAGE.$user_kyc['photo']?>" data-fancybox data-caption="User Photo"><img src="<?PHP echo INNER_IMAGE.$user_kyc['photo']?>" style="width:50px;height:50px;"></a><?PHP 
                }
                ?> </td>
                <td>

                      <?php echo $user['mobile']; ?>

                </td>

                <td>

                   <?php echo $row_rec['bank']; ?>

                </td>

                <td>

                   <?php echo $row_rec['branch']; ?>

                </td>
                <td>

                   <?php echo $row_rec['ifsc']; ?>

                </td>

                <td>

                   <?php echo $row_rec['ac_no']; ?>

                </td>

                

                
                
               
               <td>
                <?PHP if($user_kyc['passbook']!='' && file_exists(INNER_IMAGE.$user_kyc['passbook']))
                {
                ?>
            <a href="<?PHP echo INNER_IMAGE.$user_kyc['passbook']?>" data-fancybox data-caption="User Passbook"><img src="<?PHP echo INNER_IMAGE.$user_kyc['passbook']?>" style="width:50px;height:50px;"></a>
            <?PHP 
                }
                ?> 
                </td>
               
                             

                <td>

                    

                    <a href="user_bankedit.php?edit=<?php echo base64_encode($row_rec['id']); ?>" title="Edit"><img src="images/pencil.png" width="16" height="16" alt=""></a>

                    <a href="user_banklist.php?delete=<?php echo $row_rec['id']; ?>" title="Delete"  onClick="return confirm('Are you sure you to delete this data?');">

                    <img src="images/cross.png" width="16" height="16" alt="">

                    </a>

                </td>

            </tr>

            <?php } ?>

        </tbody>

    </table>

    </div>

    </div>

    </section>

</div>

<!-- /.content-wrapper -->

<?php include('includes/admin_footer.php'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>

