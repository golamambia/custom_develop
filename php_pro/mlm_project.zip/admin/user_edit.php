<?php 
include('includes/admin_top.php'); 
$msg ="";
$error_msg ="";


$sid=base64_decode($_REQUEST['edit']);
if(isset($_POST['changeProfile']) && $_POST['changeProfile']=='changeProfile'){
$db->updateArray(TABLE_USER,$_POST, "id=".$sid);
$msg_class = 'alert-success';
$msg = MSG_EDIT_SUCCESS;
}

$GET_DATA = $pm->getTableDetails(TABLE_USER,'id',$sid);


?>  
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<!-- Main Header -->
<?php include('includes/admin_header.php'); ?>  
<!-- Left side column. contains the logo and sidebar -->
<?php include('includes/admin_sidebar.php'); ?>  
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<section class="content-header">
	
<h1><?=strtoupper($GET_DATA['name']);?>'S PROFILE</h1>

</section>
<section class="content">
<?php if((isset($msg)) and ($msg != '')){ ?>
<div class="alert <?php echo $msg_class; ?> alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<p><?php echo $msg; ?></p>
</div>
<?php } ?>
<div class="box box-info">
<div class="box-header with-border">
<h3 class="box-title">Update Profile</h3>
</div>


<div class="row">
<div class="col-sm-8">
<form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="changeProfile" value="changeProfile">

<div class="box-body">

<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">Sponsor's ID</label>
<div class="col-sm-5">
<input type="text" name="" class="form-control form-spon" placeholder="Sponsor's ID" readonly value="<?=$GET_DATA['sponsor_id'];?>">
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">Sponsor's Name</label>
<div class="col-sm-5">
<input type="text" class="form-control" placeholder="Sponsor's Name" name="" id="sponsor_name" readonly value="<?=$GET_DATA['sponsor_name'];?>">
</div>
</div>

<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">Full Name</label>
<div class="col-sm-5">
<input type="text" class="form-control" placeholder="Full Name" name="name" value="<?=$GET_DATA['name'];?>" required>                    
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">Mobile</label>
<div class="col-sm-5">
<input type="text" class="form-control numeric_input" id="mobile" placeholder="mobile" name="mobile" value="<?php echo $GET_DATA['mobile'];?>" maxlength="12" >
<span style="color:red" id="malert"></span>
</div>
</div>

		<div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">Date of Birth</label>
                <div class="col-sm-5">
                     <input type="date" id="js-date" class="form-control" placeholder="Date of Birth" name="dob" value="<?=$GET_DATA['dob'];?>">
                </div>
            </div> 
            
<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">Email ID</label>
<div class="col-sm-5">
<input type="email" class="form-control" placeholder="Email ID" name="email" id="email" value="<?=$GET_DATA['email'];?>" required>                    
</div>
</div>


<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">Gender</label>
<div class="col-sm-5">
<select class="form-control" name="gender" id="gender" required>                          <option value="">Select Gender</option>                          <option <?php if($GET_DATA['gender']=='male'){echo"selected";}?> value="male">Male</option>                          <option <?php if($GET_DATA['gender']=='female'){echo"selected";}?> value="female">Female</option>
<option <?php if($GET_DATA['gender']=='other'){echo"selected";}?> value="other">Other</option>
</select>
</div>
</div>


<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">Alternate Mobile No</label>
<div class="col-sm-5">
<input type="text" class="form-control numeric_input" placeholder="Alternate Mobile No" maxlength="11" name="alt_mobile" value="<?=$GET_DATA['alt_mobile'];?>">                    
</div>
</div>

<div class="form-group">
    <label for="inputPassword3" class="col-sm-3 control-label">ID </label>
<div class="col-sm-5">
                      <select class="form-control" name="id_no" id="id_no" required>
                        <option value="">Select ID</option>
                          <option <?php if($GET_DATA['id_no']=='id1'){echo"selected";}?> value="id1">ID 1</option>
                          <option <?php if($GET_DATA['id_no']=='id2'){echo"selected";}?> value="id2">ID 2</option>
                          <option <?php if($GET_DATA['id_no']=='id3'){echo"selected";}?> value="id3">ID 3</option>
                        </select>
                    </div>
                </div>

<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">Country</label>
<div class="col-sm-5">
<select class="form-control" name="country" id="country" required>                          <option value="">Select Country</option>                        <?php             $sql = "SELECT * FROM ".TABLE_COUNTRY." ORDER BY id DESC";            $res = $db->selectData($sql);            while($row_rec = $db->getRow($res)){            ?>                          <option <?php if($row_rec['id']==$GET_DATA['country']){echo"selected";}?> value="<?php echo $row_rec['id']; ?>"><?php echo $row_rec['name']; ?></option>                        <?php }?>                        </select>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-3 control-label">State</label>
<div class="col-sm-5">
<select class="form-control" name="state" id="state" required>                          <option value="">Select State</option>                        <?php             $sql = "SELECT * FROM ".TABLE_STATE." ORDER BY name asc";            $res = $db->selectData($sql);            while($row_rec = $db->getRow($res)){            ?>                <option <?php if($row_rec['id']==$GET_DATA['state']){echo"selected";}?> value="<?=$row_rec['id'];?>"><?=$row_rec['name'];?></option>              <?php }?>                        </select>
</div>
</div>
<div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">Status</label>
                <div class="col-sm-5">
                    <select name="status" class="form-control" required>
        <option value="Active" <?php if($GET_DATA['user_status']=='Active'){?> selected <?php }?>>Active </option>
<option  value="Inactive" <?php if($GET_DATA['user_status']=='Inactive'){?> selected <?php }?>>Inactive</option>
</select>
                </div>
            </div><div class="form-group"><label for="inputPassword3" class="col-sm-3 control-label">Address</label><div class="col-sm-5"><textarea class="form-control " placeholder="Address"  name="address" required><?=$GET_DATA['address'];?></textarea>                    </div></div><div class="form-group"><label for="inputPassword3" class="col-sm-3 control-label">Pincode</label><div class="col-sm-5"><input type="text" class="form-control numeric_input" placeholder="Pincode" maxlength="6" name="pincode" required value="<?=$GET_DATA['pincode'];?>">                    </div></div>

</div>
<div class="box-footer">
    <a href="user_list.php" type="button" class="btn btn-info">Close</a>
<button type="submit" class="btn btn-info">Save</button>
</div>
</form>
</div>

</div>




</div>

</section>
</div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?>
<script type="text/javascript">
$(document).ready( function(){
        //alert(2);
$("#mobile").keyup(function(){
    var mail=$("#mobile").val();
    //email_check(mail);
    $.ajax({
type: "POST",
url: "get_email.php",
data: 'val=' + mail,
cache: false,
success: function(html1) {
//alert(html);
var html=html1.trim();
if(html>1){
$("#malert").html('Mobile no already exist!');
$('.submitBtn').attr("disabled","disabled");
return false;
}else{
  $("#malert").html('');
  $(".submitBtn").removeAttr("disabled");
  return true;
}

}
});

  });



$('.numeric_input').keydown(function(event) {
return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )


      
    });




    });




</script> 