<?php 
include('includes/admin_top.php');
    $msg ="";
    $deleteid = $_REQUEST['delete'];
    $page_title = 'Withdrawl Request - List';

    // if(isset($deleteid) && $deleteid!=""){
    //     $db->deleteData(TABLE_BONUS1,"id=".$deleteid);
    //     $msg_class = 'alert-success';
    //     $msg = MSG_DELETE_SUCCESS;
    // }
?>  
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Main Header -->
    <?php include('includes/admin_header.php'); ?>  
    <!-- Left side column. contains the logo and sidebar -->
    <?php include('includes/admin_sidebar.php'); ?>  
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php echo $page_title; ?></h1>
    </section>

    <section class="content">
    <?php if((isset($msg)) and ($msg != '')){ ?>
    <div class="alert <?php echo $msg_class; ?> alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <p><?php echo $msg; ?></p>
    </div>
    <?php } ?>

    <div class="box box-info">
    <!-- form start -->
    <div class="box-body">
    <table id="example1" class="table table-bordered table-striped tableGrid">
        <thead>
        <!-- <a href="bonus_generate.php" type="button" class="btn btn-info">Add</a> -->
            <tr>
                
                <th>Name</th>
                <th>Sponsor Id</th>
                <th>Status</th>                 
                <th>Amount(Rs.)</th>
                <th>Request Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $sql = "SELECT * FROM ".TABLE_WALLET_HISTORY." where pay_status='pending' ORDER BY id DESC";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
                $user=mysql_fetch_assoc(mysql_query("select * FROM ".TABLE_USER." where id=$row_rec[user_id]"));
            ?>
            <tr>
                
                <td>
                    <?php echo $user['name']; ?>
                </td>
                <td>
                    <?php echo $user['user_sponsorid']; ?>
                </td>
                <td>
                    <?php if($row_rec['pay_status']=='pending'){?>
                        <span  class="label label-warning">
                            Pending
                    </span>
                <?php }else{?>
                    <span  class="label label-success">
                        Cleared
                    </span>

                <?php }?>
                </td>
                <td>
                    <?php echo $row_rec['amount']; ?>
                </td>
                <td>
                    <?php echo $row_rec['request_date']; ?>
                </td>
                <td>
                    <?php if($row_rec['pay_status']=='pending'){?>
                        
                        <span style="cursor: pointer;" id="btn_id" class="label label-success" onclick="add_wallet('cleared','<?php echo $row_rec['id'];?>')" title="Click here for Cleared">
                        Cleared
                    </span>
                <?php }else{?>
                    <span style="cursor: pointer;" id="btn_id" class="label label-warning" onclick="add_wallet('pending','<?php echo $row_rec['id'];?>')" title="Click here for Pending">
                            Pending
                    </span>

                <?php }?>
                    <!-- <a href="bonus_update.php?edit=<?php echo $row_rec['id']; ?>" title="Edit"><img src="images/pencil.png" width="16" height="16" alt=""></a> -->
                    <!-- <a href="sponsor_info_list.php?delete=<?php echo $row_rec['id']; ?>" title="Delete"  onClick="return confirm('Are you sure you to delete this data?');">
                    <img src="images/cross.png" width="16" height="16" alt="">
                    </a> --> 
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    </div>
    </div>
    </section>
</div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?>
<script type="text/javascript">
    function add_wallet(val1,val2){
        $("#btn_id").html('Please wait...');
        var fstatus="fstatus";
        
$.ajax({
        type: "POST",
        url: "change_request.php",
        data: 'val1=' + val1 + '&val2=' + val2 + '&fstatus=' + fstatus,
        cache: false,
        success: function(html1) {
        //alert(html1);
        var html=html1.trim();
        if(html=='yes'){
           //$("#add_wallet").html('Transfer complete');
           window.location.reload();
        }

        }
        });

        return false;

    }

</script>
 