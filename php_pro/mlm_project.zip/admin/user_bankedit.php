<?php 
   include('includes/admin_top.php'); 
   $msg ="";
   $error_msg ="";
   
   
   $edit=base64_decode($_REQUEST['edit']);
   if(isset($_POST['changeProfile']) && $_POST['changeProfile']=='changeProfile'){ 
   
   	$db->updateArray(TABLE_BANK,$_POST, "id=".$edit);
                $msg_class = 'alert-success';
       $msg = "Document updated successfully";
         }
   
   $GET_USER_UPDATE = $pm->getTableDetails(TABLE_BANK,'id',$edit);
   
   
   ?>  
<body class="hold-transition skin-blue sidebar-mini">
   <div class="wrapper">
   <!-- Main Header -->
   <?php include('includes/admin_header.php'); ?>  
   <!-- Left side column. contains the logo and sidebar -->
   <?php include('includes/admin_sidebar.php'); ?>  
   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
         <h1>UPDATE BANK DETAILS</h1>
      </section>
      <section class="content">
         <?php if((isset($msg)) and ($msg != '')){ ?>
         <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
         </div>
         <?php } ?>
         <div class="box box-info">
            <div class="box-header with-border">
               <h3 class="box-title">Update Bank Details</h3>
            </div>
            <div class="row">
               <div class="col-sm-8">
                  <form action="" method="post" enctype="multipart/form-data">
                     <input type="hidden" name="changeProfile" value="changeProfile">					  
                     <div class="box-body">
                        <div class="row">
                                <div class="col-lg-6">
                     <label>Bank Name</label>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Bank Name" name="bank" id="bank" value="<?=$GET_USER_UPDATE['bank'];?>" required>
                    </div>
                </div>
                                <div class="col-lg-6">
                                    <label>Branch</label>
                    <div class="form-group">
                        <input type="text" name="branch" id="branch" class="form-control form-spon" placeholder="Branch Name" value="<?=$GET_USER_UPDATE['branch'];?>" required>
                       
                    </div>
                </div>
                
                <div class="col-lg-6">
                    <label>IFSC</label>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="IFSC Code" name="ifsc" id="ifsc" value="<?=$GET_USER_UPDATE['ifsc'];?>" maxlength="12" required>
                    </div>
                </div>
                
                <div class="col-lg-6">
                     <label>Account No</label>
                    <div class="form-group">
                        <input type="text" id="ac_no" class="form-control numeric_input" placeholder="A/C No" name="ac_no" value="<?=$GET_USER_UPDATE['ac_no'];?>" maxlength="16" required>
                    </div>
                </div>
                <div class="col-lg-6">
                     <label>Account Type</label>
                    <div class="form-group">
                        <select class="form-control" name="ac_type" required>
                            <option value="">--Select Type--</option>
                            <option <?php if($GET_USER_UPDATE['ac_type']=='savings'){ echo"selected";}?> value="savings">Savings</option>
                            <option <?php if($GET_USER_UPDATE['ac_type']=='current'){ echo"selected";}?> value="current">Current</option>
                        </select>
                       
                    </div>
                </div>
                
                
                                <div class="col-lg-12"><button type="submit" class="btn btn-success">Update</button></div>
                            </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </section>
   </div>
   <!-- /.content-wrapper -->
   <?php include('includes/admin_footer.php'); ?>