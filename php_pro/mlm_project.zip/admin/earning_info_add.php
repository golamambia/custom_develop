<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $page_title = 'Earning - Add';
    // $id = $_REQUEST['id'];
    $_POST['entry_date']=date('Y-m-d');
    if(isset($_POST['add_earning']) && $_POST['add_earning']=='add_earning'){

        
        $get_last_id = $db->insertDataArray(TABLE_EARNING,$_POST);
                    if(!empty($get_last_id)):
                    $msg_class = 'alert-success';
                    $msg = MSG_ADD_SUCCESS;
                    else:
                    $msg_class = 'alert-error';
                    $msg = MSG_ADD_FAIL;
                    endif;
                    

    }
?>  
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Main Header -->
    <?php include('includes/admin_header.php'); ?>  
    <!-- Left side column. contains the logo and sidebar -->
    <?php include('includes/admin_sidebar.php'); ?>  
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php echo $page_title; ?></h1>
    </section>

    <section class="content">
        <?php if((isset($msg)) and ($msg != '')){ ?>
        <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
        </div>
        <?php } ?>
        <div class="box box-info">
        <!-- form start -->
        <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="add_earning" value="add_earning">
            <div class="box-body">

            

            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" required>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">User Id</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="user_id" placeholder="Enter User Id" name="user_id" required>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Contact No.</label>
                <div class="col-sm-5">
                    <input type="number" class="form-control" id="contact_no" placeholder="Enter Contact No." name="contact_No" required>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Earning</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="earning" placeholder="Enter Earning" name="earning" required>
                </div>
            </div>
            <!-- <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Sponsor Id</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="sponsor_id" placeholder="Enter sponsor id" name="sponsor_id" required>
                </div>
            </div> -->

            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Date</label>
                <div class="col-sm-5">
                    <input type="date" class="form-control" id="date" placeholder="date" name="date" required>
                </div>
            </div>

            <div class="box-footer">
            <a href="earning_info_list.php" type="button" class="btn btn-info">Back</a>
                <button type="submit" class="btn btn-info">Submit</button>
            </div>
            </div>
        </form>
        </div>
    </section>
</div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?> 