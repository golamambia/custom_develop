<?php



include"configure.php";



 $uid=$_POST['val'];



$sql ="SELECT * FROM ".TABLE_USER." WHERE mobile='$uid' ";



echo $row_count=mysql_num_rows(mysql_query($sql));







?>