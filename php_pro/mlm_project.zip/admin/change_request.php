<?php 
if(isset($_POST['fstatus']))
{
    require('../configure.php'); 
     $id = $_POST['val2'];
    $status = $_POST['val1'];
   $date=date('Y-m-d');
 $sql_update = "UPDATE ".TABLE_WALLET_HISTORY." SET pay_status='".$status."', transfer_date='".$date."' WHERE id='".$id."'";

    $st=$db->updateSql($sql_update);
   
  if($st==true){
        echo "yes";
         exit();
  }
    
   

}

?>