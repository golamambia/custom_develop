<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $editid = 1;
    $page_title = 'Update - About Page Content';

    if(isset($_POST['update_banner']) && $_POST['update_banner']=='update_banner'){
        if($_FILES['service_img']['name']!=''){
            $arr=getimagesize($_FILES['service_img']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['service_img']['name'])));
            
            if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){
               
                    $tmp_name = $_FILES['service_img']['tmp_name'];
                    $name = time()."_".$_FILES['service_img']['name'];
                    move_uploaded_file($tmp_name, INNER_IMAGE.$name);
                    $_POST['img'] = $name;

                    
            }else{
                $msg_class = 'alert-error';
                $msg="Must be .jpeg/.jpg/.png/.gif please check extension";
            }
        }
        


            $db->updateArray(TABLE_ABOUT,$_POST, "id=".$editid) or die(mysql_error());
            $msg_class = 'alert-success';
            $msg = MSG_EDIT_SUCCESS;
        
    }
    $get_data = $pm->getTableDetails(TABLE_ABOUT,'id',$editid);
?>  

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
    <!-- Main Header -->
        <?php include('includes/admin_header.php'); ?>  

        <!-- Left side column. contains the logo and sidebar -->
        <?php include('includes/admin_sidebar.php'); ?>  

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1><?php echo $page_title; ?></h1>
        </section>

        <section class="content">
            <?php if((isset($msg)) and ($msg != ''))
            { ?>
            <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
            </div>
            <?php 
            } 
            ?>
            <div class="box box-info">
            <!-- form start -->
            <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
            
                <input type="hidden" name="update_banner" value="update_banner">
                
                <div class="box-body">

                

<div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Title</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" value="<?=$get_data['title'];?>" id="title" placeholder="" name="title" required>
                </div>
            </div>

            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Description</label>
                <div class="col-sm-5">
                    <textarea  class="form-control" rows="10" id="editor1" placeholder="" name="description" required><?=$get_data['description'];?></textarea>
                </div>
            </div>
            
               
            
<div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Image</label>
                <div class="col-sm-5">
                    <input type="file" class="form-control" id="service_img" placeholder="" name="service_img" >
                </div>
            </div> 
            <?PHP if($get_data['img']!='' && file_exists(INNER_IMAGE.$get_data['img']))
                {
                ?>
                    <div class="field-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">&nbsp;</label>
                        <div><img src="<?PHP echo INNER_IMAGE.$get_data['img']?>" height="60"/></div>
                    </div>
                <?PHP 
                }
                ?> 

                <div class="box-footer">                    
                    
                    <button type="submit" class="btn btn-info">Submit</button>
                </div>

                </div>
            </form>
            </div>
        </section>
        
        </div>
    </div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?> 