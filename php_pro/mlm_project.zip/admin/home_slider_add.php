<?php 

include('includes/admin_top.php'); 

    $msg ="";

    $page_title = 'Home Page Slider - Add';

    // $id = $_REQUEST['id'];



    if(isset($_POST['add_work']) && $_POST['add_work']=='add_work'){



        if($_FILES['service_img']['name']!=''){

            $arr=getimagesize($_FILES['service_img']['tmp_name']);

            $userfile_extn = end(explode(".", strtolower($_FILES['service_img']['name'])));

            

            if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){

               

                    $tmp_name = $_FILES['service_img']['tmp_name'];

                    $name = time()."_".$_FILES['service_img']['name'];

                    move_uploaded_file($tmp_name, INNER_IMAGE.$name);

                    $_POST['service_img'] = $name;



                    

            }else{

                $msg_class = 'alert-error';

                $msg="Must be .jpeg/.jpg/.png/.gif please check extension";

            }

        }

        





                    $get_last_id = $db->insertDataArray(TABLE_SLIDER,$_POST);

                    if(!empty($get_last_id)):

                    $msg_class = 'alert-success';

                    $msg = MSG_ADD_SUCCESS;

                    else:

                    $msg_class = 'alert-error';

                    $msg = MSG_ADD_FAIL;

                    endif;





    }

?>  

<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">

    <!-- Main Header -->

    <?php include('includes/admin_header.php'); ?>  

    <!-- Left side column. contains the logo and sidebar -->

    <?php include('includes/admin_sidebar.php'); ?>  

    <!-- Content Wrapper. Contains page content -->

    <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

        <h1><?php echo $page_title; ?></h1>

    </section>



    <section class="content">

        <?php if((isset($msg)) and ($msg != '')){ ?>

        <div class="alert <?php echo $msg_class; ?> alert-dismissable">

            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

            <p><?php echo $msg; ?></p>

        </div>

        <?php } ?>

        <div class="box box-info">

        <!-- form start -->

        <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">

            <input type="hidden" name="add_work" value="add_work">

            <div class="box-body">



            <div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Title</label>

                <div class="col-sm-5">

                    <input type="text" class="form-control" id="title" placeholder="" name="title" required>

                </div>

            </div>



            <div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Short Description</label>

                <div class="col-sm-5">

                    <textarea  class="form-control" rows="5" id="description" placeholder="Type somthing" name="description" required></textarea>

                </div>

            </div>

            

<div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Slider  Image</label>

                <div class="col-sm-5">

                    <input type="file" class="form-control" id="service_img" placeholder="" name="service_img" required>

                </div>

            </div>

<div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Status</label>

                <div class="col-sm-5">

                    <select name="status" class="form-control" required>

                        <option value="Active" selected>Active </option>

<option  value="Inactive" >Inactive</option>

 







</select>

                </div>

            </div>

            



            <div class="box-footer">

            <a href="home_slider_list.php" type="button" class="btn btn-info">Back</a>

                <button type="submit" class="btn btn-info">Submit</button>

            </div>

            </div>

        </form>

        </div>

    </section>

</div>

<!-- /.content-wrapper -->

<?php include('includes/admin_footer.php'); ?> 