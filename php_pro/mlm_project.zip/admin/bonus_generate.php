<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $page_title = 'Bonus - Generate';
    // $id = $_REQUEST['id'];
$_POST['entry_date']=date('Y-m-d');
$_POST['dr_cr']="dr";
    if(isset($_POST['add_work']) && $_POST['add_work']=='add_work'){

        
        $get_last_id = $db->insertDataArray(TABLE_BONUS,$_POST);
                    if(!empty($get_last_id)):
                    $msg_class = 'alert-success';
                    $msg = MSG_ADD_SUCCESS;
                    else:
                    $msg_class = 'alert-error';
                    $msg = MSG_ADD_FAIL;
                    endif;
                    

    }
?>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Main Header -->
    <?php include('includes/admin_header.php'); ?>  
    <!-- Left side column. contains the logo and sidebar -->
    <?php include('includes/admin_sidebar.php'); ?>  
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php echo $page_title; ?></h1>
    </section>

    <section class="content">
        <?php if((isset($msg)) and ($msg != '')){ ?>
        <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
        </div>
        <?php } ?>
        <div class="box box-info">
        <!-- form start -->
        <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="add_work" value="add_work">
            <div class="box-body">

            

            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">User ID</label>
                <div class="col-sm-5">
                    
                    <select class="form-control select2" name="user_id" required>
                        <option value="">--Select User--</option>
                        <?php 

                $sql = "SELECT * FROM ".TABLE_USER." where mobile !='' ORDER BY id DESC"; 

            $res = $db->selectData($sql);

            while($row_rec = $db->getRow($res)){

              
            ?>
                        <option value="<?=$row_rec['id'];?>"><?=$row_rec['name'];?> (<?=$row_rec['user_sponsorid'];?>)</option>
                    <?php }?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Amount(Rs.)</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control numeric_input" id="amount" placeholder="Enter amount" name="amount" maxlength="10" required>
                </div>
            </div>

            <!-- <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Description</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="description" placeholder="Description" name="description" >
                </div>
            </div> -->

            <div class="box-footer">
            <a href="bonus_list.php" type="button" class="btn btn-info">Back</a>
                <button type="submit" class="btn btn-info">Generate</button>
            </div>
            </div>
        </form>
        </div>
    </section>
</div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?>

<script type="text/javascript">
         $(document).ready(function() {
    $('.numeric_input').keydown(function(event) {
return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )


      
    });
});

     </script>  