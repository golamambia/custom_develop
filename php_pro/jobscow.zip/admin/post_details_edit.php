<?php 
include('includes/admin_top.php'); 
$msg ="";
$error_msg ="";
//if((isset($_SESSION['ADMIN']['id'])) and ($_SESSION['ADMIN']['id'] != "")){

$sid=base64_decode($_REQUEST['edit']);
if(isset($_POST['changeProfile']) && $_POST['changeProfile']=='changeProfile'){
       if($_FILES['logo1']['name']!=''){
            $arr=getimagesize($_FILES['logo1']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['logo1']['name'])));
            
            if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){
               
                    $tmp_name = $_FILES['logo1']['tmp_name'];
                    $name = time()."_".$_FILES['logo1']['name'];
                    move_uploaded_file($tmp_name, HOME_UPLOAD.$name);
                    $_POST['logo'] = $name;

                    
            }else{
                $msg_class = 'alert-error';
                $msg="Must be .jpeg/.jpg/.png/.gif please check extension";
            }
        } 
$db->updateArray(TABLE_POSTJOB,$_POST, "id=".$sid);

$msg_class = 'alert-success';
$msg = MSG_EDIT_SUCCESS;
}

$GET_USER_UPDATE = $pm->getTableDetails(TABLE_POSTJOB,'id',$sid);

//}

?>  
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<!-- Main Header -->
<?php include('includes/admin_header.php'); ?>  
<!-- Left side column. contains the logo and sidebar -->
<?php include('includes/admin_sidebar.php'); ?>  
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<section class="content-header">
<?php
if((isset($_SESSION['ADMIN']['id'])) and ($_SESSION['ADMIN']['id'] != "")){
?>

<h1>USER POST</h1>
<?php }?>
</section>
<section class="content">
<?php if((isset($msg)) and ($msg != '')){ ?>
<div class="alert <?php echo $msg_class; ?> alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<p><?php echo $msg; ?></p>
</div>
<?php } ?>
<div class="box box-info">
<div class="box-header with-border">
<h3 class="box-title">Update Details</h3>
</div>
<?php
if((isset($_SESSION['ADMIN']['id'])) and ($_SESSION['ADMIN']['id'] != "")){
?>

<form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="changeProfile" value="changeProfile">

<div class="box-body">
<div class="form-group">
<label for="inputEmail3" class="col-sm-2 control-label">job title<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="title" name="title" placeholder="title" value="<?php echo $GET_USER_UPDATE['title']; ?>" required>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Email<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="email" placeholder="email" name="email" value="<?php echo $GET_USER_UPDATE['email']; ?>" required>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Application email/URL<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="application" placeholder="Application email/URL" name="application" value="<?php echo $GET_USER_UPDATE['application']; ?>" required>
</div>
</div>

<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Location<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<select class="form-control" name="location" id="location" required>
                        <option value="">--Location--</option>
                        <option value="india" <?php if($GET_USER_UPDATE['location']=='india'){ echo"selected";}?>>India</option>
                        <option value="canada" <?php if($GET_USER_UPDATE['location']=='canada'){ echo"selected";}?>>Canada</option>
                        
                    </select>
</div>
</div>
<div class="form-group">
<label for="inputEmail3" class="col-sm-2 control-label">Job Location<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<textarea name="job_location"  class="form-control" placeholder="Job Location" required><?php echo $GET_USER_UPDATE['job_location']; ?></textarea>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Job Description<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<textarea name="description"  class="form-control" placeholder="Job description" required><?php echo $GET_USER_UPDATE['description']; ?></textarea>
</div>
</div>

<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Qualification<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<textarea name="qualification" id="editor1"  class="form-control" placeholder="Job description" required><?php echo $GET_USER_UPDATE['qualification']; ?></textarea>
</div>
</div>

<div class="form-group">
<label for="inputEmail3" class="col-sm-2 control-label">job region<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="job_region" name="job_region" placeholder="job region" value="<?php echo $GET_USER_UPDATE['job_region']; ?>" required>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">job type<span style="color:#F00">*</span></label>
<div class="col-sm-5">
            <select class="form-control" name="job_type" id="job_type" required>
                        <option value="">--Job Type--</option>
                        <option value="full_time" <?php if($GET_USER_UPDATE['job_type']=='full_time'){ echo"selected";}?>>Full Time</option>
                        <option value="part_time" <?php if($GET_USER_UPDATE['job_type']=='part_time'){ echo"selected";}?>>Part Time</option>
                        <option value="contractual" <?php if($GET_USER_UPDATE['job_type']=='contractual'){ echo"selected";}?>>Contractual</option>
                    </select>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">job category<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<select name="job_category" id="job_category" required class="form-control">
            <option value="" selected="selected">SELECT CATEGORY</option>
             <?php 
            $sql = "SELECT * FROM ".TABLE_BUSINESSTYPE." ORDER BY name asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
                    <option value="<?php echo $row_rec['id']; ?>" <?php if($GET_USER_UPDATE['job_category']==$row_rec['id']){ echo"selected";}?>><?php echo $row_rec['name']; ?></option>
                    
                    <?php } ?>
                </select>
</div>
</div>

<div class="form-group">
<label for="inputEmail3" class="col-sm-2 control-label">Salary range<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" name="salary_range" class="form-control" value="<?php echo $GET_USER_UPDATE['salary_range']; ?>" placeholder="salary range" required>
                    
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Job end date<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="date" class="form-control" id="job_end"  name="job_end" value="<?php echo $GET_USER_UPDATE['job_end']; ?>" required>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Vacancy<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="vacancy" placeholder="Vacancy" name="vacancy" value="<?php echo $GET_USER_UPDATE['vacancy']; ?>" required>
</div>
</div>
<div class="form-group">
    <label for="inputPassword3" class="col-sm-8 control-label" style="text-align: center;
    font-size: 21px;">Company detals</label>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Company name<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="company_name" placeholder="Company name" name="company_name" value="<?php echo $GET_USER_UPDATE['company_name']; ?>" required>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Company tagline<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="tagline" placeholder="company tagline" name="tagline" value="<?php echo $GET_USER_UPDATE['tagline']; ?>" required>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Company description<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="company_desc" placeholder="Company description" name="company_desc" value="<?php echo $GET_USER_UPDATE['company_desc']; ?>" required>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">facebook profile url<span style="color:#F00"></span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="fb_name" placeholder="facebook profile url" name="fb_name" value="<?php echo $GET_USER_UPDATE['fb_name']; ?>" >
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Twitter profile url<span style="color:#F00"></span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="tt_name" placeholder="twitter profile url" name="tt_name" value="<?php echo $GET_USER_UPDATE['tt_name']; ?>" >
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Linkedin profile url<span style="color:#F00"></span></label>
<div class="col-sm-5">
<input type="text" class="form-control" id="ld_name" placeholder="Linkedin profile url" name="ld_name" value="<?php echo $GET_USER_UPDATE['ld_name']; ?>" >
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Upload company logo<span style="color:#F00">*</span></label>
<div class="col-sm-5">
<input type="file" class="form-control" id="logo1" name="logo1" >
</div>
<div class="col-sm-5">
    <?PHP if($GET_USER_UPDATE['logo']!='' && file_exists(HOME_UPLOAD.$GET_USER_UPDATE['logo']))
                {
                ?>
<img src="<?PHP echo HOME_UPLOAD.$GET_USER_UPDATE['logo']?>" height="60"/>
<?PHP 
                }
                ?> 
</div>
</div>

            
               
</div>
<div class="box-footer">
<button type="submit" class="btn btn-info">Save</button>
</div>
</form>


<?php }?>
</div>

</section>
</div>
<script type="text/javascript">
    function get_state(val2,val,id) {
//alert(val);

$.ajax({
type: "POST",
url: "../get_state.php",
data: 'val=' + val+'&val2='+val2,
cache: false,
success: function(html) {
//alert(html);
   $("#"+id).html(html);

}
});

return false;
}
</script>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?> 