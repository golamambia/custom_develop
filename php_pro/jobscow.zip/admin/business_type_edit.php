<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $editid = $_REQUEST['edit'];
    $page_title = 'Update - Business Category';

    if(isset($_POST['update_country']) && $_POST['update_country']=='update_country'){
		if($_FILES['image_1']['name']!=''){
            $arr=getimagesize($_FILES['image_1']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['image_1']['name'])));
            
            if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){
               
                    $tmp_name = $_FILES['image_1']['tmp_name'];
                    $name = time()."_".$_FILES['image_1']['name'];
                    move_uploaded_file($tmp_name, HOME_UPLOAD.$name);
                    $_POST['image1'] = $name;

                    
            }else{
                $msg_class = 'alert-error';
                $msg="Must be .jpeg/.jpg/.png/.gif please check extension";
            }
        }
        $db->updateArray(TABLE_BUSINESSTYPE,$_POST, "id=".$editid) or die(mysql_error());
        $msg_class = 'alert-success';
        $msg = MSG_EDIT_SUCCESS;
    }
    $get_country = $pm->getTableDetails(TABLE_BUSINESSTYPE,'id',$editid);
?>  

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
    <!-- Main Header -->
        <?php include('includes/admin_header.php'); ?>  

        <!-- Left side column. contains the logo and sidebar -->
        <?php include('includes/admin_sidebar.php'); ?>  

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1><?php echo $page_title; ?></h1>
        </section>

        <section class="content">
            <?php if((isset($msg)) and ($msg != ''))
            { ?>
            <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
            </div>
            <?php 
            } 
            ?>
            <div class="box box-info">
            <!-- form start -->
            <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
            
                <input type="hidden" name="update_country" value="update_country">
                <div class="box-body">

               
                <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-5">
                <input type="text" class="form-control" placeholder="Country name" name="name" required value="<?php echo $get_country['name']; ?>">
                </div>
            </div>
				<div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Image</label>
                <div class="col-sm-5">
                <input type="file" class="form-control"  name="image_1" id="file" >
                </div>
            </div>
            <?PHP if($get_country['image1']!='' && file_exists(HOME_UPLOAD.$get_country['image1']))
                {
                ?>
                    <div class="field-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">&nbsp;</label>
                        <div><img src="<?PHP echo HOME_UPLOAD.$get_country['image1']?>" height="60"/></div>
                    </div>
                <?PHP 
                }
                ?> <br>


              

                <div class="box-footer">                    
                    <a href="business_type_list.php" type="button" class="btn btn-info">Close</a>
                    <button type="submit" class="btn btn-info">update</button>
                </div>

                </div>
            </form>
            </div>
        </section>
        
        </div>
    </div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?> 
<script type="text/javascript">
    $(document).ready(function(){
        //alert(1);
    $("#file").change(function() {
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];
        
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
            alert('Please select a valid image file (JPEG/JPG/PNG).');
            $("#file").val('');
            return false;
        }
    });
     });
</script>