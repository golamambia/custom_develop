<aside class="main-sidebar">
<section class="sidebar">
<div class="user-panel">
<div class="pull-left image" style="height:50px;">
<!--<img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">-->
</div>
<div class="pull-left info" style="left:0px">
<p>
<?php
if((isset($_SESSION['ADMIN']['id'])) and ($_SESSION['ADMIN']['id'] != ""))
echo $_SESSION['ADMIN']['name'];
else
echo $_SESSION['USER']['name'];
?>
</p>
<a href="<?php $gf->linkURL('admin/dashboard.php');?>"><i class="fa fa-circle text-success"></i> Online</a>
</div>
</div>
<?php if((isset($_SESSION['ADMIN']['id'])) and ($_SESSION['ADMIN']['id'] != "")){ ?>
<ul class="sidebar-menu">
<li class="<?php if($getPageName == 'dashboard.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/dashboard.php');?>"><i class="fa fa-link"></i> <span>Dashboard</span></a></li>

<li class="treeview <?php if($getPageName == 'country_add.php' || $getPageName == 'country_edit.php' || $getPageName == 'country_list.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Country Section</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li><a href="<?php $gf->linkURL('admin/country_add.php');?>">Country Add</a></li>
    <li><a href="<?php $gf->linkURL('admin/country_list.php');?>">Country List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'state_add.php' || $getPageName == 'state_edit.php' || $getPageName == 'state_list.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>State Section</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li><a href="<?php $gf->linkURL('admin/state_add.php');?>">State Add</a></li>
    <li><a href="<?php $gf->linkURL('admin/state_list.php');?>">State List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'city_add.php' || $getPageName == 'city_edit.php' || $getPageName == 'city_list.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>City Section</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li><a href="<?php $gf->linkURL('admin/city_add.php');?>">City Add</a></li>
    <li><a href="<?php $gf->linkURL('admin/city_list.php');?>">City List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'business_type_add.php' || $getPageName == 'business_type_edit.php' || $getPageName == 'business_type_list.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Business Category</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li><a href="<?php $gf->linkURL('admin/business_type_add.php');?>">Add</a></li>
    <li><a href="<?php $gf->linkURL('admin/business_type_list.php');?>">List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'home_page_content.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Home Page Content</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li><a href="<?php $gf->linkURL('admin/home_page_content.php');?>">Content Update</a></li>
    <!--<li><a href="<?php $gf->linkURL('admin/home_slider_list.php');?>">Slider List</a></li>-->
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'home_slider_edit.php' || $getPageName == 'home_slider_list.php' || $getPageName == 'home_slider_add.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Home Page Banner</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li><a href="<?php $gf->linkURL('admin/home_slider_edit.php');?>">Banner Update</a></li>
    <!--<li><a href="<?php $gf->linkURL('admin/home_slider_list.php');?>">Slider List</a></li>-->
    </ul>
</li>

<li class="treeview <?php if($getPageName == 'hiring-add.php' || $getPageName == 'hiring-list.php' || $getPageName == 'hiring-edit.php' ){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Top Hiring Companies</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <!--<li><a href="<?php $gf->linkURL('admin/hiring-add.php');?>">Company Add</a></li>-->
    <li><a href="<?php $gf->linkURL('admin/hiring-list.php');?>">Company List</a></li>
    </ul>
</li>

<!--<li class="treeview <?php if($getPageName == 'category-add.php' || $getPageName == 'category-list.php' || $getPageName == 'category-edit.php'){?> active <?php }?>">-->
<!--<a href="#"><i class="fa fa-users"></i> <span>Category</span> <i class="fa fa-angle-left pull-right"></i></a>-->
<!--    <ul class="treeview-menu">-->
<!--        <li><a href="<?php $gf->linkURL('admin/category-add.php');?>"><i class="fa fa-user-plus" aria-hidden="true"></i>Add Category</a></li>-->
<!--        <li><a href="<?php $gf->linkURL('admin/category-list.php');?>"><i class="fa fa-user-plus" aria-hidden="true"></i>List Category</a></li>-->
<!--    </ul>-->
<!--</li>-->
<!--<li class="treeview <?php if($getPageName == 'subcategory-add.php' || $getPageName == 'subcategory-list.php' || $getPageName == 'subcategory-edit.php'){?> active <?php }?>">-->
<!--<a href="#"><i class="fa fa-users"></i> <span>Sub-Category</span> <i class="fa fa-angle-left pull-right"></i></a>-->
<!--    <ul class="treeview-menu">-->
<!--        <li><a href="<?php $gf->linkURL('admin/subcategory-add.php');?>"><i class="fa fa-user-plus" aria-hidden="true"></i>Add Sub-Category</a></li>-->
<!--        <li><a href="<?php $gf->linkURL('admin/subcategory-list.php');?>"><i class="fa fa-user-plus" aria-hidden="true"></i>List Sub-Category</a></li>-->
<!--    </ul>-->
<!--</li>-->
<li class="treeview <?php if($getPageName == 'company_add.php' || $getPageName == 'company_edit.php' || $getPageName == 'company_list.php'){?> active <?php }?>">
<a href="#"><i class="fa fa-users"></i> <span>Employeer</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <!-- <li><a href="<?php $gf->linkURL('admin/company_add.php');?>"><i class="fa fa-user-plus" aria-hidden="true"></i>Add Employeer</a></li> -->
        <li><a href="<?php $gf->linkURL('admin/company_list.php');?>"><i class="fa fa-user-plus" aria-hidden="true"></i>List Employeer</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'post_details_edit.php' || $getPageName == 'post_details_list.php' || $getPageName == 'job_applyer_list.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Job Post Details</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li><a href="<?php $gf->linkURL('admin/post_details_list.php');?>">Job Post List</a></li>
       <li><a href="<?php $gf->linkURL('admin/job_applyer_list.php');?>">Job Applyer List</a></li>
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'jobseeker_list.php' || $getPageName == 'jobseeker_edit.php'){?> active <?php }?>">
<a href="#"><i class="fa fa-users"></i> <span>Job Seeker</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <!-- <li><a href="<?php $gf->linkURL('admin/company_add.php');?>"><i class="fa fa-user-plus" aria-hidden="true"></i>Add Employeer</a></li> -->
        <li><a href="<?php $gf->linkURL('admin/jobseeker_list.php');?>"><i class="fa fa-user-plus" aria-hidden="true"></i>List Job Seeker</a></li>
    </ul>
</li>
<li class="treeview <?php if( $getPageName == 'privacy_edit.php' || $getPageName == 'terms_edit.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Terms & Privacy</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
        <li><a href="<?php $gf->linkURL('admin/privacy_edit.php');?>">Privacy & Policy </a></li>
        <li><a href="<?php $gf->linkURL('admin/terms_edit.php');?>">Terms & Conditions</a></li>
         
   
    </ul>
</li>
<li class="treeview <?php if($getPageName == 'change_password.php' || $getPageName == 'profile.php' || $getPageName == 'setting.php'){?> active <?php }?>">
    <a href="#"><i class="fa fa-file-text-o"></i> <span>Profile Section</span> <i class="fa fa-angle-left pull-right"></i></a>
    <ul class="treeview-menu">
    	<li><a href="<?php $gf->linkURL('admin/profile.php');?>">Admin Profile</a></li>
    	<li><a href="<?php $gf->linkURL('admin/setting.php');?>">Settings</a></li>
    <li><a href="<?php $gf->linkURL('admin/change_password.php');?>">Change Password</a></li>
    </ul>
</li>

<li class="<?php if($getPageName == 'logout.php'){?> active <?php }?>"><a href="<?php $gf->linkURL('admin/logout.php');?>" onclick="return confirm('Are You Sure You Want To Logout !!')"><i class="glyphicon glyphicon-log-out"></i> <span>Logout</span></a></li>


</ul>
<?php }else{ ?>
<ul class="sidebar-menu">

<li><a href="<?php $gf->linkURL('admin/logout.php');?>" onclick="return confirm('Are You Sure To Logout !!')"><i class="glyphicon glyphicon-log-out"></i> <span>Logout</span></a></li>
</ul>
<?php } ?>
</section>
</aside>
