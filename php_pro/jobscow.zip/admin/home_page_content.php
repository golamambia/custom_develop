<?php 

include('includes/admin_top.php'); 

    $msg ="";

    $editid = 1;

    $page_title = 'Update - Content';



    if(isset($_POST['update_banner']) && $_POST['update_banner']=='update_banner'){

        if($_FILES['service_img']['name']!=''){

            $arr=getimagesize($_FILES['service_img']['tmp_name']);

            $userfile_extn = end(explode(".", strtolower($_FILES['service_img']['name'])));

            

            if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){

               

                    $tmp_name = $_FILES['service_img']['tmp_name'];

                    $name = time()."_".$_FILES['service_img']['name'];

                    move_uploaded_file($tmp_name, HOME_BANNER_IMAGE_PATH.$name);

                    $_POST['service_img'] = $name;



                    

            }else{

                $msg_class = 'alert-error';

                $msg="Must be .jpeg/.jpg/.png/.gif please check extension";

            }

        }else{

           $_POST['service_img']=$_POST['img1']; 

        }

        
        $_POST['entry_date'] = date('d-m-Y');




            $db->updateArray(TABLE_PAGE_LISTING,$_POST, "id=".$editid) or die(mysql_error());

            $msg_class = 'alert-success';

            $msg = MSG_EDIT_SUCCESS;

        

    }

    $get_slider = $pm->getTableDetails(TABLE_PAGE_LISTING,'id',$editid);

?>  



<body class="hold-transition skin-blue sidebar-mini">

    <div class="wrapper">

    <!-- Main Header -->

        <?php include('includes/admin_header.php'); ?>  



        <!-- Left side column. contains the logo and sidebar -->

        <?php include('includes/admin_sidebar.php'); ?>  



        <!-- Content Wrapper. Contains page content -->

        <div class="content-wrapper">



        <!-- Content Header (Page header) -->

        <section class="content-header">

            <h1><?php echo $page_title; ?></h1>

        </section>



        <section class="content">

            <?php if((isset($msg)) and ($msg != ''))

            { ?>

            <div class="alert <?php echo $msg_class; ?> alert-dismissable">

            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

            <p><?php echo $msg; ?></p>

            </div>

            <?php 

            } 

            ?>

            <div class="box box-info">

            <!-- form start -->

            <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">

            

                <input type="hidden" name="update_banner" value="update_banner">

                <input type="hidden" name="img1" value="<?=$get_slider['service_img'];?>">

                <input type="hidden" name="img2" value="<?=$get_slider['slider_img'];?>">

                <div class="box-body">



                
<div class="form-group">

                <label for="inputPassword3" class="col-sm-5 control-label" style="text-align:centre;">For Employeer</label>

                

            </div>


<div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Title</label>

                <div class="col-sm-5">

                    <input type="text" class="form-control" value="<?=$get_slider['title'];?>" id="title" placeholder="" name="title" required>

                </div>

            </div>



            <div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Short Description</label>

                <div class="col-sm-5">

                    <textarea  class="form-control" rows="5" id="description" placeholder="" name="description" required><?=$get_slider['description'];?></textarea>

                </div>

            </div>

            

               <div class="form-group">

                <label for="inputPassword3" class="col-sm-5 control-label" style="text-align:centre;">For Job Seeker</label>

                

            </div>


<div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Title</label>

                <div class="col-sm-5">

                    <input type="text" class="form-control" value="<?=$get_slider['title2'];?>" id="title2" placeholder="" name="title2" required>

                </div>

            </div>



            <div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Short Description</label>

                <div class="col-sm-5">

                    <textarea  class="form-control" rows="5" id="description2" placeholder="" name="description2" required><?=$get_slider['description2'];?></textarea>

                </div>

            </div>

            


            




                <div class="box-footer">                    

                    

                    <button type="submit" class="btn btn-info">Submit</button>

                </div>



                </div>

            </form>

            </div>

        </section>

        

        </div>

    </div>

<!-- /.content-wrapper -->

<?php include('includes/admin_footer.php'); ?> 