<?php 

include('includes/admin_top.php'); 

    $msg ="";

    $editid = $_REQUEST['edit'];

    $page_title = 'Update - Job Seeker';



    if(isset($_POST['update_emp']) && $_POST['update_emp']=='update_emp'){

      if($_FILES['upload_resume1']['name']!=''){
            $arr=getimagesize($_FILES['upload_resume1']['tmp_name']);
            $userfile_extn = end(explode(".", strtolower($_FILES['upload_resume1']['name'])));
            
           // if(($userfile_extn =="doc" || $userfile_extn =="pdf" || $userfile_extn =="docx")){
               
                    $tmp_name = $_FILES['upload_resume1']['tmp_name'];
                    $name = time()."_".$_FILES['upload_resume1']['name'];
                    move_uploaded_file($tmp_name, HOME_UPLOAD.$name);
                    $_POST['upload_resume'] = $name;

                    
                   }

           
            $db->updateArray(TABLE_JOBSREG,$_POST, "id=".$editid);
            $db->updateArray(TABLE_JOBSLOG,$_POST, "id=".$editid);

            $msg_class = 'alert-success';

            $msg = MSG_EDIT_SUCCESS;

       

    }

    $get_des = $pm->getTableDetails(TABLE_JOBSLOG,'id',$editid);
    $get_des_reg = $pm->getTableDetails(TABLE_JOBSREG,'id',$editid);

?>  



<body class="hold-transition skin-blue sidebar-mini">

    <div class="wrapper">

    <!-- Main Header -->

        <?php include('includes/admin_header.php'); ?>  



        <!-- Left side column. contains the logo and sidebar -->

        <?php include('includes/admin_sidebar.php'); ?>  



        <!-- Content Wrapper. Contains page content -->

        <div class="content-wrapper">



        <!-- Content Header (Page header) -->

        <section class="content-header">

            <h1><?php echo $page_title; ?></h1>

        </section>



        <section class="content">

            <?php if((isset($msg)) and ($msg != ''))

            { ?>

            <div class="alert <?php echo $msg_class; ?> alert-dismissable">

            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

            <p><?php echo $msg; ?></p>

            </div>

            <?php 

            } 

            ?>

            <div class="box box-info">

            <!-- form start -->

            <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">

            

                <input type="hidden" name="update_emp" value="update_emp">

                <div class="box-body">

                <div class="form-group">


            <label for="inputPassword3" class="col-sm-9 control-label" style="text-align: center;">Login Info</label>


            </div>
          


            <div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Email</label>

                <div class="col-sm-5">

                    <input type="email" class="form-control" id="reg_email" placeholder="" name="reg_email" required value="<?=$get_des['reg_email'];?>">

                </div>

            </div>

            



            
            <div class="form-group">

            <label for="inputPassword3" class="col-sm-2 control-label">Status</label>

                <div class="col-sm-5">

                    

                    <select name="status" id="status" class="form-control" required>

                         <option <?php if('Active'==$get_des['status']){ echo"selected";}?> value="Active" >Active</option>

                         <option <?php if('Inactive'==$get_des['status']){ echo"selected";}?> value="Inactive" >Inactive</option>

                         </select>

                </div>

            </div>

<div class="form-group">


            <label for="inputPassword3" class="col-sm-9 control-label" style="text-align: center;">Job Seeker Info</label>


            </div>
            <div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Name</label>



                <div class="col-sm-5">

<input class="form-control" id="contact_person"  name="contact_person" placeholder="Name" type="text" value="<?=$get_des_reg['contact_person'];?>"  required>


                </div>



            </div>
           <div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Address 1</label>



                <div class="col-sm-5">



                    <input type="text" class="form-control" value="<?=$get_des_reg['address1'];?>" id="address1" placeholder="Address 1" name="address1" required >



                </div>



            </div>
            <div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Address 2</label>



                <div class="col-sm-5">



                    <input type="text" class="form-control" value="<?=$get_des_reg['address2'];?>" id="address2" placeholder="Address 2" name="address2" required >



                </div>



            </div><div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Country</label>



                <div class="col-sm-5">



                    
                    <select class="form-control" name="country" id="country" onchange="get_state('st',this.value,'state','city')" required>
                        <option value="">--Select Country--</option>
                       <?php 
            $sql = "SELECT * FROM ".TABLE_COUNTRY." ORDER BY id DESC";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
            <option value="<?php echo $row_rec['id']; ?>" <?php if($row_rec['id']==$get_des_reg['country']){ echo"selected"; }?>><?php echo $row_rec['name']; ?></option>
          <?php }?>
                      </select>

                </div>



            </div><div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Province / State</label>



                <div class="col-sm-5">


                    
                    <select class="form-control" name="state" id="state" required onchange="get_state('ct',this.value,'city')">
                        <option value="">Province / State</option>
                        <?php 
                                                    $sql = "SELECT * FROM ".TABLE_STATE." where country_id='$get_des_reg[country]' ORDER BY id DESC";
                                                    $res = $db->selectData($sql);
                                                    while($row_rec = $db->getRow($res)){
                                                    ?>
                                                    <option value="<?php echo $row_rec['id']; ?>" <?php if($row_rec['id']==$get_des_reg['state']){ echo"selected"; }?>><?php echo $row_rec['name']; ?></option>
                                                    <?php }?>
                      </select>


                </div>



            </div><div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">City / Village</label>



                <div class="col-sm-5">

<select class="form-control" name="city" id="city" required>
                        <option value="">City / Village</option>
                        <?php 
                                                        $sql = "SELECT * FROM ".TABLE_CITY." where id='$get_des_reg[city]' ORDER BY id DESC";
                                                        $res = $db->selectData($sql);
                                                        while($row_rec = $db->getRow($res)){
                                                        ?>
                                                        <option value="<?php echo $row_rec['id']; ?>" <?php if($row_rec['id']==$get_des_reg['city']){ echo"selected"; }?>><?php echo $row_rec['name']; ?></option>
                                                    <?php }?>
                      </select>


                </div>



            </div><div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Postal Code</label>



                <div class="col-sm-5">



                    <input class="form-control" value="<?=$get_des_reg['postal'];?>"  name="postal" id="postal" placeholder="Postal Code" type="text"  required maxlength="6" onkeydown="return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )">



                </div>



            </div>
            <div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Cellphone</label>



                <div class="col-sm-5">

 <input class="form-control" id="phone" name="phone" placeholder="Cellphone" type="text"  required maxlength="11" onkeydown="return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )" value="<?=$get_des_reg['phone'];?>" >



                </div>



            </div>


<div class="form-group">


            <label for="inputPassword3" class="col-sm-9 control-label" style="text-align: center;">Job Seeker Skills</label>


            </div>
            <div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Education</label>



                <div class="col-sm-5">

<select class="form-control" name="education_type" id="education_type" required>
            <option value="-1">Select Highest Education</option>                    <option value="Architecture">Architecture</option>   
                                        <option value="Architecture" <?php if($get_des_reg['education_type']=='Architecture'){ echo"selected"; }?>>Architecture</option>
                                                    <option value="B.Pharma" <?php if($get_des_reg['education_type']=='B.Pharma'){ echo"selected"; }?>>B.Pharma</option>
                                                    <option value="Bachelore degree" <?php if($get_des_reg['education_type']=='Architecture'){ echo"selected"; }?>>Bachelore degree</option>
                                                    <option value="BBA" <?php if($GET_USER_UPDATE['education_type']=='Bachelore degree'){ echo"selected"; }?>>BBA</option>
                                                    <option value="Charter Accountant" <?php if($get_des_reg['education_type']=='Charter Accountant'){ echo"selected"; }?>>Charter Accountant</option>
                                                    <option value="Designer" <?php if($get_des_reg['education_type']=='Designer'){ echo"selected"; }?>>Designer</option>
                                                    <option value="Diploma" <?php if($get_des_reg['education_type']=='Diploma'){ echo"selected"; }?>>Diploma</option>
                                                    <option value="Doctor" <?php if($get_des_reg['education_type']=='Doctor'){ echo"selected"; }?>>Doctor</option>
                                                    <option value="Engineer" <?php if($get_des_reg['education_type']=='Engineer'){ echo"selected"; }?>>Engineer</option>
                                                    <option value="Graduation" <?php if($get_des_reg['education_type']=='Graduation'){ echo"selected"; }?>>Graduation</option>
                                                    <option value="High school completed" <?php if($get_des_reg['education_type']=='High school completed'){ echo"selected"; }?>>High school completed</option>
                                                    <option value="High School not completed" <?php if($get_des_reg['education_type']=='High School not completed'){ echo"selected"; }?>>High School not completed</option>
                                                    <option value="Master degree" <?php if($get_des_reg['education_type']=='Master degree'){ echo"selected"; }?>>Master degree</option>
                                                    <option value="Master in Business Administrator" <?php if($get_des_reg['education_type']=='Master in Business Administrator'){ echo"selected"; }?>>Master in Business Administrator</option>                                                    
                                                    <option value="Phd" <?php if($get_des_reg['education_type']=='Phd'){ echo"selected"; }?>>Phd</option>
                                                    <option value="Post Graduate" <?php if($get_des_reg['education_type']=='Post Graduate'){ echo"selected"; }?>>Post Graduate</option>
                                                    <option value="Post graduation" <?php if($get_des_reg['education_type']=='Post graduation'){ echo"selected"; }?>>Post graduation</option>
                                                    <option value="Social Science" <?php if($get_des_reg['education_type']=='Social Science'){ echo"selected"; }?>>Social Science</option>
                                                    <option value="Technical Diploma" <?php if($get_des_reg['education_type']=='Technical Diploma'){ echo"selected"; }?>>Technical Diploma</option>
                                                    <option value="Others" <?php if($get_des_reg['education_type']=='Others'){ echo"selected"; }?>>Others</option>
                </select>


                </div>



            </div>
           <div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">job title</label>



                <div class="col-sm-5">



                     <input class="form-control" id="job_title" name="job_title" placeholder="Most recent job title" type="text" value="<?=$get_des_reg['job_title'];?>" required>



                </div>



            </div>
            <div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Skills</label>



                <div class="col-sm-5">



                    <input class="form-control" placeholder="Skills" id="skill" name="skill" type="text" value="<?=$get_des_reg['skill'];?>" >



                </div>



            </div><div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Job preference</label>



                <div class="col-sm-5">



                    
                    <input class="form-control" placeholder="Job preference" id="job_prefence" name="job_prefence" type="text"  value="<?=$get_des_reg['job_prefence'];?>" >

                </div>



            </div><div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Category</label>



                <div class="col-sm-5">


                    
                   <select class="form-control" name="employer_type" id="employer_type" required>
            <option value="" selected="selected">Job match Category</option>
             <?php 
            $sql = "SELECT * FROM ".TABLE_BUSINESSTYPE." ORDER BY name asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
                    <option <?php if($get_des_reg['employer_type']==$row_rec['id']){echo"selected";}?> value="<?php echo $row_rec['id']; ?>"><?php echo $row_rec['name']; ?></option>
                    
                    <?php } ?>
                </select>


                </div>



            </div>
            <div class="form-group">



                <label for="inputPassword3" class="col-sm-2 control-label">Upload Resume</label>



                <div class="col-sm-5">

 <input type="file" class="form-control" id="upload_resume1" name="upload_resume1" >



                </div>
     <div class="col-sm-5">
    <?PHP if($get_des_reg['upload_resume']!='' && file_exists(HOME_UPLOAD.$get_des_reg['logo']))
                {
                ?>
<a class="form-control" href="<?PHP echo HOME_UPLOAD.$get_des_reg['upload_resume'];?>" download>
                        <img src="images/download.png" style="width: 40px;" alt="">Download Now
                    </a>
<?PHP 
                }
                ?> 
</div>



            </div>


                <div class="box-footer">                    

                    <a href="jobseeker_list.php" type="button" class="btn btn-info">Close</a>

                    <button type="submit" class="btn btn-info">Submit</button>

                </div>



                </div>

            </form>

            </div>

        </section>

        

        </div>

    </div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">

   function get_cat(val) {

//alert(val);



$.ajax({

type: "POST",

url: "get_subcat.php",

data: 'val=' + val,

cache: false,

success: function(html) {

//alert(html);

$("#designation").html(html);

}

});



return false;

}
function get_state(val2,val,id) {
//alert(val);

$.ajax({
type: "POST",
url: "get_state.php",
data: 'val=' + val+'&val2='+val2,
cache: false,
success: function(html) {
//alert(html);
   $("#"+id).html(html);

}
});

return false;
}
$(document).ready(function(){
                  //alert(1);
  
 $("#upload_resume1").change(function() {
        var file = this.files[0];
        var imagefile = file.type;
        //alert(imagefile);
        var match= ["application/msword","application/pdf","application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
            alert('Please select a valid  file (DOC/PDF).');
            $("#upload_resume1").val('');
            return false;
        }
    });

  });
</script>



<!-- /.content-wrapper -->

<?php include('includes/admin_footer.php'); ?> 