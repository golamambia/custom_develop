<?php 

include('includes/admin_top.php'); 

    $msg ="";

    $page_title = 'Item Order  - Add';

    // $id = $_REQUEST['id'];



    if(isset($_POST['add_work']) && $_POST['add_work']=='add_work'){



        $_POST['entry_date']=date('d-m-Y');

        $checkbox1 = $_POST['pdepartment'];

       

        $get_last_id = $db->insertDataArray(TABLE_ITEM_ORDER,$_POST);

        //$_POST['item_order_id']=$get_last_id;
        $nn='';
        for($count=0;$count<count($checkbox1);$count++)

        {

            $data['item_order_id']=$get_last_id;

            $data['pdepartment']=$_POST['pdepartment'][$count];

            $data['sub_pdepartment']=$_POST['sub_pdepartment'][$count];

            $data['item_code']=$_POST['item_code'][$count];

            $data['item_name']=$_POST['item_name'][$count];

            $data['description']=$_POST['description'][$count];

            $data['item_qty']=$_POST['item_qty'][$count];


            //$chk.=$count;

            $get_last_id2 = $db->insertDataArray(TABLE_ITEM_ORDER_PART,$data);
            
             $nn=$get_last_id2;
             //$name2='';
        if($_FILES['multi_upload']['name']!=''){
            $filename = $_FILES['multi_upload']['name'];
            $file_tmp = $_FILES['multi_upload']['tmp_name'];
            $filetype = $_FILES['multi_upload']['type'];
            $filesize = $_FILES['multi_upload']['size'];
            
            for($i=0; $i<=count($file_tmp); $i++){
                if(!empty($file_tmp[$i])){
                    $arr=getimagesize($file_tmp[$i]);
                    $userfile_extn = end(explode(".", strtolower($filename[$i])));
                    
                    if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){
                        $tmp_name = $file_tmp[$i];
                        $name = time()."_".$filename[$i];
                        //$name2.=$name.",";
                        move_uploaded_file($tmp_name, HOME_UPLOAD.$name);
                        //$_POST['multi_upload'] = $name2;
                        $_POST['multi_upload'] = $name;
                        $_POST['order_id']=$get_last_id;
                        $_POST['row_no']=$nn;
                        
                        $get_last_id1 = $db->insertDataArray(TABLE_ITEM_ORDER_UPLOAD,$_POST);
                    }
                    else{
                        $msg="Picture's must be .jpeg/.jpg/.png/.gif please check extension";
                    }
                }
                else{
                    $msg="Please select some images...";
                }
            }
        }
        }

        


                    if(!empty($get_last_id)):

                    $msg_class = 'alert-success';

                    $msg = MSG_ADD_SUCCESS;

                    else:

                    $msg_class = 'alert-error';

                    //$msg=$chk;

                    $msg = MSG_ADD_FAIL;

                    endif;



    }

?>  

<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">

    <!-- Main Header -->

    <?php include('includes/admin_header.php'); ?>  

    <!-- Left side column. contains the logo and sidebar -->

    <?php include('includes/admin_sidebar.php'); ?>  

    <!-- Content Wrapper. Contains page content -->

    <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

        <h1><?php echo $page_title; ?></h1>

    </section>



    <section class="content">

        <?php if((isset($msg)) and ($msg != '')){ ?>

        <div class="alert <?php echo $msg_class; ?> alert-dismissable">

            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

            <p><?php echo $msg; ?></p>

        </div>

        <?php } ?>

        <div class="box box-info">

        <!-- form start -->

        <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">

            <input type="hidden" name="add_work" value="add_work">

            <div class="box-body">



            



            <div class="form-group">

            <label for="inputPassword3" class="col-sm-2 control-label">Company</label>

                <div class="col-sm-5">

                    

                    <select name="company" class="form-control" required onchange="get_cat(this.value)">

                        <option value="" >-Select Now-</option>

                        <?php 

            $sql = "SELECT * FROM ".TABLE_COMPANY." ORDER BY company asc";

            $res = $db->selectData($sql);

            while($row_rec = $db->getRow($res)){

            ?>

                        <option value=" <?php echo $row_rec['id']; ?>" > <?php echo $row_rec['company']; ?>(<?php echo $row_rec['company_code']; ?>)</option>

                    <?php }?>

                    </select>

                </div>

            </div>

            <div class="form-group">

            <label for="inputPassword3" class="col-sm-2 control-label">Department</label>

                <div class="col-sm-5">

                    

                    <select name="department" id="department" class="form-control" required>

                        <option value="" >-Select Now-</option>

                        

                    </select>

                </div>

            </div>

            <!-- <div class="form-group">

            <label for="inputPassword3" class="col-sm-2 control-label">Manufacturer</label>

                <div class="col-sm-5">

                    

                    <select name="manufacturer" class="form-control" required>

                        <option value="" >-Select Now-</option>

                        <?php 

            $sql = "SELECT * FROM ".TABLE_PDEPARTMENT." ORDER BY name asc";

            $res = $db->selectData($sql);

            while($row_rec = $db->getRow($res)){

            ?>

                        <option value=" <?php echo $row_rec['id']; ?>" > <?php echo $row_rec['name']; ?></option>

                    <?php }?>

                    </select>

                </div>

            </div> -->

            <div class="form-group">

            <label for="inputPassword3" class="col-sm-2 control-label">Contact Person</label>

                <div class="col-sm-5">

                    

                    <select name="contact_person" class="form-control" required>

                        <option value="" >-Select Now-</option>

                        <?php 

            $sql = "SELECT * FROM ".TABLE_USER." ORDER BY name asc";

            $res = $db->selectData($sql);

            while($row_rec = $db->getRow($res)){

            ?>

                        <option value=" <?php echo $row_rec['id']; ?>" > <?php echo $row_rec['name']; ?></option>

                    <?php }?>

                    </select>

                </div>

            </div>

            <div class="form-group">

            <label for="inputPassword3" class="col-sm-2 control-label">Job Assign</label>

                <div class="col-sm-5">

                    

                    <select name="job_assign" class="form-control" required>

                        <option value="" >-Select Now-</option>

                        <?php 

            $sql = "SELECT * FROM ".TABLE_PARENT_DESIG." ORDER BY name asc";

            $res = $db->selectData($sql);

            while($row_rec = $db->getRow($res)){

            ?>

                        <option value=" <?php echo $row_rec['id']; ?>" > <?php echo $row_rec['name']; ?></option>

                    <?php }?>

                    </select>

                </div>

            </div>


            <div class="form-group">

            <label for="inputPassword3" class="col-sm-2 control-label">Working Status</label>

                <div class="col-sm-5">

                    

                    

                    <select name="work_status" class="form-control" required>

                        

                       <option value="NOT STARTED" selected="selected">Not Started</option>

                            <option value="RECEIVED">Received</option>

                             <option value="STARTED">Started</option>

                        <option value="PENDING">Pending</option>

                            <option value="CANCELLED">Cancelled</option>

                             <option value="COMPLETED">Completed</option>

                    </select>

                </div>

            </div>



            <div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Order Date</label>

                <div class="col-sm-5">

                    <input type="date" class="form-control" id="order_date" placeholder="" name="order_date" required>

                </div>

            </div>

            <div class="form-group">

                <label for="inputPassword3" class="col-sm-2 control-label">Delivery Date</label>

                <div class="col-sm-5">

                    <input type="date" class="form-control" id="delivery_date" placeholder="" name="delivery_date" required>

                </div>

            </div>







            <div class="form-group">

                

                <div class="col-sm-12">

                    



<br>

                <table class="table table-bordered">



        <thead>



        <!-- <a href="add-product.php" type="button" class="btn btn-info">Add</a> -->



            <tr>

                <th>Subject</th>

                <th>Format No</th>



                <th>SOP No</th>



                <th>Pages</th>



                <th>No of Pages</th>



                <th>No of Log Book</th>
                <th>Upload</th>
                <th></th>

            </tr>





        </thead>



        <tbody class="itm_tbl">





            <tr>


                 <td>



                   <div class="form-group">

           

                <div class="col-sm-12">
                    <input type="text" class="form-control" id="pdepartment" placeholder="Subject" name="pdepartment[]" required>

                </div>

            </div>





                </td>



                <td>



                   

                   <div class="form-group">

           

                <div class="col-sm-12">


                        <input type="text" class="form-control" id="sub_pdepartment" placeholder="Format No" name="sub_pdepartment[]" required>

                </div>

            </div>



                </td>



                <td>



                    <div class="form-group">

                

                <div class="col-sm-12">

                    <input type="text" class="form-control" id="item_code" placeholder="SOP No" name="item_code[]" required>

                </div>

            </div>





                </td>

                <td>



                     <div class="form-group">

                

                <div class="col-sm-12">

                    <input type="text" class="form-control" id="order_date" placeholder="Pages" name="item_name[]" required>

                </div>

            </div>



                </td>



                <td>



                    <div class="form-group">

                

                <div class="col-sm-12">
                    <input type="text" class="form-control" id="description" placeholder="No of Pages" name="description[]" required>
                   

                </div>

            </div>



                </td>



                <td>



                    <div class="form-group">

                

                <div class="col-sm-12">

                    <input type="text" class="form-control" id="item_qty" placeholder="No of Log Book" name="item_qty[]" required >

                </div>

            </div>



                </td>
                <td>



                    <div class="form-group">

                

                <div class="col-sm-12">
                    <input type="hidden" name="row_no[]" value="0">
                    <input type="file" class="form-control" id="multi_upload_0" placeholder="" name="multi_upload[]" required multiple>

                </div>

            </div>



                </td>


                <td style="color: red;cursor: pointer;font-size: 20px;font-weight: 600;"></td>



            </tr>


        </tbody>

    </table>



<div  style="float: right;margin-right: 20px; cursor: pointer;" onclick="add_item();">

                            Add Item

                        </div>





                </div>

            </div>



            <div class="box-footer">

            <a href="item_order_list.php" type="button" class="btn btn-info">Back</a>

                <button type="submit" class="btn btn-info">Submit</button>

            </div>

            </div>

        </form>

        </div>

    </section>

</div>

<!-- /.content-wrapper -->



<script type="text/javascript">

   function get_cat(val) {

//alert(val);



$.ajax({

type: "POST",

url: "get_department.php",

data: 'val=' + val,

cache: false,

success: function(html) {

//alert(html);



   

$("#department").html(html);





}

});



return false;

}





 function get_cat1(val,no) {

//alert(no);



$.ajax({

type: "POST",

url: "get_prodepartment.php",

data: 'val=' + val+'&no='+no,

cache: false,

success: function(html) {

//alert(html);



   

$("#sub_pdepartment"+no).html(html);





}

});



return false;

}

 

</script>







            <script type="text/javascript">

                itm=1;

            function add_item() {

             //alert('abcd1');

                            

        

        var st = '<tr id="itm_tbl_row_' + itm + '">'

                    + '<td><input type="text" class="form-control" id="pdepartment_' + itm + '" placeholder="Subject" name="pdepartment[]" required></td>'

                    + '<td><input type="text" class="form-control" id="sub_pdepartment_' + itm + '" placeholder="Format No" name="sub_pdepartment[]" required></td>' //<option value="">--Select--</option>' + prdt_depts + '

                    + '<td> <input type="text" class="form-control padding width" name="item_code[]" id="item_code_' + itm + '" value="" placeholder="SOP No" required></td>'

                    + '<td><input type="text" class="form-control padding width" name="item_name[]" id="item_name_' + itm + '" value="" placeholder="Pages" required></td>'

                    + '<td><input type="text" class="form-control" id="description_' + itm + '" placeholder="No of Pages" name="description[]" required></td>'

                    + '<td><input type="text" class="form-control padding right width" name="item_qty[]" id="item_qty_' + itm + '" value="" placeholder="No of Log Book" required></td>'
                    + '<td><input type="hidden" name="row_no[]" value="'+ itm +'"><input type="file" class="form-control padding right width" name="multi_upload[]" id="multi_upload_' + itm + '" value="" placeholder="" multiple required></td>'

                    + '<td><div class="row_delete" style="float: right;margin-right: 20px; cursor: pointer;color: red;font-size: 100%;" onclick="deleteItem(\'#itm_tbl_row_' + itm + '\');">&cross;</div></td>'

                    + '</tr>';

                    itm++;

            $(".itm_tbl").append(st);

            

            //alert(st);

        }

        

function deleteItem(elm) {

            $(elm).remove();

            //--eml;

        }



</script>







<?php include('includes/admin_footer.php'); ?> 