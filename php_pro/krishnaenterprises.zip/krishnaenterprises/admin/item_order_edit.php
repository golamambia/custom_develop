<?php 
   include('includes/admin_top.php'); 
   
       $msg ="";
   
       $editid = $_REQUEST['edit'];
   
       $page_title = 'Update - Item Order';
   
   
   
       if(isset($_POST['update_banner']) && $_POST['update_banner']=='update_banner'){?>
<?php
   $db->updateArray(TABLE_ITEM_ORDER,$_POST, "id=".$editid) or die(mysql_error());
   
   
   
   $checkbox1 = $_POST['pdepartment'];
   
   for($count=0;$count<count($checkbox1);$count++)
   
   {
   
   $editid2=$_POST['pid'][$count];
   
   
   
   $data['pdepartment']=$_POST['pdepartment'][$count];
   
   $data['sub_pdepartment']=$_POST['sub_pdepartment'][$count];
   
   $data['item_code']=$_POST['item_code'][$count];
   
   $data['item_name']=$_POST['item_name'][$count];
   
   $data['description']=$_POST['description'][$count];
   
   $data['item_qty']=$_POST['item_qty'][$count];
   $data['slno']=$_POST['slno'][$count];
   unset($data['multi_upload']);
   unset($data['multi_upload2']);
   unset($data['multi_upload3']);
   
   if($_FILES['multi_upload']['name'][$count]!=''){
   $arr=getimagesize($_FILES['multi_upload']['tmp_name'][$count]);
   $userfile_extn = end(explode(".", strtolower($_FILES['multi_upload']['name'][$count])));
   
       if(($userfile_extn =="jpeg"||$userfile_extn =="jpg" || $userfile_extn =="png" || $userfile_extn =="gif")){
      
           $tmp_name = $_FILES['multi_upload']['tmp_name'][$count];
           $name = time()."_".$_FILES['multi_upload']['name'][$count];
           move_uploaded_file($tmp_name, HOME_UPLOAD.$name);
           $_POST['multi_upload'] = $name;             
               $data['multi_upload']=$_POST['multi_upload'];
           }else{
       $msg_class = 'alert-error';
       $msg="Must be .jpeg/.jpg/.png/.gif please check extension";
       }
   }
   
   if($_FILES['multi_upload2']['name'][$count]!=''){
   $arr=getimagesize($_FILES['multi_upload2']['tmp_name'][$count]);
   $userfile_extn = end(explode(".", strtolower($_FILES['multi_upload2']['name'][$count])));
   
       if(($userfile_extn =="pdf")){
      
           $tmp_name = $_FILES['multi_upload2']['tmp_name'][$count];
           $name = time()."_".$_FILES['multi_upload2']['name'][$count];
           move_uploaded_file($tmp_name, HOME_UPLOAD.$name);
           $_POST['multi_upload2'] = $name;             
               $data['multi_upload2']=$_POST['multi_upload2'];
           }else{
       $msg_class = 'alert-error';
       $msg="Must be .pdf please check extension";
       }
   }
   
   if($_FILES['multi_upload3']['name'][$count]!=''){
   $arr=getimagesize($_FILES['multi_upload3']['tmp_name'][$count]);
   $userfile_extn = end(explode(".", strtolower($_FILES['multi_upload3']['name'][$count])));
   
       if(($userfile_extn !="jpeg"||$userfile_extn !="jpg" || $userfile_extn !="png" || $userfile_extn !="gif" || $userfile_extn !="pdf")){
      
           $tmp_name = $_FILES['multi_upload3']['tmp_name'][$count];
           $name = time()."_".$_FILES['multi_upload3']['name'][$count];
           move_uploaded_file($tmp_name, HOME_UPLOAD.$name);
           $_POST['multi_upload3'] = $name;             
               $data['multi_upload3']=$_POST['multi_upload3'];
           }else{
       $msg_class = 'alert-error';
       $msg="Must be .csv please check extension";
       }
   }
   
       if($editid2!=''){
   
           $row_n=$db->updateArray(TABLE_ITEM_ORDER_PART,$data, "id=".$editid2) or die(mysql_error());
   
       }else{
   
           $data['item_order_id']=$editid;
   
           $row_n=$db->insertDataArray(TABLE_ITEM_ORDER_PART,$data);
    
       }
   
   
   }
   
   
   
   
   $msg_class = 'alert-success';
   
   $msg = MSG_EDIT_SUCCESS;
   
   
   
   }
   
   $get_des = $pm->getTableDetails(TABLE_ITEM_ORDER,'id',$editid);
   
   ?>  
<body class="hold-transition skin-blue sidebar-mini">
   <div class="wrapper">
      <!-- Main Header -->
      <?php include('includes/admin_header.php'); ?>  
      <!-- Left side column. contains the logo and sidebar -->
      <?php include('includes/admin_sidebar.php'); ?>  
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
         <!-- Content Header (Page header) -->
         <section class="content-header">
            <h1><?php echo $page_title; ?></h1>
         </section>
         <section class="content">
            <?php if((isset($msg)) and ($msg != ''))
               { ?>
            <div class="alert <?php echo $msg_class; ?> alert-dismissable">
               <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <p><?php echo $msg; ?></p>
            </div>
            <?php 
               } 
               
               ?>
            <div class="box box-info">
               <!-- form start -->
               <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="update_banner" value="update_banner">
                  <div class="box-body">
                     <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Company</label>
                        <div class="col-sm-5">
                           <select name="company" class="form-control" required onchange="get_cat(this.value)">
                              <option value="" >-Select Now-</option>
                              <?php 
                                 $sql = "SELECT * FROM ".TABLE_COMPANY." ORDER BY company asc";
                                 
                                 $res = $db->selectData($sql);
                                 
                                 while($row_rec = $db->getRow($res)){
                                 
                                 ?>
                              <option value=" <?php echo $row_rec['id']; ?>" <?php if($row_rec['id']==$get_des['company']){echo"selected";}?> > <?php echo $row_rec['company']; ?>(<?php echo $row_rec['company_code']; ?>)</option>
                              <?php }?>
                           </select>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Department</label>
                        <div class="col-sm-5">
                           <select name="department" id="department" class="form-control" required>
                              <option value="" >-Select Now-</option>
                              <?php 
                                 $com=$get_des['department'];
                                 
                                 $sql = "SELECT * FROM ".TABLE_DEPARTMENT." where id='$com'";
                                 
                                 $res = $db->selectData($sql);
                                 
                                 while($row_rec = $db->getRow($res)){
                                 
                                 ?>
                              <option value=" <?php echo $row_rec['id']; ?>" <?php if($row_rec['id']==$get_des['department']){echo"selected";}?> > <?php echo $row_rec['department']; ?></option>
                              <?php }?>
                           </select>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Contact Person</label>
                        <div class="col-sm-5">
                           <select name="contact_person" class="form-control" required>
                              <option value="" >-Select Now-</option>
                              <?php 
                                 $sql = "SELECT * FROM ".TABLE_USER." ORDER BY name asc";
                                 
                                 $res = $db->selectData($sql);
                                 
                                 while($row_rec = $db->getRow($res)){
                                 
                                 ?>
                              <option value=" <?php echo $row_rec['id']; ?>" <?php if($row_rec['id']==$get_des['contact_person']){echo"selected";}?>> <?php echo $row_rec['name']; ?></option>
                              <?php }?>
                           </select>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Job Assign</label>
                        <div class="col-sm-5">
                           <select name="job_assign" class="form-control" required>
                              <option value="" >-Select Now-</option>
                              <?php 
                                 $sql = "SELECT * FROM ".TABLE_PARENT_DESIG." ORDER BY name asc";
                                 
                                 $res = $db->selectData($sql);
                                 
                                 while($row_rec = $db->getRow($res)){
                                 
                                 ?>
                              <option value=" <?php echo $row_rec['id']; ?>" <?php if($row_rec['id']==$get_des['job_assign']){echo"selected";}?>> <?php echo $row_rec['name']; ?></option>
                              <?php }?>
                           </select>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Working Status</label>
                        <div class="col-sm-5">
                           <select name="work_status" class="form-control" required>
                              <option value="NOT STARTED" <?php if($get_des['work_status']=='NOT STARTED'){echo"selected";}?>>Not Started</option>
                              <option value="RECEIVED" <?php if($get_des['work_status']=='RECEIVED'){echo"selected";}?>>Received</option>
                              <option value="STARTED" <?php if($get_des['work_status']=='STARTED'){echo"selected";}?>>Started</option>
                              <option value="PENDING" <?php if($get_des['work_status']=='PENDING'){echo"selected";}?>>Pending</option>
                              <option value="CANCELLED" <?php if($get_des['work_status']=='CANCELLED'){echo"selected";}?>>Cancelled</option>
                              <option value="COMPLETED" <?php if($get_des['work_status']=='COMPLETED'){echo"selected";}?>>Completed</option>
                           </select>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Order Date</label>
                        <div class="col-sm-5">
                           <input type="date" class="form-control" id="order_date" placeholder="" name="order_date" required value="<?=$get_des['order_date'];?>">
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Delivery Date</label>
                        <div class="col-sm-5">
                           <input type="date" class="form-control" id="delivery_date" placeholder="" name="delivery_date" required value="<?=$get_des['delivery_date'];?>">
                        </div>
                     </div>
                     <div class="form-group">
                        <div class="col-sm-12">
                           <br>
                           <table class="table table-bordered">
                              <thead>
                                 <!-- <a href="add-product.php" type="button" class="btn btn-info">Add</a> -->
                                 <tr>
                                  <td colspan="11"><input style="text-align: center;" type="text" class="form-control" name="tab_title"  placeholder="Enter table title here" required value="<?=$get_des['tab_title'];?>"></td>
                              </tr>
                                 <tr>
                                    <th>No</th>
                                    <th>Format Name</th>
                                    <th>Format No</th>
                                    <th>SOP No</th>
                                    <th>Pages</th>
                                    <th>No of Pages</th>
                                    <th>No of Log Book</th>
                                    <th>Draft</th>
                                    <th>Dtp</th>
                                    <th>Source</th>
                                    <th></th>
                                 </tr>
                              </thead>
                              <tbody class="itm_tbl">
                              
                                 <?php 
                                    $i=0;
                                    
                                    $j='';
                                    
                                    $sql_part = "SELECT * FROM ".TABLE_ITEM_ORDER_PART." where item_order_id='$editid' ORDER BY id ASC";
                                    
                                    $res_part = $db->selectData($sql_part);
                                    
                                    while($row_rec_part = $db->getRow($res_part)){
                                    
                                    ?>
                                 <tr id="itm_tbl_row_<?=$i;?>">
                                    <input type="hidden" name="pid[]" value="<?=$row_rec_part['id'];?>">
                                    <td>
                                       <input type="text" class="form-control" name="slno[]"  value="<?=$row_rec_part['slno'];?>" >
                                    </td>
                                    <td>
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="text" class="form-control" id="pdepartment_<?=$i;?>" placeholder="Format name" name="pdepartment[]" required value="<?=$row_rec_part['pdepartment'];?>">
                                          </div>
                                       </div>
                                    </td>
                                    <td>
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="text" class="form-control" id="sub_pdepartment_<?=$i;?>" placeholder="Format No" name="sub_pdepartment[]" required value="<?=$row_rec_part['sub_pdepartment'];?>">
                                          </div>
                                       </div>
                                    </td>
                                    <td>
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="text" class="form-control" id="" placeholder="Item Code" name="item_code[]" required value="<?=$row_rec_part['item_code'];?>">
                                          </div>
                                       </div>
                                    </td>
                                    <td>
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="text" class="form-control" id="" placeholder="Item Name" name="item_name[]" required value="<?=$row_rec_part['item_name'];?>">
                                          </div>
                                       </div>
                                    </td>
                                    <td>
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="text" class="form-control" id="description_<?=$i;?>" placeholder="No of Pages" name="description[]" value="<?=$row_rec_part['description'];?>" required>
                                          </div>
                                       </div>
                                    </td>
                                    <?php if($i==0){?>
                                    <td rowspan="100">
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="text" class="form-control" id="" placeholder="Quantity" name="item_qty[]" required value="<?=$row_rec_part['item_qty'];?>">
                                          </div>
                                       </div>
                                    </td>
                                <?php }?>
                                    <td>
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="hidden" name="row_no[]" value="0">
                                             <input type="file" class="form-control" id="multi_upload_<?=$i;?>" placeholder="" name="multi_upload[]"  >
                                             <div id="multi_img<?=$i;?>">
                                                <div style="margin-top: 0px;float: left;margin-right: 10px;position: relative;padding-top: 20px;">
                                                   <!-- <span style="cursor:pointer;position: absolute;top:0px;left:0px;right:0px;display: block;text-align: center;color: red;font-size: 100%;" onclick="del_img11('<?=$row_rec_part['id'];?>','<?=$row_rec_part[order_id];?>','<?=$row_rec_part[multi_upload];?>','<?=$i;?>','<?=$proid;?>')">X</span> --><img src="<?PHP echo HOME_UPLOAD.$row_rec_part['multi_upload'];?>" height="20"/>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </td>
                                    <td>
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="hidden" name="row_no[]" value="0">
                                             <input type="file" class="form-control" id="multi_upload2_<?=$i;?>" placeholder="" name="multi_upload2[]"  >
                                             <div id="multi_img<?=$i;?>">
                                                <div style="margin-top: 0px;float: left;margin-right: 10px;position: relative;padding-top: 20px;">
                                                   <!-- <span style="cursor:pointer;position: absolute;top:0px;left:0px;right:0px;display: block;text-align: center;color: red;font-size: 100%;" onclick="del_img11('<?=$row_rec_part['id'];?>','<?=$row_rec_part[order_id];?>','<?=$row_rec_part[multi_upload];?>','<?=$i;?>','<?=$proid;?>')">X</span> --><img src="<?PHP echo HOME_UPLOAD.$row_rec_part['multi_upload2'];?>" height="20"/>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </td>
                                    <td>
                                       <div class="form-group">
                                          <div class="col-sm-12">
                                             <input type="hidden" name="row_no[]" value="0">
                                             <input type="file" class="form-control" id="multi_upload3_<?=$i;?>" placeholder="" name="multi_upload3[]"  >
                                             <div id="multi_img<?=$i;?>">
                                                <div style="margin-top: 0px;float: left;margin-right: 10px;position: relative;padding-top: 20px;">
                                                   <!-- <span style="cursor:pointer;position: absolute;top:0px;left:0px;right:0px;display: block;text-align: center;color: red;font-size: 100%;" onclick="del_img11('<?=$row_rec_part['id'];?>','<?=$row_rec_part[order_id];?>','<?=$row_rec_part[multi_upload];?>','<?=$i;?>','<?=$proid;?>')">X</span> --><img src="<?PHP echo HOME_UPLOAD.$row_rec_part['multi_upload3'];?>" height="20"/>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </td>
                                    <?php if($i>0){?>
                                    <td>
                                       <div class="row_delete" style="float: right;margin-right: 20px; cursor: pointer;color: red;font-size: 100%;" onclick="deleteItem('#itm_tbl_row_<?=$i;?>','<?=$row_rec_part["id"];?>');">&cross;</div>
                                    </td>
                                    <?php }?>
                                 </tr>
                                 <?php
                                    $i++;
                                    $j=$i;
                                    
                                    }
                                    
                                    ?>
                              </tbody>
                           </table>
                           <div  style="float: right;margin-right: 20px; cursor: pointer;" onclick="add_item();">
                              Add Item
                           </div>
                        </div>
                     </div>
                     <div class="box-footer">                    
                        <a href="item_order_list.php" type="button" class="btn btn-info">Close</a>
                        <button type="submit" class="btn btn-info">Submit</button>
                     </div>
                  </div>
               </form>
            </div>
         </section>
      </div>
   </div>
   <script type="text/javascript">
      itm=<?=$j+1;?>
      
      
      
   </script>
   <script type="text/javascript">
      function get_cat(val) {
      
      //alert(val);
      
      
      
      $.ajax({
      
      type: "POST",
      
      url: "get_department.php",
      
      data: 'val=' + val,
      
      cache: false,
      
      success: function(html) {
      
      //alert(html);
      
      $("#department").html(html);
      
      }
      
      });
      
      
      
      return false;
      
      }
      
      function del_img(val,val2,img,did,row){
      $.ajax({
      type: "POST",
      url: "get_multiimage.php",
      data: 'val=' + val+'&val2='+val2+'&img='+img+'&did='+did+'&row='+row,
      cache: false,
      success: function(html) {
      //alert(html);
      
      $("#alert_rem").show();
      $("#multi_img"+did).html(html);
      
      
      }
      });
      
      return false;
      }
      
      
      
      function get_cat1(val,no) {
      
      //alert(no);
      
      
      
      $.ajax({
      
      type: "POST",
      
      url: "get_prodepartment.php",
      
      data: 'val=' + val+'&no='+no,
      
      cache: false,
      
      success: function(html) {
      
      //alert(html);
      
      $("#sub_pdepartment"+no).html(html);
      
      }
      
      });
      
      
      
      return false;
      
      }
      
      
      
   </script>
   <script type="text/javascript">
      //itm=1;
      
      function add_item() {
      
      //alert('abcd1');
      
      var st = '<tr id="itm_tbl_row_' + itm + '">'
      
          + '<td><input type="text" class="form-control" name="slno[]"  value="' + itm + '" ></td>'
          + '<td><input type="text" class="form-control" id="pdepartment_' + itm + '" placeholder="Format name" name="pdepartment[]" required></td>'
      
          + '<td><input type="text" class="form-control" id="sub_pdepartment_' + itm + '" placeholder="Format No" name="sub_pdepartment[]" required></td>' //<option value="">--Select--</option>' + prdt_depts + '
      
          + '<td> <input type="text" class="form-control padding width" name="item_code[]" id="item_code_' + itm + '" value="" placeholder="SOP No" required></td>'
      
          + '<td><input type="text" class="form-control padding width" name="item_name[]" id="item_name_' + itm + '" value="" placeholder="Pages" required></td>'
      
          + '<td><input type="text" class="form-control" id="description_' + itm + '" placeholder="No of Pages" name="description[]" required></td>'
      
          //+ '<td><input type="text" class="form-control padding right width" name="item_qty[]" id="item_qty_' + itm + '" value="" placeholder="No of Log Book" required></td>'
          + '<td><input type="hidden" name="row_no[]" value="'+ itm +'"><input type="file" class="form-control padding right width" name="multi_upload[]" id="multi_upload_' + itm + '" value="" placeholder=""  required></td>'
          + '<td><input type="file" class="form-control" id="multi_upload2_' + itm + '" placeholder="" name="multi_upload2[]" required ></td>'
          + '<td><input type="file" class="form-control" id="multi_upload3_' + itm + '" placeholder="" name="multi_upload3[]" required ></td>'
      
          + '<td><div class="row_delete" style="float: right;margin-right: 20px; cursor: pointer;color: red;font-size: 100%;" onclick="deleteItem(\'#itm_tbl_row_' + itm + '\',\'' + 0 + '\');">&cross;</div></td>'
      
          + '</tr>';
      
      
          itm++;
      
      $(".itm_tbl").append(st);
      
      
      
      //alert(st);
      
      }
      
      
      
      function deleteItem(elm,id) {
      
      
      if(id!='0'){
      
      var result = confirm("Are you sure to delete?");
      
      if (result) {
      
      $.ajax({
      
      type: "POST",
      
      url: "get_itemorderdel.php",
      
      data: 'val=' + id,
      
      cache: false,
      
      success: function(html) {
      
      //alert(html);
      
      }
      
      });
      
      $(elm).remove();
      
      }     
      
      }else{
      
      
      
      $(elm).remove();
      
      }
      
      //--eml;
      
      }
      
      
      
   </script>
   <!-- /.content-wrapper -->
   <?php include('includes/admin_footer.php'); ?>