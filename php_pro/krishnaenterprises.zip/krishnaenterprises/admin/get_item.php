<?php
include('../configure.php');
 $id=$_POST[val];
 $no=$_POST[no];


 $sql = "SELECT * FROM ".TABLE_ITEM." where id='$id'";
            $res = $db->selectData($sql);
            $row_rec = $db->getRow($res);
           echo $row_rec['hsn_code'].'~amb~'.$row_rec['unit'];
?>



