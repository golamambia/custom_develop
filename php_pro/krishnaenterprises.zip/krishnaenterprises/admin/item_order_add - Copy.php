<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $page_title = 'Item Order  - Add';
    // $id = $_REQUEST['id'];

    if(isset($_POST['add_work']) && $_POST['add_work']=='add_work'){

        $_POST['entry_date']=date('d-m-Y');

        $get_last_id = $db->insertDataArray(TABLE_SUB_PDEPARTMENT,$_POST);
                    if(!empty($get_last_id)):
                    $msg_class = 'alert-success';
                    $msg = MSG_ADD_SUCCESS;
                    else:
                    $msg_class = 'alert-error';
                    $msg = MSG_ADD_FAIL;
                    endif;

    }
?>  
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Main Header -->
    <?php include('includes/admin_header.php'); ?>  
    <!-- Left side column. contains the logo and sidebar -->
    <?php include('includes/admin_sidebar.php'); ?>  
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php echo $page_title; ?></h1>
    </section>

    <section class="content">
        <?php if((isset($msg)) and ($msg != '')){ ?>
        <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
        </div>
        <?php } ?>
        <div class="box box-info">
        <!-- form start -->
        <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="add_work" value="add_work">
            <div class="box-body">

            

            <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Company</label>
                <div class="col-sm-5">
                    
                    <select name="company" class="form-control" required onchange="get_cat(this.value)">
                        <option value="" >-Select Now-</option>
                        <?php 
            $sql = "SELECT * FROM ".TABLE_COMPANY." ORDER BY company asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
                        <option value=" <?php echo $row_rec['id']; ?>" > <?php echo $row_rec['company']; ?>(<?php echo $row_rec['company_code']; ?>)</option>
                    <?php }?>
                    </select>
                </div>
            </div>
            <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Department</label>
                <div class="col-sm-5">
                    
                    <select name="department" id="department" class="form-control" required>
                        <option value="" >-Select Now-</option>
                        
                    </select>
                </div>
            </div>
            <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Manufacturer</label>
                <div class="col-sm-5">
                    
                    <select name="manufacturer" class="form-control" required>
                        <option value="" >-Select Now-</option>
                        <?php 
            $sql = "SELECT * FROM ".TABLE_PDEPARTMENT." ORDER BY name asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
                        <option value=" <?php echo $row_rec['id']; ?>" > <?php echo $row_rec['name']; ?></option>
                    <?php }?>
                    </select>
                </div>
            </div>
            <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Working Status</label>
                <div class="col-sm-5">
                    
                    
                    <select name="work_status" class="form-control" required>
                        
                       <option value="NOT STARTED" selected="selected">Not Started</option>
                            <option value="RECEIVED">Received</option>
                             <option value="STARTED">Started</option>
                        <option value="PENDING">Pending</option>
                            <option value="CANCELLED">Cancelled</option>
                             <option value="COMPLETED">Completed</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Order Date</label>
                <div class="col-sm-5">
                    <input type="date" class="form-control" id="order_date" placeholder="" name="order_date" required>
                </div>
            </div>



            <div class="form-group">
                
                <div class="col-sm-12">
                    

<br>
                <table class="table table-bordered">

        <thead>

        <!-- <a href="add-product.php" type="button" class="btn btn-info">Add</a> -->

            <tr>
                <th>Product Department</th>
                <th>Sub Product Department</th>

                <th>Item Code</th>

                <th>Item Name</th>

                <th>Item Description</th>

                <th>Item Qty</th>
                <th></th>
            </tr>


        </thead>

        <tbody>


            <tr>



               

                 <td>

                   <div class="form-group">
           
                <div class="col-sm-12">
                    
                    <select name="pdepartment" class="form-control" required onchange="get_cat1(this.value)">
                        
                       <option value="" >--Select Now--</option>
                        <?php 
            $sql = "SELECT * FROM ".TABLE_PDEPARTMENT." ORDER BY name asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
                        <option <?php if($get_des['pdepartment']==$row_rec['id']){?> selected <?php }?> value=" <?php echo $row_rec['id']; ?>" > <?php echo $row_rec['name']; ?></option>
                    <?php }?>
                    </select>
                </div>
            </div>


                </td>

                <td>

                   
                   <div class="form-group">
           
                <div class="col-sm-12">
                    
                    <select name="sub_pdepartment" id="sub_pdepartment" class="form-control" required>
                        
                       <option value="" >--Select Now--</option>
                        
                    </select>
                </div>
            </div>

                </td>

                <td>

                    <div class="form-group">
                
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="order_date" placeholder="Item code" name="order_date" required>
                </div>
            </div>


                </td>
                <td>

                     <div class="form-group">
                
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="order_date" placeholder="Item name" name="order_date" required>
                </div>
            </div>

                </td>

                <td>

                    <div class="form-group">
                
                <div class="col-sm-12">
                    <textarea class="form-control" id="order_date" placeholder="Description" name="order_date" required rows="2"></textarea>
                </div>
            </div>

                </td>

                <td>

                    <div class="form-group">
                
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="order_date" placeholder="Quantity" name="order_date" required>
                </div>
            </div>

                </td>
                <td style="color: red;cursor: pointer;font-size: 20px;font-weight: 600;"></td>

            </tr>
        




            
        </tbody>
    </table>

<div  style="float: right;margin-right: 20px; cursor: pointer;" onclick="add_item();">
                            Add Item
                        </div>


                </div>
            </div>

            <div class="box-footer">
            <a href="item_order_list.php" type="button" class="btn btn-info">Back</a>
                <button type="submit" class="btn btn-info">Submit</button>
            </div>
            </div>
        </form>
        </div>
    </section>
</div>
<!-- /.content-wrapper -->

<script type="text/javascript">
   function get_cat(val) {
//alert(val);

$.ajax({
type: "POST",
url: "get_department.php",
data: 'val=' + val,
cache: false,
success: function(html) {
//alert(html);

   
$("#department").html(html);


}
});

return false;
}


 function get_cat1(val) {
//alert(val);

$.ajax({
type: "POST",
url: "get_prodepartment.php",
data: 'val=' + val,
cache: false,
success: function(html) {
//alert(html);

   
$("#sub_pdepartment").html(html);


}
});

return false;
}

</script>



<script type="text/javascript">
    function add_item() {
             //alert('abcd1');
         var prdt_depts = '';
         
                             prdt_depts += '<option value="6" >Logbook</option>';
                            prdt_depts += '<option value="4" >Electrical</option>';
                            prdt_depts += '<option value="3" >Stationary</option>';
                            prdt_depts += '<option value="2" >House keeping</option>';
                            prdt_depts += '<option value="1" >Printing</option>';
        
        var st = '<tr id="itm_tbl_row_' + itm + '">'
                    + '<td><select name="product_department[]"  id="product_department_' + itm + '" class="form-control select width" onchange="getSubPrdtDept(\'' + itm + '\');"><option value="">--Select--</option>' + prdt_depts +  '</select></td>'
                    + '<td><select name="sub_product_department[]"  id="sub_product_department_' + itm + '" class="form-control select width" onchange=""><option value="">--Select--</option></select></td>' //<option value="">--Select--</option>' + prdt_depts + '
                    + '<td> <input type="text" class="form-control padding width" name="item_code[]" id="item_code_' + itm + '" value="" placeholder="Item Code"></td>'
                    + '<td><input type="text" class="form-control padding width" name="item_name[]" id="item_name_' + itm + '" value="" placeholder="Item Name"></td>'
                    + '<td><textarea class="form-control padding width" name="item_description[]" name="item_description_' + itm + '" rows="3" placeholder="Description"></textarea></td>'
                    + '<td><input type="text" class="form-control padding right width" name="item_qty[]" id="item_qty_' + itm + '" value="" placeholder="Qty"></td>'
                    + '<td><div class="row_delete" style="float: right;margin-right: 20px; cursor: pointer;" onclick="deleteItem(\'#itm_tbl_row_' + itm + '\');">&cross;</div></td>'
                    + '</tr>';
            $(".itm_tbl").append(st);
            itm++;
        }
        
function deleteItem(elm) {
            $(elm).remove();
            //--eml;
        }

</script>



<?php include('includes/admin_footer.php'); ?> 