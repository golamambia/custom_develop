<header class="main-header">
<a class="logo">
<span class="logo-mini"><b>PT</b>A</span>
<span class="logo-lg"><b><?php echo SITE_NAME; ?></b></span>
<span><img src=""></span>
</a>

<nav class="navbar navbar-static-top" role="navigation">


<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
<span class="sr-only">Toggle navigation</span>
</a>
<div class="navbar-custom-menu">
<ul class="nav navbar-nav">
        
        
        <ul class="nav navbar-nav">
        
          <!-- Messages: style can be found in dropdown.less-->
          
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              
              <i class="fa fa-clock-o" style="font-weight:bold" id="time">  </i>
              <span class="label label-warning"></span>
            </a>
            
          </li>
<li>
            <a href="logout.php" ><i class="glyphicon glyphicon-log-out1" style="font-weight:bold">Logout</i></a>
          </li>

      </ul>


</header>
