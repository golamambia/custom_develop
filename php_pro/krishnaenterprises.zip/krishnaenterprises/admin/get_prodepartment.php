<?php
include('../configure.php');
 $id=$_POST[val];
 $no=$_POST[no];
?>
<select name="sub_pdepartment[]" id="sub_pdepartment<?=$no;?>" class="form-control" required>
                    <option  value="" selected>--Select--</option>
                    <?php 
                    $sql1= "SELECT * FROM ".TABLE_SUB_PDEPARTMENT." where pdepartment=$id ORDER BY id";
                    $res1 = $db->selectData($sql1);
                    while($row_rec1 = $db->getRow($res1)){
                    ?>
                    <option value="<?php echo $row_rec1['id']; ?>"><?php echo $row_rec1['sub_pdepartment']; ?></option>
                    <?php } ?>
                </select>


