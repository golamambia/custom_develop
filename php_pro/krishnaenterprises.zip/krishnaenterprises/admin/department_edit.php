<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $editid = $_REQUEST['edit'];
    $page_title = 'Update - Department';

    if(isset($_POST['update_banner']) && $_POST['update_banner']=='update_banner'){
       
            $db->updateArray(TABLE_DEPARTMENT,$_POST, "id=".$editid) or die(mysql_error());
            $msg_class = 'alert-success';
            $msg = MSG_EDIT_SUCCESS;
       
    }
    $get_des = $pm->getTableDetails(TABLE_DEPARTMENT,'id',$editid);
?>  

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
    <!-- Main Header -->
        <?php include('includes/admin_header.php'); ?>  

        <!-- Left side column. contains the logo and sidebar -->
        <?php include('includes/admin_sidebar.php'); ?>  

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1><?php echo $page_title; ?></h1>
        </section>

        <section class="content">
            <?php if((isset($msg)) and ($msg != ''))
            { ?>
            <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
            </div>
            <?php 
            } 
            ?>
            <div class="box box-info">
            <!-- form start -->
            <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
            
                <input type="hidden" name="update_banner" value="update_banner">
                <div class="box-body">

                
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Company</label>
                <div class="col-sm-5">
                   
                    <select name="company" class="form-control" required>
                        <?php 
            $sql = "SELECT * FROM ".TABLE_COMPANY." ORDER BY company asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
                        <option value="<?php echo $row_rec['id']; ?>" <?php if($row_rec['id']==$get_des['company']){?> selected <?php } ?> ><?php echo $row_rec['company']; ?>(<?php echo $row_rec['company_code']; ?>) </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Department</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="department" placeholder="Company code" name="department" required value="<?=$get_des['department'];?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Contact person</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="contact_person" placeholder="" name="contact_person" required value="<?=$get_des['contact_person'];?>">
                </div>
            </div>

            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Contact No</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="contact" placeholder="" name="contact" maxlength="12" required value="<?=$get_des['contact'];?>" onkeydown="return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )">
                </div>
            </div>

            
            <!-- <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-5">
                    
                     <textarea class="form-control" name="address" rows="5" placeholder="Enter Address" required><?=$get_des['address'];?></textarea>
                </div>
            </div> -->

                <div class="box-footer">                    
                    <a href="department_list.php" type="button" class="btn btn-info">Close</a>
                    <button type="submit" class="btn btn-info">Submit</button>
                </div>

                </div>
            </form>
            </div>
        </section>
        
        </div>
    </div>
<!-- /.content-wrapper -->
<?php include('includes/admin_footer.php'); ?> 