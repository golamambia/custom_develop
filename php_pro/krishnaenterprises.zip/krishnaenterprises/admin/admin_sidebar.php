<aside class="main-sidebar">
   <section class="sidebar">
      <div class="user-panel">
         <div class="pull-left image" >
            <img style="height: 47px;" src="images/krishna.png" class="img-circle" alt="User Image">
         </div>
         <div class="pull-left info" >
            <p>
               <?php
                  if((isset($_SESSION['ADMIN']['id'])) and ($_SESSION['ADMIN']['id'] != ""))
                  echo $_SESSION['ADMIN']['name'];
                  else
                  echo $_SESSION['USER']['name'];
                  ?>
            </p>
            <a href="<?php $gf-> linkURL('admin/dashboard.php');?>"><i class="fa fa-circle text-success"></i> Online</a>
         </div>
      </div>
      <?php if((isset($_SESSION['ADMIN']['id'])) and ($_SESSION['ADMIN']['id'] != "")){ ?>
      <ul class="sidebar-menu">
         <li class="<?php if($getPageName == 'dashboard.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/dashboard.php');?>"><i class="fa fa-link"></i> <span>Dashboard</span></a></li>
         <li class="treeview <?php if($getPageName == 'designation_add.php' || $getPageName == 'designation_list.php' || $getPageName == 'designation_edit.php' || $getPageName == 'user_add.php' || $getPageName == 'user_list.php' || $getPageName == 'user_edit.php' || $getPageName == 'pdesignation_add.php' || $getPageName == 'pdesignation_list.php' || $getPageName == 'pdesignation_edit.php'){?> active <?php }?>">
            <a href="#"><i class="fa fa-users"></i> <span>User</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
               <li><a href="<?php $gf-> linkURL('admin/pdesignation_list.php');?>">List Parent Designation</a></li>
               <li><a href="<?php $gf-> linkURL('admin/designation_add.php');?>">Add Designation</a></li>
               <li><a href="<?php $gf-> linkURL('admin/designation_list.php');?>">List Designation</a></li>
               <li><a href="<?php $gf-> linkURL('admin/user_add.php');?>">Add User</a></li>
               <li><a href="<?php $gf-> linkURL('admin/user_list.php');?>">List User</a>
               </li>
            </ul>
         </li>
         <li class="treeview <?php if($getPageName == 'quotation_add.php' || $getPageName == 'quotation_edit.php' || $getPageName == 'quotation_list.php' || $getPageName == 'item_bill_add.php' || $getPageName == 'item_bill_list.php' || $getPageName == 'item_bill_edit.php' || $getPageName == 'item_challan_add.php' || $getPageName == 'item_challan_list.php' || $getPageName == 'item_challan_edit.php' || $getPageName == 'purchase_order_add.php' || $getPageName == 'purchase_order_edit.php' || $getPageName == 'purchase_order_list.php'){?> active <?php }?>">
            <a href="#"><i class="fa fa-file-text-o " aria-hidden="true"></i> <span>Account</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu ">
               <li class="<?php if($getPageName == 'quotation_add.php' || $getPageName == 'quotation_edit.php' || $getPageName == 'quotation_list.php' || $getPageName == 'purchase_order_add.php' || $getPageName == 'purchase_order_edit.php' || $getPageName == 'purchase_order_list.php' || $getPageName == 'item_bill_add.php' || $getPageName == 'item_bill_list.php' || $getPageName == 'item_bill_edit.php' || $getPageName == 'item_challan_add.php' || $getPageName == 'item_challan_list.php' || $getPageName == 'item_challan_edit.php'){?> active <?php }?>">
                  <a href="#"><i class="fa fa-sitemap fa-rotate-270"></i>Purchase<i class="fa fa-angle-left pull-right"></i></a>
                  <ul class="treeview-menu">
                     <li class="treeview <?php if($getPageName == 'quotation_add.php' || $getPageName == 'quotation_edit.php' || $getPageName == 'quotation_list.php' ){?> active <?php }?>">
                        <a href="#"><i class="fa fa-circle-o"></i> <span>Quotation</span> <i class="fa fa-angle-left pull-right"></i></a>
                        <ul class="treeview-menu">
                           <li class="<?php if($getPageName == 'quotation_add.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/quotation_add.php');?>">Quotation Add</a></li>
                           <li class="<?php if($getPageName == 'quotation_list.php' ){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/quotation_list.php');?>">Quotation List</a></li>
                        </ul>
                     </li>
                     <li class="treeview <?php if($getPageName == 'purchase_order_add.php' || $getPageName == 'purchase_order_edit.php' || $getPageName == 'purchase_order_list.php' ){?> active <?php }?>">
                        <a href="#"><i class="fa fa-circle-o"></i> <span>Purchase Order</span> <i class="fa fa-angle-left pull-right"></i></a>
                        <ul class="treeview-menu">
                           <li class="<?php if($getPageName == 'purchase_order_add.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/purchase_order_add.php');?>">Purchase Order Add</a></li>
                           <li class="<?php if($getPageName == 'purchase_order_list.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/purchase_order_list.php');?>">Purchase Order List</a></li>
                        </ul>
                     </li>
                     <li class="treeview <?php if($getPageName == 'item_bill_add.php' || $getPageName == 'item_bill_list.php' || $getPageName == 'item_bill_edit.php' ){?> active <?php }?>">
                        <a href="#"><i class="fa fa-circle-o"></i> <span>Bill</span> <i class="fa fa-angle-left pull-right"></i></a>
                        <ul class="treeview-menu">
                           <li class="<?php if($getPageName == 'item_bill_add.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/item_bill_add.php');?>">Item Bill Add</a></li>
                           <li class="<?php if($getPageName == 'item_bill_list.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/item_bill_list.php');?>">Item Bill List</a></li>
                        </ul>
                     </li>
                     <li class="treeview <?php if($getPageName == 'item_challan_add.php' || $getPageName == 'item_challan_list.php' || $getPageName == 'item_challan_edit.php' ){?> active <?php }?>">
                        <a href="#"><i class="fa fa-circle-o"></i> <span>Challan</span> <i class="fa fa-angle-left pull-right"></i></a>
                        <ul class="treeview-menu">
                           <li class="<?php if($getPageName == 'item_challan_add.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/item_challan_add.php');?>">Item Challan Add</a></li>
                           <li class="<?php if($getPageName == 'item_challan_list.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/item_challan_list.php');?>">Item Challan List</a></li>
                        </ul>
                     </li>
                  </ul>
               </li>
               <li><a href="#"><span>Sale</span> <i class="fa fa-angle-left pull-right"></i></a>
               </li>
               <li><a href="#"><span>Expence</span> <i class="fa fa-angle-left pull-right"></i></a></li>
               <li><a href="#"><span>Tax</span> <i class="fa fa-angle-left pull-right"></i></a></li>
               <li><a href="#"><span>Payment</span> <i class="fa fa-angle-left pull-right"></i></a></li>
            </ul>
         </li>
         <li class="treeview ">
            <a href="#"><i class="fa fa-file-text-o"></i> <span>Manufacture</span> <i class="fa fa-angle-left pull-right"></i></a>
         </li>
         <li class="treeview <?php if($getPageName == 'company_add.php' || $getPageName == 'company_list.php' || $getPageName == 'company_edit.php' ){?> active <?php }?>">
            <a href="#"><i class="fa fa-file-text-o"></i> <span>Company</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
               <li><a href="<?php $gf-> linkURL('admin/company_add.php');?>">Company Add</a></li>
               <li><a href="<?php $gf-> linkURL('admin/company_list.php');?>">Company List</a></li>
            </ul>
         </li>
         <li class="treeview <?php if($getPageName == 'department_add.php' || $getPageName == 'department_list.php' || $getPageName == 'department_edit.php' ){?> active <?php }?>">
            <a href="#"><i class="fa fa-file-text-o"></i> <span>Department</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
               <li><a href="<?php $gf-> linkURL('admin/department_add.php');?>">Department Add</a></li>
               <li><a href="<?php $gf-> linkURL('admin/department_list.php');?>">Department List</a></li>
            </ul>
         </li>
         <li class="treeview <?php if($getPageName == 'pdepartment_add.php' || $getPageName == 'pdepartment_list.php' || $getPageName == 'pdepartment_edit.php' || $getPageName == 'sub_pdepartment_add.php' || $getPageName == 'sub_pdepartment_list.php' || $getPageName == 'sub_pdepartment_edit.php' ){?> active <?php }?>">
            <a href="#"><i class="fa fa-file-text-o"></i> <span>Product Department</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
               <li><a href="<?php $gf-> linkURL('admin/pdepartment_add.php');?>">Product Department Add</a></li>
               <li><a href="<?php $gf-> linkURL('admin/pdepartment_list.php');?>">Product Department List</a></li>
               <li><a href="<?php $gf-> linkURL('admin/sub_pdepartment_add.php');?>">Sub Product Department Add</a></li>
               <li><a href="<?php $gf-> linkURL('admin/sub_pdepartment_list.php');?>">Sub Product Department List</a></li>
            </ul>
         </li>
         <li class="treeview <?php if($getPageName == 'item_order_add.php' || $getPageName == 'item_order_edit.php' || $getPageName == 'item_order_list.php' ){?> active <?php }?>">
            <a href="#"><i class="fa fa-file-text-o"></i> <span>Item Order</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
               <li><a href="<?php $gf-> linkURL('admin/item_order_add.php');?>">Item Order Add</a></li>
               <li><a href="<?php $gf-> linkURL('admin/item_order_list.php');?>">Item Order List</a></li>
            </ul>
         </li>
         <li class="treeview <?php if($getPageName == 'item_add.php' || $getPageName == 'item_list.php' || $getPageName == 'item_edit.php' ){?> active <?php }?>">
            <a href="#"><i class="fa fa-file-text-o"></i> <span>Items</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
               <li><a href="<?php $gf-> linkURL('admin/item_add.php');?>">Item Add</a></li>
               <li><a href="<?php $gf-> linkURL('admin/item_list.php');?>">Item List</a></li>
            </ul>
         </li>
         <!--<li class="treeview <?php if($getPageName == 'footer-add.php' || $getPageName == 'footer-list.php' || $getPageName == 'footer-edit.php' ){?> active <?php }?>">-->
         <!--   <a href="#"><i class="fa fa-file-text-o"></i> <span>Footer</span> <i class="fa fa-angle-left pull-right"></i></a>-->
         <!--   <ul class="treeview-menu">-->
         <!--      <li><a href="<?php $gf-> linkURL('admin/footer-list.php');?>">Footer Details</a></li>-->
         <!--   </ul>-->
         <!--</li>-->
         <li class="treeview <?php if($getPageName == 'change_password.php' || $getPageName == 'profile.php' || $getPageName == 'setting.php'){?> active <?php }?>">
            <a href="#"><i class="fa fa-file-text-o"></i> <span>Profile Section</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
               <li><a href="<?php $gf-> linkURL('admin/profile.php');?>">Admin Profile</a></li>
               <!--<li><a href="<?php $gf-> linkURL('admin/setting.php');?>">Settings</a></li>-->
               <li><a href="<?php $gf-> linkURL('admin/change_password.php');?>">Change Password</a></li>
            </ul>
         </li>
         <li class="<?php if($getPageName == 'logout.php'){?> active <?php }?>"><a href="<?php $gf-> linkURL('admin/logout.php');?>" onclick="return confirm('Are You Sure You Want To Logout !!')"><i class="glyphicon glyphicon-log-out"></i> <span>Logout</span></a></li>
      </ul>
      <?php }else{ ?>
      <ul class="sidebar-menu">
         <li class="treeview <?php if($getPageName == 'change_password.php' || $getPageName == 'profile.php' || $getPageName == 'setting.php'){?> active <?php }?>">
            <a href="#"><i class="fa fa-file-text-o"></i> <span>Profile Section</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
               <li><a href="<?php $gf-> linkURL('admin/profile.php');?>">User Profile</a></li>
               <!-- <li><a href="<?php $gf-> linkURL('admin/setting.php');?>">Settings</a></li> -->
               <li><a href="<?php $gf-> linkURL('admin/change_password.php');?>">Change Password</a></li>
            </ul>
         </li>
         <li><a href="<?php $gf-> linkURL('admin/logout.php');?>" onclick="return confirm('Are You Sure You Want To Logout !!')"><i class="glyphicon glyphicon-log-out"></i> <span>Logout</span></a></li>
      </ul>
      <?php } ?>
   </section>
</aside>