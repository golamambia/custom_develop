<?php 
include('includes/admin_top.php'); 
    $msg ="";
    $page_title = 'Item Bill - Add';
    // $id = $_REQUEST['id'];
$rc=mysql_fetch_assoc(mysql_query("SELECT * FROM ".TABLE_BILL." WHERE id=(SELECT MAX(id) FROM ".TABLE_BILL.")"));
     $rc_no=$rc['no']+1;
    if(isset($_POST['add_work']) && $_POST['add_work']=='add_work'){
        $did=$_POST['company'];
         $sqlc =mysql_fetch_assoc(mysql_query("SELECT * FROM ".TABLE_COMPANY." where id='$did'"))['company'];

        $string = $sqlc;
        $stringExp = explode(' ', $string);
        $shortCode = '';
        for($i = 0; $i < count($stringExp); $i++){

                $shortCode .= substr($stringExp[$i], 0, 1);

        }

     
        $q="KE-SGT/B0".$rc_no."/".strtoupper($shortCode);
        $_POST['no']=$rc_no;
        $_POST['bill_no']=$q;

        $_POST['entry_date']=date('d-m-Y');
        $checkbox1 = $_POST['item_name'];
       
        $get_last_id = $db->insertDataArray(TABLE_BILL,$_POST);
        //$_POST['item_order_id']=$get_last_id;
        for($count=0;$count<count($checkbox1);$count++)
        {
            $data['bill_id']=$get_last_id;
            $data['hsn_code']=$_POST['hsn_code'][$count];
            $data['item_name']=$_POST['item_name'][$count];
            $data['item_qty']=$_POST['item_qty'][$count];
            $data['item_rate']=$_POST['item_rate'][$count];
            $data['item_unit']=$_POST['item_unit'][$count];
            // $data['discount_rate']=$_POST['discount_rate'][$count];
            $data['item_amt']=$_POST['item_amt'][$count];
            //$chk.=$count;
            $get_last_id2 = $db->insertDataArray(TABLE_BILL_PART,$data);
        }
                    if(!empty($get_last_id)):
                    $msg_class = 'alert-success';
                    $msg = MSG_ADD_SUCCESS;
                    else:
                    $msg_class = 'alert-error';
                    //$msg=$chk;
                    $msg = MSG_ADD_FAIL;
                    endif;

    }
?>  
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Main Header -->
    <?php include('includes/admin_header.php'); ?>  
    <!-- Left side column. contains the logo and sidebar -->
    <?php include('includes/admin_sidebar.php'); ?>  
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php echo $page_title; ?></h1>
    </section>

    <section class="content">
        <?php if((isset($msg)) and ($msg != '')){ ?>
        <div class="alert <?php echo $msg_class; ?> alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><?php echo $msg; ?></p>
        </div>
        <?php } ?>
        <div class="box box-info">
        <!-- form start -->
        <form class="form-horizontal" name="" action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="add_work" value="add_work">
            <div class="box-body">

            

            <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Company</label>
                <div class="col-sm-5">
                    
                    <select name="company" class="form-control" required onchange="get_cat(this.value)">
                        <option value="" >-Select Now-</option>
                        <?php 
            $sql = "SELECT * FROM ".TABLE_COMPANY." ORDER BY company asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
                        <option value=" <?php echo $row_rec['id']; ?>" > <?php echo $row_rec['company']; ?>(<?php echo $row_rec['company_code']; ?>)</option>
                    <?php }?>
                    </select>
                </div>
            </div>
            <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Department</label>
                <div class="col-sm-5">
                    
                    <select name="department" id="department" class="form-control" required>
                        <option value="" >-Select Now-</option>
                        
                    </select>
                </div>
            </div>
            
            
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Po No</label>
                <div class="col-sm-5">
            <input type="number" class="form-control" id="po_no" placeholder="Po No" name="po_no" required>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Bill Date</label>
                <div class="col-sm-5">
                    <input type="date" class="form-control" id="bill_date" placeholder="" name="bill_date" required>
                </div>
            </div>



            <div class="form-group">
                
                <div class="col-sm-12">
                    

<br>
                <table class="table table-bordered">

        <thead>

        <!-- <a href="add-product.php" type="button" class="btn btn-info">Add</a> -->

            <tr>
                <th>Name of Item</th>
                <th>HSN Code</th>

                <th>Rate</th>

                <th>Unit</th>

                <th>Qty</th>

                <!-- <th>Discount(%)</th> -->
                <th>Amount</th>
                <th></th>
            </tr>


        </thead>

        <tbody class="itm_po_tbl">


            <tr>


                 <td>

                   <div class="form-group">
           
                <div class="col-sm-12">
                    
                    <select name="item_name[]" id="item_name_0" class="form-control" required onchange="get_cat1(this.value,'0')">
                        <option value="" >-Select-</option>
                    <?php 
            $sql = "SELECT * FROM ".TABLE_ITEM." ORDER BY name asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
            <option value="<?php echo $row_rec['id']; ?>" ><?php echo $row_rec['name']; ?></option>
                    <?php }?>
                   
                </div>
            </div>


                </td>

                <td>

                   
                   <div class="form-group">
           
                <div class="col-sm-12">
                    
            <input type="text" class="form-control" name="hsn_code[]" id="hsn_code_0" value="" placeholder="HSN Code" required readonly>
                </div>
            </div>

                </td>

                <td>

                    <div class="form-group">
                
                <div class="col-sm-12">
                   <input type="text" class="form-control" name="item_rate[]" id="item_rate_0" rows="2" placeholder="Rate" onkeyup="getRateAmt('0')">
                </div>
            </div>


                </td>
                <td>

                     <div class="form-group">
                
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="item_unit[]" id="item_unit_0" value="" placeholder="Unit" required readonly>
                </div>
            </div>

                </td>

                <td>

                    <div class="form-group">
                
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="item_qty[]" id="item_qty_0" value="" placeholder="Quantity" required onkeyup="getAmt('0')">
                </div>
            </div>

                </td>

                <!-- <td>

                    <div class="form-group">
                
                <div class="col-sm-12">
                <input type="text" class="form-control" name="discount_rate[]" id="discount_rate_0" value="" placeholder="Discount"  onkeyup="getDiscount('0')">
                </div>
            </div>

                </td> -->
                <td>

                    <div class="form-group">
                
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="item_amt[]" id="item_amt_0" value="" placeholder="Amount" required readonly >
                </div>
            </div>

                </td>
                <td style="color: red;cursor: pointer;font-size: 20px;font-weight: 600;"></td>

            </tr>
        
        </tbody>
    </table>

<div  style="float: right;margin-right: 20px; cursor: pointer;" onclick="add_item_po();">
                            Add Item
                        </div>


                </div>
            </div>

<div class="table-responsive">
                              <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                 <thead>
                                    <tr>
                                       <td colspan="5" align="right">Sub. Total</td>
                                      <td align="right"><input type="hidden" name="po_sub_amt" id="po_sub_amt_1"  /><div id="po_sub_amt_0"></div>
                                      </td>
                                       </tr>
                                    <tr>
                                       <td colspan="5" align="right">CGST (9%)</td>
                                      <td align="right"><input type="hidden" name="cgst_amt" id="cgst_amt_1" /><div id="cgst_amt_0"></div></td>
                                      </tr>
                                    <tr>
                                       <td colspan="5" align="right">SGST (9%)</td>
                                      <td align="right"><input type="hidden" name="sgst_amt" id="sgst_amt_1" /><div id="sgst_amt_0"></div></td>
                                       </tr>
                                    <tr>
                                       <td colspan="5" align="right">G. Total </td>
                                      <td align="right"><input type="hidden" name="po_g_t_amt" id="po_g_t_amt_1" /><div id="po_g_t_amt_0"></div></td>
                                       </tr>
                                                                           <script>
                                       window.onload = function(e) {
                                            getGTotal();
                                            //getDepartment();
                                       };
                                       </script>
                                                                          
                                        </table>
                                        </div>
                                



            <div class="box-footer">
            <a href="item_bill_list.php" type="button" class="btn btn-info">Back</a>
                <button type="submit" class="btn btn-info">Submit</button>
            </div>
            </div>
        </form>
        </div>
    </section>
</div>
<!-- /.content-wrapper -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">
   function get_cat(val) {
//alert(val);

$.ajax({
type: "POST",
url: "get_department.php",
data: 'val=' + val,
cache: false,
success: function(html) {
//alert(html);

$("#department").html(html);

}
});

return false;
}


 function get_cat1(val,no) {
//alert(no);

$.ajax({
type: "POST",
url: "get_item.php",
data: 'val=' + val+'&no='+no,
cache: false,
success: function(html) {
//alert(html);
var sp = html.split('~amb~');
var code = sp[0];
var name = sp[1];
   
$("#hsn_code_"+no).val(code);
$("#item_unit_"+no).val(name);


}
});

return false;
}
 

 function getAmt(val) {
            var i = val;
            var item_qty = $('#item_qty_' + i).val();
            var item_rate = $('#item_rate_' + i).val();
            
            if(item_rate != ''){
            var item_amt = item_qty * item_rate;
            item_amt = Number(item_amt).toFixed(2);
            $('#item_amt_'+ i).val(item_amt);
            }else{
            var item_amt = 0;   
            item_amt = Number(item_amt).toFixed(2);
            $('#item_amt_'+ i).val(item_amt);
            }
            // var discount_rate = $('#discount_rate_' + i).val();
            // if(discount_rate != ''){
            // var discount = item_amt * (discount_rate / 100);
            // var discounted_amt = item_amt - discount; 
            // discounted_amt = Number(discounted_amt).toFixed(2);
            // $('#item_amt_'+ i).val(discounted_amt);
            // }
            /*
            else{
            var discount = 0;
            var discounted_amt = item_amt - discount; 
            discounted_amt = Number(discounted_amt).toFixed(2);
            $('#discounted_amt_'+ i).val(discounted_amt);
            }
            */
            getGTotal();
            }
        
            function getRateAmt(val) {
            var i = val;
            var item_rate = $('#item_rate_' + i).val();
            var item_qty = $('#item_qty_' + i).val();
            
            if(item_rate != ''){
            var item_amt = item_qty * item_rate;
            item_amt = Number(item_amt).toFixed(2);
            $('#item_amt_'+ i).val(item_amt);
            }else{
            var item_amt = 0;   
            item_amt = Number(item_amt).toFixed(2);
            $('#item_amt_'+ i).val(item_amt);
            }
            // var discount_rate = $('#discount_rate_' + i).val();
            // if(discount_rate != ''){
            // var discount = item_amt * (discount_rate / 100);
            // var discounted_amt = item_amt - discount; 
            // discounted_amt = Number(discounted_amt).toFixed(2);
            // $('#item_amt_'+ i).val(discounted_amt);
            // }
            getGTotal();
            }
            
            function getDiscount(val1){
        var i = val1;
        var item_qty = $('#item_qty_' + i).val();
            var item_rate = $('#item_rate_' + i).val();
            
            if(item_rate != ''){
            var item_amt = item_qty * item_rate;
            item_amt = Number(item_amt).toFixed(2);
            $('#item_amt_'+ i).val(item_amt);
            }else{
            var item_amt = 0;   
            item_amt = Number(item_amt).toFixed(2);
            $('#item_amt_'+ i).val(item_amt);
            }
            
        var discount_rate = $('#discount_rate_' + i).val();
        var item_amt = $('#item_amt_' + i).val();
            if(item_amt == ''){
            var item_amt = 0;   
            }
        var discount = item_amt * (discount_rate / 100);
        var discounted_amt = item_amt - discount;
        discounted_amt = Number(discounted_amt).toFixed(2);
        $('#item_amt_'+ i).val(discounted_amt);
        getGTotal();    
        }
        function getGTotal(){
            //alert(val);
                //var i = val;
                var sub_tot_amt = 0;
                for(c = 0; c < itm_po; c++){
                var amt = $('#item_amt_'+ c).val();
                //var amt = $('#discounted_amt_' + c).val();
                if(amt != 0){
                sub_tot_amt = sub_tot_amt + Number(amt);
                }
                }
                sub_tot_amt = Number(sub_tot_amt).toFixed(2);
                document.getElementById("po_sub_amt_0").innerHTML = sub_tot_amt;
                $('#po_sub_amt_1').val(sub_tot_amt);
                var cgstAmt = sub_tot_amt * (9/100);
                cgstAmt = Number(cgstAmt).toFixed(2);
                document.getElementById("cgst_amt_0").innerHTML = cgstAmt;
                $('#cgst_amt_1').val(cgstAmt);
                var sgstAmt = sub_tot_amt * (9/100);
                sgstAmt = Number(sgstAmt).toFixed(2);
                document.getElementById("sgst_amt_0").innerHTML = sgstAmt;
                $('#sgst_amt_1').val(sgstAmt);
                var gTotAmt = Number(sub_tot_amt) + Number(cgstAmt) + Number(sgstAmt); 
                gTotAmt = gTotAmt.toFixed(2);
                document.getElementById("po_g_t_amt_0").innerHTML = gTotAmt;
                $('#po_g_t_amt_1').val(gTotAmt);
                }
            

</script>



            <script type="text/javascript">
                itm_po=1;
           function add_item_po() {
             
             var items = '';
                   <?php 
            $sql = "SELECT * FROM ".TABLE_ITEM." ORDER BY name asc";
            $res = $db->selectData($sql);
            while($row_rec = $db->getRow($res)){
            ?>
            items += '<option value="<?php echo $row_rec['id']; ?>" ><?php echo $row_rec['name']; ?></option>';
                    <?php }?>
                   
        
        var st = '<tr id="itm_po_tbl_row_' + itm_po + '">'
                    + '<td><select name="item_name[]" id="item_name_' + itm_po + '" class="form-control select" onchange="get_cat1(this.value,\'' + itm_po + '\')"><option>--Select--</option>' + items + '</select></td>'
                    + '<td><input type="text" class="form-control padding width" name="hsn_code[]" id="hsn_code_' + itm_po + '" value="" placeholder="HSN Code" readonly></td>'
                    + '<td><input type="text" class="form-control padding width right" step="any" name="item_rate[]" id="item_rate_' + itm_po + '" value="" onkeyup="getRateAmt(\'' + itm_po + '\');" placeholder="Rate"></td>'
                    + '<td><input type="text" class="form-control padding width" name="item_unit[]" id="item_unit_' + itm_po + '" value="" placeholder="Unit" readonly></td>'
                    + '<td><input type="text"  class="form-control padding width right" name="item_qty[]" id="item_qty_' + itm_po + '" value="" onkeyup="getAmt(\'' + itm_po + '\');" placeholder="Quantity"></td>'
                    //+ '<td><input type="text" class="form-control padding width right" step="any" name="discount_rate[]" id="discount_rate_' + itm_po + '" value="" onkeyup="getDiscount(\'' + itm_po + '\');" placeholder="Discount"></td>' 
                    //+ '<td><input type="hidden" class="form-control padding width right" step="any" name="discounted_amt[]" id="discounted_amt_' + itm_po + '" value="" placeholder=""></td>'
                    + '<td><input type="text" class="form-control padding width right" step="any" name="item_amt[]" id="item_amt_' + itm_po + '" value="" placeholder="Amount" readonly></td>'
                    + '<td><div style="color: red;cursor: pointer;font-size: 20px;font-weight: 600;" class="row_delete" onclick="deleteItemPO(\'#itm_po_tbl_row_' + itm_po + '\');">&cross;</div></td>'
                    + '</tr>';
            $(".itm_po_tbl").append(st);
            itm_po++;
        }
        
        function deleteItemPO(elm) {
            var row = elm.substr(16);
            var i = row;
            //alert(elm);
            $('#item_amt_'+ i).val(0);
            itm_po--;
            getGTotal();
            
            $(elm).remove();
        }

</script>



<?php include('includes/admin_footer.php'); ?> 