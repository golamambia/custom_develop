<?php
include('../configure.php');
 $id=$_POST[val];
 $proid=$_POST[val2];
 $delete=$_POST['img'];
 $did=$_POST['did'];
 $row=$_POST['row'];
 $db->deleteData(TABLE_ITEM_ORDER_UPLOAD,"id=".$id);
 unlink("images/$delete");
?>
<div id="multi_img<?=$did;?>">
                    <?PHP
                     //$proid=$get_des['id'];
                    //$get_product2 = $pm->getTableDetails(DTABLE_MULTIIMG,'product_rid',$proid);

        $sql2 = "SELECT * FROM ".TABLE_ITEM_ORDER_UPLOAD." where row_no='$row' ORDER BY id DESC";
            $res2 = $db->selectData($sql2);
            while($row_rec2 = $db->getRow($res2)){
            
             ?>

<div style="margin-top: 0px;float: left;margin-right: 10px;position: relative;padding-top: 20px;"><span style="cursor:pointer;position: absolute;top:0px;left:0px;right:0px;display: block;text-align: center;color: red;font-size: 100%;" onclick="del_img('<?=$row_rec2['id'];?>','<?=$row_rec2[order_id];?>','<?=$row_rec2[multi_upload];?>','<?=$did;?>','<?=$row;?>')">X</span><img src="<?PHP echo HOME_UPLOAD.$row_rec2['multi_upload'];?>" height="20"/></div>

         <?php } ?>
                </div>


