<?php
//session_start();
include('mysql.php');
/**
 * PHPExcel
 *
 * Copyright (c) 2006 - 2015 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2015 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(0);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Europe/London');

/** Include PHPExcel */
require_once dirname(__FILE__) . '/../Classes/PHPExcel.php';

 $objPHPExcel = new PHPExcel();
  $query1 = "SELECT * FROM api_money_transfer_details where rcp_name!='' ";

//$user=mysql_fetch_array(mysql_query("SELECT * FROM  api_users where gatkey='$_SESSION[gatkey]'"));

  $exec1 = mysql_query($query1) or die ("Error in Query1".mysql_error());
  $serialnumber=0;
  //Set header with temp array
  $tmparray =array("No","Bank Name ","Account Number","Bank Ref Number","Customer Number","Amount","Account Holder","TID","Payid","date","Status","date & Time");
  //take new main array and set header array in it.
  $sheet =array($tmparray);

  while ($res1 = mysql_fetch_array($exec1))
  {
    $tmparray =array();
    $serialnumber = $serialnumber + 1;
    array_push($tmparray,$serialnumber);
	
    $employeelogin = $res1['bank_name'];
    array_push($tmparray,$employeelogin);
	
    $employeename = $res1['account'];
    array_push($tmparray,$employeename); 
	
	
	$bank_ref = $res1['bank_ref'];
    array_push($tmparray,$bank_ref); 
	
	$customer_id = $res1['customer_id'];
    array_push($tmparray,$customer_id); 
	

	
	
	 $Amount = $res1['amount'];
    array_push($tmparray,$Amount); 
	
	 $rcp_name = $res1['rcp_name'];
    array_push($tmparray,$rcp_name); 
	
	$TID = $res1['tid'];
    array_push($tmparray,$TID); 
	
	
	$Payid = $res1['payid'];
    array_push($tmparray,$Payid); 
	
	$date = $res1['date'];
    array_push($tmparray,$date); 
	
	$status = $res1['txn_status'];
    array_push($tmparray,$status); 
	
	$excatime = $res1['times'];
    array_push($tmparray,$excatime); 
	
	
	  
    array_push($sheet,$tmparray);
  }
  
  function cellColor($cells,$color){
    global $objPHPExcel;

    $objPHPExcel->getActiveSheet()->getStyle($cells)->getFill()->applyFromArray(array(
        'type' => PHPExcel_Style_Fill::FILL_SOLID,
        'startcolor' => array(
             'rgb' => $color
        )
    ));
}

cellColor('A1', 'F28A8C');
cellColor('B1', 'b77b0d');
cellColor('C1', '0d22b7');
cellColor('D1', 'b70daa');
cellColor('E1', 'b7250d');

cellColor('F1', '0db739');
cellColor('G1', '0d61b7');
cellColor('H1', 'b70d15');

cellColor('I1', 'adb70d');

cellColor('J1', 'e26821');

cellColor('K1', '248812');

cellColor('L1', '123c88');

cellColor('M1', 'adb70d');

   
// Redirect output to a client’s web browser (Excel2010)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="01simple.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');


// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0
  $worksheet = $objPHPExcel->getActiveSheet();
  foreach($sheet as $row => $columns) {
    foreach($columns as $column => $data) {
        $worksheet->setCellValueByColumnAndRow($column, $row + 1, $data);
		
		
		 
		    }
  }
  
  
  
  
  
  
  
  
  
  
  
  


  //make first row bold
  $objPHPExcel->getActiveSheet()->getStyle("A1:I1")->getFont()->setBold(true);
  
$objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(25);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);

$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(25);

$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);

$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(13);

$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(8);

$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(40);

$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);

$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(18);

$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);

$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);

$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(25);

$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(30);




  
  $objPHPExcel->setActiveSheetIndex(0);
  $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;
  
  
  
  ?>