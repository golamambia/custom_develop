<?php 
define("STRIPE_SECRET_KEY", "sk_test_4eC39HqLyjWDarjtT1zdp7dc");
define("STRIPE_PUBLISHABLE_KEY", "pk_test_TYooMQauvdEDq54NiTphI7jx");
?>