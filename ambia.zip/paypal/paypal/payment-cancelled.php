<?php include("header.php");?>
  
<div class="container">

<br><br>
<div class="pdoduct-header">
                            
                            <?php                  
      if ($_GET["successful"] == ""){
       
    ?>
<!-- <h1>Thank you for your order. </h1> -->
               <h1 style="font-size: 23px;">Your payment cancelled</h1>            

               
    <?php
     
      }
    ?>
                
                        </div>
<br><br>
    	    		
			<div class="buttons cart-btngroup">
        <div class="pull-left"><a class="btn btn160 btn-lg btn-default" href="this_two.php">Continue </a></div>
       
      </div>
                        <br> <br> <br> <br>
                    </div>







  <?php include("footer.php");?>